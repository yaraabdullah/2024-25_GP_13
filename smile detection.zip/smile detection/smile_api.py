from flask import Flask, request, jsonify
import cv2
import numpy as np
from PIL import Image
import io

app = Flask(__name__)

@app.route('/smile-detection', methods=['POST'])
def detect_smile():
    if 'image' not in request.files:
        return jsonify({'error': 'No image provided'}), 400

    file = request.files['image']
    img = Image.open(file.stream).convert('L')  # Grayscale
    img_np = np.array(img)

    smile_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_smile.xml')
    smiles = smile_cascade.detectMultiScale(img_np, scaleFactor=1.8, minNeighbors=20)

    return jsonify({'smiling': len(smiles) > 0})

# THIS PART IS CRITICAL
if __name__ == '__main__':
    app.run(debug=True)
