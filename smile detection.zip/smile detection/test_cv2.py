import cv2
print("OpenCV Version:", cv2.__version__)