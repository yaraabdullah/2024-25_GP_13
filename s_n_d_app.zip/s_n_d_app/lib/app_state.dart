import 'package:flutter/material.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/api_requests/api_manager.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';
import 'dart:convert';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {
    prefs = await SharedPreferences.getInstance();
    _safeInit(() {
      if (prefs.containsKey('ff_audioRef')) {
        try {
          _audioRef = jsonDecode(prefs.getString('ff_audioRef') ?? '');
        } catch (e) {
          print("Can't decode persisted json. Error: $e.");
        }
      }
    });
    _safeInit(() {
      _musicEnabled = prefs.getBool('ff_musicEnabled') ?? _musicEnabled;
    });
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late SharedPreferences prefs;

  dynamic _audioRef = jsonDecode(
      '[\"https://firebasestorage.googleapis.com/v0/b/sand-98353.appspot.com/o/backgroundSound-nature%2Fnature-216798.mp3?alt=media&token=8e3c4fdd-f564-45ae-b5fb-598f9e670145\",\"https://firebasestorage.googleapis.com/v0/b/sand-98353.appspot.com/o/backgroundSound-chill%2F1%20Hour%20Relaxing%20Sleep%20Music.mp3?alt=media&token=0b36e11c-f2e6-4d70-834f-b2aa5d69c181\"]');
  dynamic get audioRef => _audioRef;
  set audioRef(dynamic value) {
    _audioRef = value;
    prefs.setString('ff_audioRef', jsonEncode(value));
  }

  bool _musicEnabled = true;
  bool get musicEnabled => _musicEnabled;
  set musicEnabled(bool value) {
    _musicEnabled = value;
    prefs.setBool('ff_musicEnabled', value);
  }

  String _currentURL =
      'https://firebasestorage.googleapis.com/v0/b/sand-98353.appspot.com/o/backgroundSound-nature%2Fnature-216798.mp3?alt=media&token=8e3c4fdd-f564-45ae-b5fb-598f9e670145';
  String get currentURL => _currentURL;
  set currentURL(String value) {
    _currentURL = value;
  }

  List<String> _audiRef2 = [
    '\"https://firebasestorage.googleapis.com/v0/b/sand-98353.appspot.com/o/backgroundSound-nature%2Fnature-216798.mp3?alt=media&token=8e3c4fdd-f564-45ae-b5fb-598f9e670145\"',
    '\"https://firebasestorage.googleapis.com/v0/b/sand-98353.appspot.com/o/backgroundSound-chill%2F1%20Hour%20Relaxing%20Sleep%20Music%2C%20Sleep%20Therapy%2C%20Deep%20Sleep%20Music%2C%20Insomnia%2C%20Spa%2C%20Study%2C%20Sleep%2C101.mp3?alt=media&token=0b36e11c-f2e6-4d70-834f-b2aa5d69c181\"'
  ];
  List<String> get audiRef2 => _audiRef2;
  set audiRef2(List<String> value) {
    _audiRef2 = value;
  }

  void addToAudiRef2(String value) {
    audiRef2.add(value);
  }

  void removeFromAudiRef2(String value) {
    audiRef2.remove(value);
  }

  void removeAtIndexFromAudiRef2(int index) {
    audiRef2.removeAt(index);
  }

  void updateAudiRef2AtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    audiRef2[index] = updateFn(_audiRef2[index]);
  }

  void insertAtIndexInAudiRef2(int index, String value) {
    audiRef2.insert(index, value);
  }

  String _initAddio =
      'https://firebasestorage.googleapis.com/v0/b/sand-98353.appspot.com/o/backgroundSound-nature%2Fnature-216798.mp3?alt=media&token=8e3c4fdd-f564-45ae-b5fb-598f9e670145';
  String get initAddio => _initAddio;
  set initAddio(String value) {
    _initAddio = value;
  }

  List<String> _allAdio = [
    'https://firebasestorage.googleapis.com/v0/b/sand-98353.appspot.com/o/backgroundSound-nature%2Fnature-216798.mp3?alt=media&token=8e3c4fdd-f564-45ae-b5fb-598f9e670145',
    'https://firebasestorage.googleapis.com/v0/b/sand-98353.appspot.com/o/backgroundSound-nature%2F1%20hour%20of%20Relaxing%20River%20Sounds.%20Ideal%20for%20Sleep%2C%20Healing%20or%20Studying.mp3?alt=media&token=8c0c66ec-ff8e-4164-96da-221184037084'
  ];
  List<String> get allAdio => _allAdio;
  set allAdio(List<String> value) {
    _allAdio = value;
  }

  void addToAllAdio(String value) {
    allAdio.add(value);
  }

  void removeFromAllAdio(String value) {
    allAdio.remove(value);
  }

  void removeAtIndexFromAllAdio(int index) {
    allAdio.removeAt(index);
  }

  void updateAllAdioAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    allAdio[index] = updateFn(_allAdio[index]);
  }

  void insertAtIndexInAllAdio(int index, String value) {
    allAdio.insert(index, value);
  }

  List<SoundsinfoStruct> _a = [
    SoundsinfoStruct.fromSerializableMap(jsonDecode(
        '{\"title\":\"Hello World\",\"sound\":\"https://firebasestorage.googleapis.com/v0/b/sand-98353.appspot.com/o/backgroundSound-sleep%2FWhite%20Noise%201%20Hour%20Long.mp3?alt=media&token=586f71c1-9323-41da-8ea7-4a2dc2845195\"}'))
  ];
  List<SoundsinfoStruct> get a => _a;
  set a(List<SoundsinfoStruct> value) {
    _a = value;
  }

  void addToA(SoundsinfoStruct value) {
    a.add(value);
  }

  void removeFromA(SoundsinfoStruct value) {
    a.remove(value);
  }

  void removeAtIndexFromA(int index) {
    a.removeAt(index);
  }

  void updateAAtIndex(
    int index,
    SoundsinfoStruct Function(SoundsinfoStruct) updateFn,
  ) {
    a[index] = updateFn(_a[index]);
  }

  void insertAtIndexInA(int index, SoundsinfoStruct value) {
    a.insert(index, value);
  }
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}
