import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'no_past_appointments_model.dart';
export 'no_past_appointments_model.dart';

class NoPastAppointmentsWidget extends StatefulWidget {
  const NoPastAppointmentsWidget({super.key});

  @override
  State<NoPastAppointmentsWidget> createState() =>
      _NoPastAppointmentsWidgetState();
}

class _NoPastAppointmentsWidgetState extends State<NoPastAppointmentsWidget> {
  late NoPastAppointmentsModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => NoPastAppointmentsModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsetsDirectional.fromSTEB(9.0, 66.0, 9.0, 66.0),
      child: Text(
        'You have no past appointments at the moment. Once you complete an appointment, it will appear here.',
        textAlign: TextAlign.center,
        style: FlutterFlowTheme.of(context).bodyMedium.override(
              fontFamily: 'Inter',
              color: Color(0xFF4A4B4F),
              letterSpacing: 0.0,
            ),
      ),
    );
  }
}
