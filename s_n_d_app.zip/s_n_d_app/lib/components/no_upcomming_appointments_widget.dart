import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'no_upcomming_appointments_model.dart';
export 'no_upcomming_appointments_model.dart';

class NoUpcommingAppointmentsWidget extends StatefulWidget {
  const NoUpcommingAppointmentsWidget({super.key});

  @override
  State<NoUpcommingAppointmentsWidget> createState() =>
      _NoUpcommingAppointmentsWidgetState();
}

class _NoUpcommingAppointmentsWidgetState
    extends State<NoUpcommingAppointmentsWidget> {
  late NoUpcommingAppointmentsModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => NoUpcommingAppointmentsModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsetsDirectional.fromSTEB(0.0, 66.0, 0.0, 66.0),
      child: Text(
        'You currently have no upcoming appointments\nSchedule a new one to get started!',
        textAlign: TextAlign.center,
        style: FlutterFlowTheme.of(context).bodyMedium.override(
              fontFamily: 'Inter',
              color: Color(0xFF4A4B4F),
              letterSpacing: 0.0,
            ),
      ),
    );
  }
}
