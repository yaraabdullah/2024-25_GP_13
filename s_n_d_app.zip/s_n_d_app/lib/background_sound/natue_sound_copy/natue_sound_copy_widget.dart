import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_audio_player.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'natue_sound_copy_model.dart';
export 'natue_sound_copy_model.dart';

class NatueSoundCopyWidget extends StatefulWidget {
  const NatueSoundCopyWidget({super.key});

  @override
  State<NatueSoundCopyWidget> createState() => _NatueSoundCopyWidgetState();
}

class _NatueSoundCopyWidgetState extends State<NatueSoundCopyWidget>
    with TickerProviderStateMixin {
  late NatueSoundCopyModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  final animationsMap = <String, AnimationInfo>{};

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => NatueSoundCopyModel());

    animationsMap.addAll({
      'textOnPageLoadAnimation': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          FadeEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 600.0.ms,
            begin: 0.0,
            end: 1.0,
          ),
          MoveEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 600.0.ms,
            begin: Offset(0.0, 60.0),
            end: Offset(0.0, 0.0),
          ),
          ScaleEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 600.0.ms,
            begin: Offset(0.95, 1.0),
            end: Offset(1.0, 1.0),
          ),
        ],
      ),
    });
    setupAnimations(
      animationsMap.values.where((anim) =>
          anim.trigger == AnimationTrigger.onActionTrigger ||
          !anim.applyInitialState),
      this,
    );

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primary,
        body: Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            Expanded(
              child: Container(
                height: 500.0,
                child: Stack(
                  alignment: AlignmentDirectional(0.0, -1.0),
                  children: [
                    Container(
                      width: double.infinity,
                      height: 500.0,
                      decoration: BoxDecoration(
                        color: FlutterFlowTheme.of(context).primary,
                      ),
                    ),
                    Align(
                      alignment: AlignmentDirectional(0.0, 0.0),
                      child: SingleChildScrollView(
                        child: Column(
                          mainAxisSize: MainAxisSize.max,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 10.0, 0.0, 0.0),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  FlutterFlowIconButton(
                                    borderColor: Colors.transparent,
                                    borderRadius: 30.0,
                                    borderWidth: 1.0,
                                    buttonSize: 60.0,
                                    fillColor: Color(0x00FFFFFF),
                                    icon: Icon(
                                      Icons.arrow_back_rounded,
                                      color: FlutterFlowTheme.of(context)
                                          .primaryBackground,
                                      size: 30.0,
                                    ),
                                    onPressed: () async {
                                      context.pushNamed('BackgroundSound');
                                    },
                                  ),
                                  Align(
                                    alignment: AlignmentDirectional(0.0, 0.0),
                                    child: Padding(
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          0.0, 0.0, 16.0, 0.0),
                                      child: Text(
                                        'Nature',
                                        style: FlutterFlowTheme.of(context)
                                            .titleMedium
                                            .override(
                                              fontFamily: 'Readex Pro',
                                              fontSize: 35.0,
                                              letterSpacing: 0.0,
                                              fontWeight: FontWeight.w600,
                                            ),
                                      ).animateOnPageLoad(animationsMap[
                                          'textOnPageLoadAnimation']!),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 32.0, 0.0, 0.0),
                              child: Container(
                                width: double.infinity,
                                height: 737.0,
                                decoration: BoxDecoration(
                                  color: FlutterFlowTheme.of(context)
                                      .secondaryBackground,
                                  borderRadius: BorderRadius.only(
                                    bottomLeft: Radius.circular(0.0),
                                    bottomRight: Radius.circular(0.0),
                                    topLeft: Radius.circular(16.0),
                                    topRight: Radius.circular(16.0),
                                  ),
                                ),
                                child: Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 8.0, 0.0, 24.0),
                                  child: SingleChildScrollView(
                                    child: Column(
                                      mainAxisSize: MainAxisSize.max,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        FlutterFlowAudioPlayer(
                                          audio: Audio.network(
                                            'https://firebasestorage.googleapis.com/v0/b/sand-98353.appspot.com/o/backgroundSound-nature%2F1%20hour%20of%20farm%20animal%20noises%20%20Farm%20ambience%20sound%20for%20sleeping%20(1).mp3?alt=media&token=a8a23fc7-c239-450d-a98f-9c1855c65a94',
                                            metas: Metas(
                                              id: 'backgroundSound-nature%2F1%20hour%20of%20farm%20animal%20noises%20%20Farm%20ambience%20sound%20for%20sleeping%20(1).mp3?alt=media&token=a8a23fc7-c239-450d-a98f-9c1855c65a94-87c2c986',
                                              title: 'Farm',
                                            ),
                                          ),
                                          titleTextStyle:
                                              FlutterFlowTheme.of(context)
                                                  .titleLarge
                                                  .override(
                                                    fontFamily: 'Readex Pro',
                                                    letterSpacing: 0.0,
                                                  ),
                                          playbackDurationTextStyle:
                                              FlutterFlowTheme.of(context)
                                                  .labelMedium
                                                  .override(
                                                    fontFamily: 'Inter',
                                                    letterSpacing: 0.0,
                                                  ),
                                          fillColor:
                                              FlutterFlowTheme.of(context)
                                                  .secondaryBackground,
                                          playbackButtonColor:
                                              FlutterFlowTheme.of(context)
                                                  .primary,
                                          activeTrackColor:
                                              FlutterFlowTheme.of(context)
                                                  .primary,
                                          inactiveTrackColor:
                                              FlutterFlowTheme.of(context)
                                                  .alternate,
                                          elevation: 0.0,
                                          pauseOnNavigate: false,
                                          playInBackground:
                                              PlayInBackground.enabled,
                                        ),
                                        FlutterFlowAudioPlayer(
                                          audio: Audio.network(
                                            'https://firebasestorage.googleapis.com/v0/b/sand-98353.appspot.com/o/backgroundSound-nature%2F1%20hour%20of%20Relaxing%20River%20Sounds.%20Ideal%20for%20Sleep%2C%20Healing%20or%20Studying.mp3?alt=media&token=8c0c66ec-ff8e-4164-96da-221184037084',
                                            metas: Metas(
                                              id: 'backgroundSound-nature%2F1%20hour%20of%20Relaxing%20River%20Sounds.%20Ideal%20for%20Sleep%2C%20Healing%20or%20Studying.mp3?alt=media&token=8c0c66ec-ff8e-4164-96da-221184037084-5d205046',
                                              title: 'Sea Waves',
                                            ),
                                          ),
                                          titleTextStyle:
                                              FlutterFlowTheme.of(context)
                                                  .titleLarge
                                                  .override(
                                                    fontFamily: 'Readex Pro',
                                                    letterSpacing: 0.0,
                                                  ),
                                          playbackDurationTextStyle:
                                              FlutterFlowTheme.of(context)
                                                  .labelMedium
                                                  .override(
                                                    fontFamily: 'Inter',
                                                    letterSpacing: 0.0,
                                                  ),
                                          fillColor:
                                              FlutterFlowTheme.of(context)
                                                  .secondaryBackground,
                                          playbackButtonColor:
                                              FlutterFlowTheme.of(context)
                                                  .primary,
                                          activeTrackColor:
                                              FlutterFlowTheme.of(context)
                                                  .primary,
                                          inactiveTrackColor:
                                              FlutterFlowTheme.of(context)
                                                  .alternate,
                                          elevation: 0.0,
                                          pauseOnNavigate: false,
                                          playInBackground:
                                              PlayInBackground.enabled,
                                        ),
                                        FlutterFlowAudioPlayer(
                                          audio: Audio.network(
                                            'https://firebasestorage.googleapis.com/v0/b/sand-98353.appspot.com/o/backgroundSound-nature%2FRelaxing%20Sounds%20of%20Wind%201%20Hour%20%20Autumn%20Leaves%20Rumbling%20in%20The%20Wind.mp3?alt=media&token=ef71eaf3-f371-4357-bb14-d13961f6c99c',
                                            metas: Metas(
                                              id: 'backgroundSound-nature%2FRelaxing%20Sounds%20of%20Wind%201%20Hour%20%20Autumn%20Leaves%20Rumbling%20in%20The%20Wind.mp3?alt=media&token=ef71eaf3-f371-4357-bb14-d13961f6c99c-e6d46748',
                                              title: 'Autumn Leaves Falling',
                                            ),
                                          ),
                                          titleTextStyle:
                                              FlutterFlowTheme.of(context)
                                                  .titleLarge
                                                  .override(
                                                    fontFamily: 'Readex Pro',
                                                    letterSpacing: 0.0,
                                                  ),
                                          playbackDurationTextStyle:
                                              FlutterFlowTheme.of(context)
                                                  .labelMedium
                                                  .override(
                                                    fontFamily: 'Inter',
                                                    letterSpacing: 0.0,
                                                  ),
                                          fillColor:
                                              FlutterFlowTheme.of(context)
                                                  .secondaryBackground,
                                          playbackButtonColor:
                                              FlutterFlowTheme.of(context)
                                                  .primary,
                                          activeTrackColor:
                                              FlutterFlowTheme.of(context)
                                                  .primary,
                                          inactiveTrackColor:
                                              FlutterFlowTheme.of(context)
                                                  .alternate,
                                          elevation: 0.0,
                                          pauseOnNavigate: false,
                                          playInBackground:
                                              PlayInBackground.enabled,
                                        ),
                                        FlutterFlowAudioPlayer(
                                          audio: Audio.network(
                                            'https://firebasestorage.googleapis.com/v0/b/sand-98353.appspot.com/o/backgroundSound-nature%2FNature%20Sounds_%20Rain%20Sounds%20One%20Hour%20for%20Sleeping%2C%20Sleep%20Aid%20for%20Everybody.mp3?alt=media&token=3f2416c9-0294-4cfc-96ff-289e74163763',
                                            metas: Metas(
                                              id: 'backgroundSound-nature%2FNature%20Sounds_%20Rain%20Sounds%20One%20Hour%20for%20Sleeping%2C%20Sleep%20Aid%20for%20Everybody.mp3?alt=media&token=3f2416c9-0294-4cfc-96ff-289e74163763-4d89beb5',
                                              title: 'Rain ',
                                            ),
                                          ),
                                          titleTextStyle:
                                              FlutterFlowTheme.of(context)
                                                  .titleLarge
                                                  .override(
                                                    fontFamily: 'Readex Pro',
                                                    letterSpacing: 0.0,
                                                  ),
                                          playbackDurationTextStyle:
                                              FlutterFlowTheme.of(context)
                                                  .labelMedium
                                                  .override(
                                                    fontFamily: 'Inter',
                                                    letterSpacing: 0.0,
                                                  ),
                                          fillColor:
                                              FlutterFlowTheme.of(context)
                                                  .secondaryBackground,
                                          playbackButtonColor:
                                              FlutterFlowTheme.of(context)
                                                  .primary,
                                          activeTrackColor:
                                              FlutterFlowTheme.of(context)
                                                  .primary,
                                          inactiveTrackColor:
                                              FlutterFlowTheme.of(context)
                                                  .alternate,
                                          elevation: 0.0,
                                          pauseOnNavigate: false,
                                          playInBackground:
                                              PlayInBackground.enabled,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
