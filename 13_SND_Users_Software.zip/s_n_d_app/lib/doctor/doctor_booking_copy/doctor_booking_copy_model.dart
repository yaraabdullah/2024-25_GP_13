import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/components/doctor_nopast_widget.dart';
import '/components/doctor_noupcoming_widget.dart';
import '/doctor/doctor_nav_bar/doctor_nav_bar_widget.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_button_tabbar.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:math';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 'doctor_booking_copy_widget.dart' show DoctorBookingCopyWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DoctorBookingCopyModel extends FlutterFlowModel<DoctorBookingCopyWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for TabBar widget.
  TabController? tabBarController;
  int get tabBarCurrentIndex =>
      tabBarController != null ? tabBarController!.index : 0;
  int get tabBarPreviousIndex =>
      tabBarController != null ? tabBarController!.previousIndex : 0;

  // Model for DoctorNavBar component.
  late DoctorNavBarModel doctorNavBarModel;

  @override
  void initState(BuildContext context) {
    doctorNavBarModel = createModel(context, () => DoctorNavBarModel());
  }

  @override
  void dispose() {
    tabBarController?.dispose();
    doctorNavBarModel.dispose();
  }
}
