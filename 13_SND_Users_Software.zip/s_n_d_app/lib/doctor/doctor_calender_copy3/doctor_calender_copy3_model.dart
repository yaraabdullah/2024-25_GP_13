import '/auth/firebase_auth/auth_util.dart';
import '/flutter_flow/flutter_flow_checkbox_group.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import 'doctor_calender_copy3_widget.dart' show DoctorCalenderCopy3Widget;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DoctorCalenderCopy3Model
    extends FlutterFlowModel<DoctorCalenderCopy3Widget> {
  ///  State fields for stateful widgets in this page.

  DateTime? datePicked1;
  // State field(s) for Sunday widget.
  FormFieldController<List<String>>? sundayValueController;
  List<String>? get sundayValues => sundayValueController?.value;
  set sundayValues(List<String>? v) => sundayValueController?.value = v;

  // State field(s) for Monday widget.
  FormFieldController<List<String>>? mondayValueController;
  List<String>? get mondayValues => mondayValueController?.value;
  set mondayValues(List<String>? v) => mondayValueController?.value = v;

  // State field(s) for tuesday widget.
  FormFieldController<List<String>>? tuesdayValueController;
  List<String>? get tuesdayValues => tuesdayValueController?.value;
  set tuesdayValues(List<String>? v) => tuesdayValueController?.value = v;

  // State field(s) for wednesday widget.
  FormFieldController<List<String>>? wednesdayValueController;
  List<String>? get wednesdayValues => wednesdayValueController?.value;
  set wednesdayValues(List<String>? v) => wednesdayValueController?.value = v;

  // State field(s) for thaursday widget.
  FormFieldController<List<String>>? thaursdayValueController;
  List<String>? get thaursdayValues => thaursdayValueController?.value;
  set thaursdayValues(List<String>? v) => thaursdayValueController?.value = v;

  // State field(s) for repeatOptions widget.
  String? repeatOptionsValue;
  FormFieldController<String>? repeatOptionsValueController;
  DateTime? datePicked2;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
