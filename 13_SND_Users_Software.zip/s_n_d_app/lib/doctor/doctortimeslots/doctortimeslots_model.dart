import '/auth/firebase_auth/auth_util.dart';
import '/flutter_flow/flutter_flow_calendar.dart';
import '/flutter_flow/flutter_flow_checkbox_group.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/flutter_flow/custom_functions.dart' as functions;
import 'doctortimeslots_widget.dart' show DoctortimeslotsWidget;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DoctortimeslotsModel extends FlutterFlowModel<DoctortimeslotsWidget> {
  ///  Local state fields for this page.

  DateTime? selectedDate;

  List<String> selectedTimes = [];
  void addToSelectedTimes(String item) => selectedTimes.add(item);
  void removeFromSelectedTimes(String item) => selectedTimes.remove(item);
  void removeAtIndexFromSelectedTimes(int index) =>
      selectedTimes.removeAt(index);
  void insertAtIndexInSelectedTimes(int index, String item) =>
      selectedTimes.insert(index, item);
  void updateSelectedTimesAtIndex(int index, Function(String) updateFn) =>
      selectedTimes[index] = updateFn(selectedTimes[index]);

  String? repeatOption;

  DateTime? untilDate;

  List<String> outputList = [];
  void addToOutputList(String item) => outputList.add(item);
  void removeFromOutputList(String item) => outputList.remove(item);
  void removeAtIndexFromOutputList(int index) => outputList.removeAt(index);
  void insertAtIndexInOutputList(int index, String item) =>
      outputList.insert(index, item);
  void updateOutputListAtIndex(int index, Function(String) updateFn) =>
      outputList[index] = updateFn(outputList[index]);

  ///  State fields for stateful widgets in this page.

  // State field(s) for Calendar widget.
  DateTimeRange? calendarSelectedDay;
  // State field(s) for CheckboxGroup widget.
  FormFieldController<List<String>>? checkboxGroupValueController;
  List<String>? get checkboxGroupValues => checkboxGroupValueController?.value;
  set checkboxGroupValues(List<String>? v) =>
      checkboxGroupValueController?.value = v;

  // State field(s) for repeatOptions widget.
  String? repeatOptionsValue;
  FormFieldController<String>? repeatOptionsValueController;
  DateTime? datePicked;

  @override
  void initState(BuildContext context) {
    calendarSelectedDay = DateTimeRange(
      start: DateTime.now().startOfDay,
      end: DateTime.now().endOfDay,
    );
  }

  @override
  void dispose() {}
}
