import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'contact_us_widget.dart' show ContactUsWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

class ContactUsModel extends FlutterFlowModel<ContactUsWidget> {
  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  // State field(s) for EmailTextField widget.
  FocusNode? emailTextFieldFocusNode;
  TextEditingController? emailTextFieldTextController;
  String? Function(BuildContext, String?)?
      emailTextFieldTextControllerValidator;
  // State field(s) for SubjectTextField widget.
  FocusNode? subjectTextFieldFocusNode;
  TextEditingController? subjectTextFieldTextController;
  String? Function(BuildContext, String?)?
      subjectTextFieldTextControllerValidator;
  // State field(s) for BodyTextField widget.
  FocusNode? bodyTextFieldFocusNode;
  TextEditingController? bodyTextFieldTextController;
  String? Function(BuildContext, String?)? bodyTextFieldTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    emailTextFieldFocusNode?.dispose();
    emailTextFieldTextController?.dispose();

    subjectTextFieldFocusNode?.dispose();
    subjectTextFieldTextController?.dispose();

    bodyTextFieldFocusNode?.dispose();
    bodyTextFieldTextController?.dispose();
  }
}
