import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_checkbox_group.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:ui';
import '/index.dart';
import 'dart:async';
import 'edit_doctor_profile_widget.dart' show EditDoctorProfileWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:provider/provider.dart';

class EditDoctorProfileModel extends FlutterFlowModel<EditDoctorProfileWidget> {
  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  Completer<List<DoctorsRecord>>? firestoreRequestCompleter;
  // State field(s) for yourName widget.
  FocusNode? yourNameFocusNode1;
  TextEditingController? yourNameTextController1;
  String? Function(BuildContext, String?)? yourNameTextController1Validator;
  String? _yourNameTextController1Validator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Name is required';
    }

    if (val.length < 1) {
      return 'Name is required';
    }

    if (!RegExp('^[a-zA-Z\\s]+\$').hasMatch(val)) {
      return 'Name must contain only alphabetic characters';
    }
    return null;
  }

  // State field(s) for yourName widget.
  FocusNode? yourNameFocusNode2;
  TextEditingController? yourNameTextController2;
  String? Function(BuildContext, String?)? yourNameTextController2Validator;
  String? _yourNameTextController2Validator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Name is required';
    }

    if (val.length < 1) {
      return 'Name is required';
    }

    if (!RegExp('^[a-zA-Z\\s]+\$').hasMatch(val)) {
      return 'Name must contain only alphabetic characters';
    }
    return null;
  }

  // State field(s) for PN widget.
  FocusNode? pnFocusNode;
  TextEditingController? pnTextController;
  final pnMask = MaskTextInputFormatter(mask: '##########');
  String? Function(BuildContext, String?)? pnTextControllerValidator;
  String? _pnTextControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Your phone number is required';
    }

    if (val.length < 1) {
      return 'Your phone number is required';
    }

    if (!RegExp('^05\\d{8}\$').hasMatch(val)) {
      return 'Must be a valid Phone Number start with 05';
    }
    return null;
  }

  // State field(s) for About widget.
  FocusNode? aboutFocusNode;
  TextEditingController? aboutTextController;
  String? Function(BuildContext, String?)? aboutTextControllerValidator;
  String? _aboutTextControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return ' About is required';
    }

    if (val.length < 1) {
      return 'About is required';
    }

    if (!RegExp('').hasMatch(val)) {
      return 'must contain only alphabetic characters';
    }
    return null;
  }

  // State field(s) for Speciality widget.
  FocusNode? specialityFocusNode;
  TextEditingController? specialityTextController;
  String? Function(BuildContext, String?)? specialityTextControllerValidator;
  // State field(s) for DropDown widget.
  String? dropDownValue;
  FormFieldController<String>? dropDownValueController;
  // State field(s) for Sub-Speciality widget.
  FocusNode? subSpecialityFocusNode;
  TextEditingController? subSpecialityTextController;
  String? Function(BuildContext, String?)? subSpecialityTextControllerValidator;
  // State field(s) for Sub-Speciality widget.
  FormFieldController<List<String>>? subSpecialityValueController;
  List<String>? get subSpecialityValues => subSpecialityValueController?.value;
  set subSpecialityValues(List<String>? v) =>
      subSpecialityValueController?.value = v;

  // State field(s) for Languages widget.
  FocusNode? languagesFocusNode;
  TextEditingController? languagesTextController;
  String? Function(BuildContext, String?)? languagesTextControllerValidator;
  String? _languagesTextControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return ' ';
    }

    if (val.length < 1) {
      return 'Languages is required';
    }

    return null;
  }

  // State field(s) for Checkbox-languages widget.
  FormFieldController<List<String>>? checkboxLanguagesValueController;
  List<String>? get checkboxLanguagesValues =>
      checkboxLanguagesValueController?.value;
  set checkboxLanguagesValues(List<String>? v) =>
      checkboxLanguagesValueController?.value = v;

  @override
  void initState(BuildContext context) {
    yourNameTextController1Validator = _yourNameTextController1Validator;
    yourNameTextController2Validator = _yourNameTextController2Validator;
    pnTextControllerValidator = _pnTextControllerValidator;
    aboutTextControllerValidator = _aboutTextControllerValidator;
    languagesTextControllerValidator = _languagesTextControllerValidator;
  }

  @override
  void dispose() {
    yourNameFocusNode1?.dispose();
    yourNameTextController1?.dispose();

    yourNameFocusNode2?.dispose();
    yourNameTextController2?.dispose();

    pnFocusNode?.dispose();
    pnTextController?.dispose();

    aboutFocusNode?.dispose();
    aboutTextController?.dispose();

    specialityFocusNode?.dispose();
    specialityTextController?.dispose();

    subSpecialityFocusNode?.dispose();
    subSpecialityTextController?.dispose();

    languagesFocusNode?.dispose();
    languagesTextController?.dispose();
  }

  /// Additional helper methods.
  Future waitForFirestoreRequestCompleted({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = firestoreRequestCompleter?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }
}
