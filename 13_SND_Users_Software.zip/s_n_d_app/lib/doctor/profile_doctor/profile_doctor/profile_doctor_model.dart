import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/doctor/doctor_nav_bar/doctor_nav_bar_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 'profile_doctor_widget.dart' show ProfileDoctorWidget;
import 'package:auto_size_text/auto_size_text.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

class ProfileDoctorModel extends FlutterFlowModel<ProfileDoctorWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for DoctorNavBar component.
  late DoctorNavBarModel doctorNavBarModel;

  @override
  void initState(BuildContext context) {
    doctorNavBarModel = createModel(context, () => DoctorNavBarModel());
  }

  @override
  void dispose() {
    doctorNavBarModel.dispose();
  }
}
