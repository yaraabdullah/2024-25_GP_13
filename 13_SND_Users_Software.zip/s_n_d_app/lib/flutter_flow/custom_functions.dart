import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/backend.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';
import '/auth/firebase_auth/auth_util.dart';

dynamic saveChatHistory(
  dynamic chatHistory,
  dynamic newChat,
) {
// If chatHistory isn't a list, make it a list and then add newChat
  if (chatHistory is List) {
    chatHistory.add(newChat);
    return chatHistory;
  } else {
    return [newChat];
  }
}

dynamic convertToJSON(String prompt) {
  // take the prompt and return a JSON with form [{"role": "user", "content": prompt}]
  return json.decode('{"role": "user", "content": "$prompt"}');
}

List<DateTime> getAvailSlots(
  List<DateTime> reservedSlots,
  DateTime startDateArg,
) {
  List<DateTime> availableBookings = [];
  DateTime now = DateTime.now();
  DateTime startTime = DateTime(now.year, now.month, now.day, now.hour, 0);
  DateTime endTime = startTime.add(const Duration(days: 2)); // now + 2 days

  // Loop through the time slots from start to end time
  for (DateTime currentTime = startTime;
      currentTime.isBefore(endTime);
      currentTime = currentTime.add(const Duration(hours: 1))) {
    bool isReserved = false;

    // Check if the current time slot is reserved
    for (DateTime reservedTime in reservedSlots) {
      if (currentTime.year == reservedTime.year &&
          currentTime.month == reservedTime.month &&
          currentTime.day == reservedTime.day &&
          currentTime.hour == reservedTime.hour) {
        isReserved = true;
        break;
      }
    }

    // Add the current time slot to available bookings if it's not reserved
    if (!isReserved && currentTime.hour >= 9 && currentTime.hour <= 17) {
      availableBookings.add(currentTime);
    }
  }

  List<DateTime> availableSlots = availableBookings
      .where((datetime) => datetime.day == availableBookings[0].day)
      .toList();

  return availableSlots;
}

DateTime? timeCalculater() {
  return DateTime.now().add(Duration(hours: 1));
}

bool showSearchResult(
  String textsearchfor,
  String textsearchin,
  String textsearchin2,
) {
  return textsearchin.toLowerCase().contains(textsearchfor.toLowerCase()) ||
      textsearchin2.toLowerCase().contains(textsearchfor.toLowerCase());
}

String? calculateAge(DateTime? dob) {
  if (dob == null) {
    return null;
  }

  DateTime now = DateTime.now(); // Current date
  int age = now.year - dob.year; // Calculate initial age

  if (now.month < dob.month || (now.month == dob.month && now.day < dob.day)) {
    age--; // Subtract 1 if the birthday hasn't occurred yet this year
  }

  return age.toString(); // Return age as a string
}

List<AvailabilityStruct>? initialAvailability() {
  // Generate 7 random arrays for each day of the week
  final List<AvailabilityStruct> availability = [];

  // Updated order of days: week starts with Sunday and ends with Thursday
  final List<String> daysOfWeek = [
    'Sunday',
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday'
  ];

  for (final day in daysOfWeek) {
    // Add each day to the availability list with null start and end times
    availability.add(
        AvailabilityStruct(dayofWeek: day, startTime: null, endTime: null));
  }

  return availability;
}

double averageRating(List<int>? ratings) {
  // generate avarage rating from list of integer value.
  if (ratings == null || ratings.isEmpty) {
    return 0.0;
  }

  double sum = 0.0;
  for (int rating in ratings) {
    sum += rating;
  }

  return sum / ratings.length;
}

DateTime convertTimeStringToDateTime(
  String timeString,
  DateTime date,
) {
  final timeFormat = DateFormat.jm(); // For AM/PM format
  final parsedTime = timeFormat.parse(timeString);

  return DateTime(
    date.year,
    date.month,
    date.day,
    parsedTime.hour,
    parsedTime.minute,
  );
}

List<DateTime>? getAvailabileSlots(
  List<DateTime> bookings,
  DateTime dateArg,
  List<AvailabilityStruct> availability,
) {
  final matchingAvailability = availability
      .where((a) =>
          a.dayofWeek.toLowerCase() ==
          DateFormat('EEEE').format(dateArg).toLowerCase())
      .toList();

// Next, we need to create a list of DateTime objects representing the half-hourly blocks between the start and end times of each matching DayOfWeekWithTimeStruct object.
  final availableSlots = <DateTime>[];
  for (final a in matchingAvailability) {
    if (a.hasStartTime() && a.hasEndTime()) {
      final startHour = a.startTime!.hour;
      final endHour = a.endTime!.hour;
      final startMinute = a.startTime!.minute;
      final endMinute = a.endTime!.minute;

      for (var hour = startHour; hour <= endHour; hour++) {
        for (var minute = 0; minute < 60; minute += 30) {
          if (hour == startHour && minute < startMinute) {
            continue; // Skip this half-hour block before the start time.
          }

          if (hour == endHour && minute >= endMinute) {
            break; // Exit the minute loop when reaching or exceeding the end time.
          }

          availableSlots.add(
              DateTime(dateArg.year, dateArg.month, dateArg.day, hour, minute));
        }
      }
    }
  }

  // Finally, we need to filter out any DateTime objects that match the bookings list.
  final availableSlotsFiltered = availableSlots
      .where((slot) => !bookings.any((booking) =>
          booking.hour == slot.hour &&
          booking.minute == slot.minute &&
          booking.day == slot.day &&
          booking.month == slot.month &&
          booking.year == slot.year))
      .toList();

  DateTime now = DateTime.now();

  return availableSlotsFiltered.where((slot) => slot.isAfter(now)).toList();
}

String createAppointmentReminderNotification(String userId) {
// Function to create appointment reminder notification for a user
  void createNotification(String userId) async {
    // Get current date and time
    DateTime now = DateTime.now();

    // Get Firestore instance
    FirebaseFirestore firestore = FirebaseFirestore.instance;

    // Query the bookings collection for the user
    firestore
        .collection(
            'bookings') // Use 'bookings' table instead of 'appointments'
        .where('userId', isEqualTo: userId)
        .get()
        .then((querySnapshot) {
      // If no bookings are found for this user, return
      if (querySnapshot.docs.isEmpty) {
        print("No bookings found for this user.");
        return;
      }

      querySnapshot.docs.forEach((doc) {
        // Get appointment date and time
        DateTime appointmentDateTime = (doc.data() as Map)['dateTime']
            .toDate(); // Assuming the 'dateTime' field is of Timestamp type

        // Calculate difference in days between current date and appointment date
        int daysDifference = appointmentDateTime.difference(now).inDays;

        // If appointment is after one day, create notification document
        if (daysDifference == 1) {
          firestore.collection('notifications').add({
            'userid': firestore
                .collection('Users')
                .doc(userId), // Reference to the user document
            'title': 'Reminder',
            'description': 'Tomorrow is your appointment!',
            'time_created': FieldValue.serverTimestamp(),
            'appointment_date': Timestamp.fromDate(
                appointmentDateTime), // Store the appointment date as Timestamp
          });
        }
      });
    });
  }

  // Call the function to create appointment reminder notification for the user
  createNotification(userId);

  // Since the above function is async, return a placeholder message immediately
  return "Processing notification creation...";
}

List<String> generateRepeatedTimes(
  List<String> selectedTimes,
  String repeatOption,
  String untilDate,
) {
  List<String> generatedTimes = [];

  // Convert untilDate string to DateTime
  DateTime? endDate = DateTime.tryParse(untilDate);
  if (endDate == null) return generatedTimes;

  // Loop through each selected time
  for (String timeString in selectedTimes) {
    DateTime? baseTime = DateTime.tryParse(timeString);
    if (baseTime == null) continue; // Skip invalid time formats

    // Add the first selected time
    generatedTimes.add(timeString);

    // Generate repeated times
    DateTime nextTime = baseTime;

    while (true) {
      // Increment based on repeatOption
      if (repeatOption == "Daily") {
        nextTime = nextTime.add(Duration(days: 1));
      } else if (repeatOption == "Weekly") {
        nextTime = nextTime.add(Duration(days: 7));
      } else if (repeatOption == "Monthly") {
        nextTime = DateTime(nextTime.year, nextTime.month + 1, nextTime.day,
            nextTime.hour, nextTime.minute);
      } else {
        break; // No repetition
      }

      // Stop when exceeding endDate
      if (nextTime.isAfter(endDate)) break;

      // Add to generated times
      generatedTimes.add(nextTime
          .toIso8601String()
          .substring(0, 16)); // Format: "YYYY-MM-DD HH:mm"
    }
  }

  return generatedTimes;
}

DateTime todate() {
  final DateTime now = DateTime.now();
  // Create a DateTime object that only contains the year, month, and day.
  final DateTime currentDate = DateTime(now.year, now.month, now.day);

  return currentDate;
}

DateTime timedatefix(
  String time,
  DateTime dAte,
) {
  // Parse the provided time string using the 'h:mm a' format.
  final DateTime parsedTime = DateFormat('h:mm a').parse(time);

  // Create and return a new DateTime using the date's year, month, and day,
  // and the parsed time's hour and minute.
  final DateTime updatedDate = DateTime(
    dAte.year,
    dAte.month,
    dAte.day,
    parsedTime.hour,
    parsedTime.minute,
  );

  // Debug print the updated date.
  print('Updated DateTime: $updatedDate');

  return updatedDate;
}

String datetostr(DateTime date) {
  return "${date.day.toString().padLeft(2, '0')}-${date.month.toString().padLeft(2, '0')}-${date.year.toString().substring(2)}";
}

FFUploadedFile? base64toFile(String base64Img) {
  final bytes = base64Decode(base64Img);
  final file = FFUploadedFile(bytes: bytes);
  return file;
}

DateTime setDateTime() {
  DateTime now = DateTime.now();
  DateTime currentDate =
      DateTime(now.year, now.month, now.day, 12, 0); // Set time to 12:00 PM
  return currentDate;
}

DateTime? newCustomFunction(DateTime? currenttime) {
  // only return date from current date and time in format of d/m/y
  if (currenttime == null) return null;
  return DateTime(currenttime.year, currenttime.month, currenttime.day);
}
