import 'dart:async';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';

import '/auth/base_auth_user_provider.dart';

import '/backend/push_notifications/push_notifications_handler.dart'
    show PushNotificationsHandler;
import '/main.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/lat_lng.dart';
import '/flutter_flow/place.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'serialization_util.dart';

import '/index.dart';

export 'package:go_router/go_router.dart';
export 'serialization_util.dart';

const kTransitionInfoKey = '__transition_info__';

GlobalKey<NavigatorState> appNavigatorKey = GlobalKey<NavigatorState>();

class AppStateNotifier extends ChangeNotifier {
  AppStateNotifier._();

  static AppStateNotifier? _instance;
  static AppStateNotifier get instance => _instance ??= AppStateNotifier._();

  BaseAuthUser? initialUser;
  BaseAuthUser? user;
  bool showSplashImage = true;
  String? _redirectLocation;

  /// Determines whether the app will refresh and build again when a sign
  /// in or sign out happens. This is useful when the app is launched or
  /// on an unexpected logout. However, this must be turned off when we
  /// intend to sign in/out and then navigate or perform any actions after.
  /// Otherwise, this will trigger a refresh and interrupt the action(s).
  bool notifyOnAuthChange = true;

  bool get loading => user == null || showSplashImage;
  bool get loggedIn => user?.loggedIn ?? false;
  bool get initiallyLoggedIn => initialUser?.loggedIn ?? false;
  bool get shouldRedirect => loggedIn && _redirectLocation != null;

  String getRedirectLocation() => _redirectLocation!;
  bool hasRedirect() => _redirectLocation != null;
  void setRedirectLocationIfUnset(String loc) => _redirectLocation ??= loc;
  void clearRedirectLocation() => _redirectLocation = null;

  /// Mark as not needing to notify on a sign in / out when we intend
  /// to perform subsequent actions (such as navigation) afterwards.
  void updateNotifyOnAuthChange(bool notify) => notifyOnAuthChange = notify;

  void update(BaseAuthUser newUser) {
    final shouldUpdate =
        user?.uid == null || newUser.uid == null || user?.uid != newUser.uid;
    initialUser ??= newUser;
    user = newUser;
    // Refresh the app on auth change unless explicitly marked otherwise.
    // No need to update unless the user has changed.
    if (notifyOnAuthChange && shouldUpdate) {
      notifyListeners();
    }
    // Once again mark the notifier as needing to update on auth change
    // (in order to catch sign in / out events).
    updateNotifyOnAuthChange(true);
  }

  void stopShowingSplashImage() {
    showSplashImage = false;
    notifyListeners();
  }
}

GoRouter createRouter(AppStateNotifier appStateNotifier) => GoRouter(
      initialLocation: '/',
      debugLogDiagnostics: true,
      refreshListenable: appStateNotifier,
      navigatorKey: appNavigatorKey,
      errorBuilder: (context, state) =>
          appStateNotifier.loggedIn ? NavBarPage() : HomePageWidget(),
      routes: [
        FFRoute(
          name: '_initialize',
          path: '/',
          builder: (context, _) =>
              appStateNotifier.loggedIn ? NavBarPage() : HomePageWidget(),
        ),
        FFRoute(
          name: HomeWidget.routeName,
          path: HomeWidget.routePath,
          requireAuth: true,
          builder: (context, params) =>
              params.isEmpty ? NavBarPage(initialPage: 'home') : HomeWidget(),
        ),
        FFRoute(
          name: DoctorDeatilsWidget.routeName,
          path: DoctorDeatilsWidget.routePath,
          builder: (context, params) => DoctorDeatilsWidget(
            docID: params.getParam(
              'docID',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['Users'],
            ),
          ),
        ),
        FFRoute(
          name: St2Widget.routeName,
          path: St2Widget.routePath,
          builder: (context, params) => St2Widget(),
        ),
        FFRoute(
          name: STResultsWidget.routeName,
          path: STResultsWidget.routePath,
          builder: (context, params) => STResultsWidget(),
        ),
        FFRoute(
          name: ProfileDoctorWidget.routeName,
          path: ProfileDoctorWidget.routePath,
          builder: (context, params) => ProfileDoctorWidget(),
        ),
        FFRoute(
          name: AuthVerifyEmailWidget.routeName,
          path: AuthVerifyEmailWidget.routePath,
          builder: (context, params) => AuthVerifyEmailWidget(
            email: params.getParam(
              'email',
              ParamType.String,
            ),
          ),
        ),
        FFRoute(
          name: AuthForgotPasswordWidget.routeName,
          path: AuthForgotPasswordWidget.routePath,
          builder: (context, params) => AuthForgotPasswordWidget(
            password: params.getParam(
              'password',
              ParamType.String,
            ),
            studentBool: params.getParam(
              'studentBool',
              ParamType.String,
            ),
          ),
        ),
        FFRoute(
          name: StudentProfileWidget.routeName,
          path: StudentProfileWidget.routePath,
          builder: (context, params) => params.isEmpty
              ? NavBarPage(initialPage: 'StudentProfile')
              : StudentProfileWidget(
                  docPic: params.getParam(
                    'docPic',
                    ParamType.String,
                  ),
                ),
        ),
        FFRoute(
          name: DoctorBookingWidget.routeName,
          path: DoctorBookingWidget.routePath,
          builder: (context, params) => DoctorBookingWidget(),
        ),
        FFRoute(
          name: Auth3Create2Widget.routeName,
          path: Auth3Create2Widget.routePath,
          builder: (context, params) => Auth3Create2Widget(),
        ),
        FFRoute(
          name: Auth3Login2Widget.routeName,
          path: Auth3Login2Widget.routePath,
          builder: (context, params) => Auth3Login2Widget(),
        ),
        FFRoute(
          name: Auth3Phone2Widget.routeName,
          path: Auth3Phone2Widget.routePath,
          builder: (context, params) => Auth3Phone2Widget(),
        ),
        FFRoute(
          name: Auth3VerifyPhone2Widget.routeName,
          path: Auth3VerifyPhone2Widget.routePath,
          builder: (context, params) => Auth3VerifyPhone2Widget(
            phoneNumber: params.getParam(
              'phoneNumber',
              ParamType.String,
            ),
          ),
        ),
        FFRoute(
          name: Auth3ForgotPassword2Widget.routeName,
          path: Auth3ForgotPassword2Widget.routePath,
          builder: (context, params) => Auth3ForgotPassword2Widget(),
        ),
        FFRoute(
          name: HomePageWidget.routeName,
          path: HomePageWidget.routePath,
          builder: (context, params) => HomePageWidget(),
        ),
        FFRoute(
          name: AssessmentCategoryWidget.routeName,
          path: AssessmentCategoryWidget.routePath,
          builder: (context, params) => AssessmentCategoryWidget(),
        ),
        FFRoute(
          name: AssessmentResultDepressioWidget.routeName,
          path: AssessmentResultDepressioWidget.routePath,
          builder: (context, params) => AssessmentResultDepressioWidget(
            score: params.getParam(
              'score',
              ParamType.double,
            ),
          ),
        ),
        FFRoute(
          name: ResultsViewMoreWidget.routeName,
          path: ResultsViewMoreWidget.routePath,
          builder: (context, params) => ResultsViewMoreWidget(),
        ),
        FFRoute(
          name: AlbumWidget.routeName,
          path: AlbumWidget.routePath,
          builder: (context, params) =>
              params.isEmpty ? NavBarPage(initialPage: 'Album') : AlbumWidget(),
        ),
        FFRoute(
          name: SmileRecognitionWidget.routeName,
          path: SmileRecognitionWidget.routePath,
          builder: (context, params) => SmileRecognitionWidget(),
        ),
        FFRoute(
          name: ReportRatingWidget.routeName,
          path: ReportRatingWidget.routePath,
          builder: (context, params) => ReportRatingWidget(
            booking: params.getParam(
              'booking',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['bookings'],
            ),
            userid: params.getParam(
              'userid',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['Users'],
            ),
            doctorid: params.getParam(
              'doctorid',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['Users'],
            ),
          ),
        ),
        FFRoute(
          name: EditStudentProfileWidget.routeName,
          path: EditStudentProfileWidget.routePath,
          builder: (context, params) => EditStudentProfileWidget(),
        ),
        FFRoute(
          name: EditNotificationSettingsWidget.routeName,
          path: EditNotificationSettingsWidget.routePath,
          builder: (context, params) => EditNotificationSettingsWidget(),
        ),
        FFRoute(
          name: SuccessWidget.routeName,
          path: SuccessWidget.routePath,
          builder: (context, params) => SuccessWidget(),
        ),
        FFRoute(
          name: ReservatonsPageWidget.routeName,
          path: ReservatonsPageWidget.routePath,
          builder: (context, params) => ReservatonsPageWidget(),
        ),
        FFRoute(
          name: STResultsCopyWidget.routeName,
          path: STResultsCopyWidget.routePath,
          builder: (context, params) => STResultsCopyWidget(),
        ),
        FFRoute(
          name: ReservationAppointmentWidget.routeName,
          path: ReservationAppointmentWidget.routePath,
          builder: (context, params) => ReservationAppointmentWidget(
            docID: params.getParam(
              'docID',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['Users'],
            ),
            doctorname: params.getParam(
              'doctorname',
              ParamType.String,
            ),
          ),
        ),
        FFRoute(
          name: AuthCreatAcountWidget.routeName,
          path: AuthCreatAcountWidget.routePath,
          builder: (context, params) => AuthCreatAcountWidget(
            studentBool: params.getParam(
              'studentBool',
              ParamType.bool,
            ),
          ),
        ),
        FFRoute(
          name: ArticlesWidget.routeName,
          path: ArticlesWidget.routePath,
          builder: (context, params) => params.isEmpty
              ? NavBarPage(initialPage: 'articles')
              : ArticlesWidget(),
        ),
        FFRoute(
          name: ArticleContentWidget.routeName,
          path: ArticleContentWidget.routePath,
          builder: (context, params) => ArticleContentWidget(),
        ),
        FFRoute(
          name: ArticleContentCopyWidget.routeName,
          path: ArticleContentCopyWidget.routePath,
          builder: (context, params) => ArticleContentCopyWidget(
            articleid: params.getParam(
              'articleid',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['Articles'],
            ),
          ),
        ),
        FFRoute(
          name: ChatAiScreenWidget.routeName,
          path: ChatAiScreenWidget.routePath,
          builder: (context, params) => ChatAiScreenWidget(),
        ),
        FFRoute(
          name: MyBookingsCopy2Widget.routeName,
          path: MyBookingsCopy2Widget.routePath,
          builder: (context, params) => params.isEmpty
              ? NavBarPage(initialPage: 'myBookingsCopy2')
              : NavBarPage(
                  initialPage: 'myBookingsCopy2',
                  page: MyBookingsCopy2Widget(),
                ),
        ),
        FFRoute(
          name: EditReservationWidget.routeName,
          path: EditReservationWidget.routePath,
          asyncParams: {
            'doctorDoc': getDoc(['Users'], UsersRecord.fromSnapshot),
          },
          builder: (context, params) => EditReservationWidget(
            bookingid: params.getParam(
              'bookingid',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['bookings'],
            ),
            id: params.getParam(
              'id',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['Users', 'availableslots'],
            ),
            doctorDoc: params.getParam(
              'doctorDoc',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: ApplicationStatusWidget.routeName,
          path: ApplicationStatusWidget.routePath,
          builder: (context, params) => ApplicationStatusWidget(),
        ),
        FFRoute(
          name: EditDoctorProfileWidget.routeName,
          path: EditDoctorProfileWidget.routePath,
          builder: (context, params) => EditDoctorProfileWidget(),
        ),
        FFRoute(
          name: DoctorCalenderWidget.routeName,
          path: DoctorCalenderWidget.routePath,
          builder: (context, params) => DoctorCalenderWidget(),
        ),
        FFRoute(
          name: BackgroundSoundCopyWidget.routeName,
          path: BackgroundSoundCopyWidget.routePath,
          builder: (context, params) => BackgroundSoundCopyWidget(),
        ),
        FFRoute(
          name: ChillSoundCopyCopy2Widget.routeName,
          path: ChillSoundCopyCopy2Widget.routePath,
          builder: (context, params) => NavBarPage(
            initialPage: '',
            page: ChillSoundCopyCopy2Widget(
              soundid: params.getParam(
                'soundid',
                ParamType.DocumentReference,
                isList: false,
                collectionNamePath: ['backgroundSound'],
              ),
            ),
          ),
        ),
        FFRoute(
          name: HomeCopyWidget.routeName,
          path: HomeCopyWidget.routePath,
          requireAuth: true,
          builder: (context, params) => HomeCopyWidget(),
        ),
        FFRoute(
          name: ReservatonsPageCopyWidget.routeName,
          path: ReservatonsPageCopyWidget.routePath,
          builder: (context, params) => ReservatonsPageCopyWidget(),
        ),
        FFRoute(
          name: ContactUsWidget.routeName,
          path: ContactUsWidget.routePath,
          builder: (context, params) => ContactUsWidget(),
        ),
        FFRoute(
          name: ChillSoundCopyCopy2Copy2Widget.routeName,
          path: ChillSoundCopyCopy2Copy2Widget.routePath,
          builder: (context, params) => NavBarPage(
            initialPage: '',
            page: ChillSoundCopyCopy2Copy2Widget(
              soundid: params.getParam(
                'soundid',
                ParamType.DocumentReference,
                isList: false,
                collectionNamePath: ['backgroundSound'],
              ),
            ),
          ),
        ),
        FFRoute(
          name: NeedMoreInfoWidget.routeName,
          path: NeedMoreInfoWidget.routePath,
          builder: (context, params) => NeedMoreInfoWidget(),
        ),
        FFRoute(
          name: DoctortimeslotsWidget.routeName,
          path: DoctortimeslotsWidget.routePath,
          builder: (context, params) => DoctortimeslotsWidget(),
        ),
        FFRoute(
          name: DoctorCalenderCopy2Widget.routeName,
          path: DoctorCalenderCopy2Widget.routePath,
          builder: (context, params) => DoctorCalenderCopy2Widget(),
        ),
        FFRoute(
          name: NotificationsWidget.routeName,
          path: NotificationsWidget.routePath,
          builder: (context, params) => NotificationsWidget(),
        ),
        FFRoute(
          name: SendReportWidget.routeName,
          path: SendReportWidget.routePath,
          builder: (context, params) => SendReportWidget(
            bookingId: params.getParam(
              'bookingId',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['bookings'],
            ),
          ),
        ),
        FFRoute(
          name: ReportRatingCopyWidget.routeName,
          path: ReportRatingCopyWidget.routePath,
          builder: (context, params) => ReportRatingCopyWidget(
            booking: params.getParam(
              'booking',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['bookings'],
            ),
            userid: params.getParam(
              'userid',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['Users'],
            ),
            doctorid: params.getParam(
              'doctorid',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['Users'],
            ),
          ),
        ),
        FFRoute(
          name: DoctorCalenderCopyWidget.routeName,
          path: DoctorCalenderCopyWidget.routePath,
          builder: (context, params) => DoctorCalenderCopyWidget(),
        ),
        FFRoute(
          name: DoctorCalenderCopy3Widget.routeName,
          path: DoctorCalenderCopy3Widget.routePath,
          builder: (context, params) => DoctorCalenderCopy3Widget(),
        ),
        FFRoute(
          name: DoctorCalenderEditViewWidget.routeName,
          path: DoctorCalenderEditViewWidget.routePath,
          builder: (context, params) => DoctorCalenderEditViewWidget(),
        ),
        FFRoute(
          name: UpdatecalanderWidget.routeName,
          path: UpdatecalanderWidget.routePath,
          builder: (context, params) => UpdatecalanderWidget(),
        ),
        FFRoute(
          name: SchedualemengmentWidget.routeName,
          path: SchedualemengmentWidget.routePath,
          builder: (context, params) => SchedualemengmentWidget(),
        ),
        FFRoute(
          name: ConfirmationSchedualeWidget.routeName,
          path: ConfirmationSchedualeWidget.routePath,
          builder: (context, params) => ConfirmationSchedualeWidget(),
        ),
        FFRoute(
          name: ConfirmationSchedualeCopyWidget.routeName,
          path: ConfirmationSchedualeCopyWidget.routePath,
          builder: (context, params) => ConfirmationSchedualeCopyWidget(),
        ),
        FFRoute(
          name: DoctorCalenderUpdatedWidget.routeName,
          path: DoctorCalenderUpdatedWidget.routePath,
          builder: (context, params) => DoctorCalenderUpdatedWidget(),
        ),
        FFRoute(
          name: DoctorBookingCopyWidget.routeName,
          path: DoctorBookingCopyWidget.routePath,
          builder: (context, params) => DoctorBookingCopyWidget(),
        ),
        FFRoute(
          name: IntrosmileWidget.routeName,
          path: IntrosmileWidget.routePath,
          builder: (context, params) => IntrosmileWidget(),
        ),
        FFRoute(
          name: CameraWidget.routeName,
          path: CameraWidget.routePath,
          builder: (context, params) => CameraWidget(
            smileid: params.getParam(
              'smileid',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['SmileAlbum'],
            ),
          ),
        ),
        FFRoute(
          name: St3Widget.routeName,
          path: St3Widget.routePath,
          builder: (context, params) => St3Widget(),
        ),
        FFRoute(
          name: St4Widget.routeName,
          path: St4Widget.routePath,
          builder: (context, params) => St4Widget(),
        ),
        FFRoute(
          name: AssessmentResultanxietyWidget.routeName,
          path: AssessmentResultanxietyWidget.routePath,
          builder: (context, params) => AssessmentResultanxietyWidget(
            score: params.getParam(
              'score',
              ParamType.double,
            ),
          ),
        ),
        FFRoute(
          name: AssessmentResultsleepWidget.routeName,
          path: AssessmentResultsleepWidget.routePath,
          builder: (context, params) => AssessmentResultsleepWidget(
            score: params.getParam(
              'score',
              ParamType.double,
            ),
          ),
        ),
        FFRoute(
          name: SEHAinstructionsWidget.routeName,
          path: SEHAinstructionsWidget.routePath,
          builder: (context, params) => SEHAinstructionsWidget(),
        ),
        FFRoute(
          name: InformationFormWidget.routeName,
          path: InformationFormWidget.routePath,
          builder: (context, params) => InformationFormWidget(),
        ),
        FFRoute(
          name: ConfirmationWidget.routeName,
          path: ConfirmationWidget.routePath,
          builder: (context, params) => ConfirmationWidget(),
        ),
        FFRoute(
          name: YourPicWidget.routeName,
          path: YourPicWidget.routePath,
          builder: (context, params) => YourPicWidget(
            smileid: params.getParam(
              'smileid',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['SmileAlbum'],
            ),
          ),
        ),
        FFRoute(
          name: ChillSoundCopyCopy2CopyWidget.routeName,
          path: ChillSoundCopyCopy2CopyWidget.routePath,
          builder: (context, params) => NavBarPage(
            initialPage: '',
            page: ChillSoundCopyCopy2CopyWidget(
              soundid: params.getParam(
                'soundid',
                ParamType.DocumentReference,
                isList: false,
                collectionNamePath: ['backgroundSound'],
              ),
            ),
          ),
        ),
        FFRoute(
          name: ZoomlinkWidget.routeName,
          path: ZoomlinkWidget.routePath,
          builder: (context, params) => ZoomlinkWidget(),
        ),
        FFRoute(
          name: ZoompasscodeWidget.routeName,
          path: ZoompasscodeWidget.routePath,
          builder: (context, params) => ZoompasscodeWidget(
            bookingid: params.getParam(
              'bookingid',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['bookings'],
            ),
          ),
        ),
        FFRoute(
          name: ClinicsWidget.routeName,
          path: ClinicsWidget.routePath,
          builder: (context, params) => ClinicsWidget(),
        ),
        FFRoute(
          name: PsychotherapyClinicWidget.routeName,
          path: PsychotherapyClinicWidget.routePath,
          builder: (context, params) => PsychotherapyClinicWidget(),
        ),
        FFRoute(
          name: PsychiatryClinicWidget.routeName,
          path: PsychiatryClinicWidget.routePath,
          builder: (context, params) => PsychiatryClinicWidget(),
        ),
        FFRoute(
          name: SocialServicesClinicWidget.routeName,
          path: SocialServicesClinicWidget.routePath,
          builder: (context, params) => SocialServicesClinicWidget(),
        ),
        FFRoute(
          name: PicAlbumWidget.routeName,
          path: PicAlbumWidget.routePath,
          builder: (context, params) => PicAlbumWidget(),
        ),
        FFRoute(
          name: GgWidget.routeName,
          path: GgWidget.routePath,
          builder: (context, params) => GgWidget(),
        ),
        FFRoute(
          name: MyBookingsCopy2CopyWidget.routeName,
          path: MyBookingsCopy2CopyWidget.routePath,
          builder: (context, params) => MyBookingsCopy2CopyWidget(),
        ),
        FFRoute(
          name: SuccessCopyWidget.routeName,
          path: SuccessCopyWidget.routePath,
          builder: (context, params) => SuccessCopyWidget(),
        )
      ].map((r) => r.toRoute(appStateNotifier)).toList(),
    );

extension NavParamExtensions on Map<String, String?> {
  Map<String, String> get withoutNulls => Map.fromEntries(
        entries
            .where((e) => e.value != null)
            .map((e) => MapEntry(e.key, e.value!)),
      );
}

extension NavigationExtensions on BuildContext {
  void goNamedAuth(
    String name,
    bool mounted, {
    Map<String, String> pathParameters = const <String, String>{},
    Map<String, String> queryParameters = const <String, String>{},
    Object? extra,
    bool ignoreRedirect = false,
  }) =>
      !mounted || GoRouter.of(this).shouldRedirect(ignoreRedirect)
          ? null
          : goNamed(
              name,
              pathParameters: pathParameters,
              queryParameters: queryParameters,
              extra: extra,
            );

  void pushNamedAuth(
    String name,
    bool mounted, {
    Map<String, String> pathParameters = const <String, String>{},
    Map<String, String> queryParameters = const <String, String>{},
    Object? extra,
    bool ignoreRedirect = false,
  }) =>
      !mounted || GoRouter.of(this).shouldRedirect(ignoreRedirect)
          ? null
          : pushNamed(
              name,
              pathParameters: pathParameters,
              queryParameters: queryParameters,
              extra: extra,
            );

  void safePop() {
    // If there is only one route on the stack, navigate to the initial
    // page instead of popping.
    if (canPop()) {
      pop();
    } else {
      go('/');
    }
  }
}

extension GoRouterExtensions on GoRouter {
  AppStateNotifier get appState => AppStateNotifier.instance;
  void prepareAuthEvent([bool ignoreRedirect = false]) =>
      appState.hasRedirect() && !ignoreRedirect
          ? null
          : appState.updateNotifyOnAuthChange(false);
  bool shouldRedirect(bool ignoreRedirect) =>
      !ignoreRedirect && appState.hasRedirect();
  void clearRedirectLocation() => appState.clearRedirectLocation();
  void setRedirectLocationIfUnset(String location) =>
      appState.updateNotifyOnAuthChange(false);
}

extension _GoRouterStateExtensions on GoRouterState {
  Map<String, dynamic> get extraMap =>
      extra != null ? extra as Map<String, dynamic> : {};
  Map<String, dynamic> get allParams => <String, dynamic>{}
    ..addAll(pathParameters)
    ..addAll(uri.queryParameters)
    ..addAll(extraMap);
  TransitionInfo get transitionInfo => extraMap.containsKey(kTransitionInfoKey)
      ? extraMap[kTransitionInfoKey] as TransitionInfo
      : TransitionInfo.appDefault();
}

class FFParameters {
  FFParameters(this.state, [this.asyncParams = const {}]);

  final GoRouterState state;
  final Map<String, Future<dynamic> Function(String)> asyncParams;

  Map<String, dynamic> futureParamValues = {};

  // Parameters are empty if the params map is empty or if the only parameter
  // present is the special extra parameter reserved for the transition info.
  bool get isEmpty =>
      state.allParams.isEmpty ||
      (state.allParams.length == 1 &&
          state.extraMap.containsKey(kTransitionInfoKey));
  bool isAsyncParam(MapEntry<String, dynamic> param) =>
      asyncParams.containsKey(param.key) && param.value is String;
  bool get hasFutures => state.allParams.entries.any(isAsyncParam);
  Future<bool> completeFutures() => Future.wait(
        state.allParams.entries.where(isAsyncParam).map(
          (param) async {
            final doc = await asyncParams[param.key]!(param.value)
                .onError((_, __) => null);
            if (doc != null) {
              futureParamValues[param.key] = doc;
              return true;
            }
            return false;
          },
        ),
      ).onError((_, __) => [false]).then((v) => v.every((e) => e));

  dynamic getParam<T>(
    String paramName,
    ParamType type, {
    bool isList = false,
    List<String>? collectionNamePath,
    StructBuilder<T>? structBuilder,
  }) {
    if (futureParamValues.containsKey(paramName)) {
      return futureParamValues[paramName];
    }
    if (!state.allParams.containsKey(paramName)) {
      return null;
    }
    final param = state.allParams[paramName];
    // Got parameter from `extras`, so just directly return it.
    if (param is! String) {
      return param;
    }
    // Return serialized value.
    return deserializeParam<T>(
      param,
      type,
      isList,
      collectionNamePath: collectionNamePath,
      structBuilder: structBuilder,
    );
  }
}

class FFRoute {
  const FFRoute({
    required this.name,
    required this.path,
    required this.builder,
    this.requireAuth = false,
    this.asyncParams = const {},
    this.routes = const [],
  });

  final String name;
  final String path;
  final bool requireAuth;
  final Map<String, Future<dynamic> Function(String)> asyncParams;
  final Widget Function(BuildContext, FFParameters) builder;
  final List<GoRoute> routes;

  GoRoute toRoute(AppStateNotifier appStateNotifier) => GoRoute(
        name: name,
        path: path,
        redirect: (context, state) {
          if (appStateNotifier.shouldRedirect) {
            final redirectLocation = appStateNotifier.getRedirectLocation();
            appStateNotifier.clearRedirectLocation();
            return redirectLocation;
          }

          if (requireAuth && !appStateNotifier.loggedIn) {
            appStateNotifier.setRedirectLocationIfUnset(state.uri.toString());
            return '/HomePage';
          }
          return null;
        },
        pageBuilder: (context, state) {
          fixStatusBarOniOS16AndBelow(context);
          final ffParams = FFParameters(state, asyncParams);
          final page = ffParams.hasFutures
              ? FutureBuilder(
                  future: ffParams.completeFutures(),
                  builder: (context, _) => builder(context, ffParams),
                )
              : builder(context, ffParams);
          final child = appStateNotifier.loading
              ? Center(
                  child: SizedBox(
                    width: 50.0,
                    height: 50.0,
                    child: CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation<Color>(
                        FlutterFlowTheme.of(context).primary,
                      ),
                    ),
                  ),
                )
              : PushNotificationsHandler(child: page);

          final transitionInfo = state.transitionInfo;
          return transitionInfo.hasTransition
              ? CustomTransitionPage(
                  key: state.pageKey,
                  child: child,
                  transitionDuration: transitionInfo.duration,
                  transitionsBuilder:
                      (context, animation, secondaryAnimation, child) =>
                          PageTransition(
                    type: transitionInfo.transitionType,
                    duration: transitionInfo.duration,
                    reverseDuration: transitionInfo.duration,
                    alignment: transitionInfo.alignment,
                    child: child,
                  ).buildTransitions(
                    context,
                    animation,
                    secondaryAnimation,
                    child,
                  ),
                )
              : MaterialPage(key: state.pageKey, child: child);
        },
        routes: routes,
      );
}

class TransitionInfo {
  const TransitionInfo({
    required this.hasTransition,
    this.transitionType = PageTransitionType.fade,
    this.duration = const Duration(milliseconds: 300),
    this.alignment,
  });

  final bool hasTransition;
  final PageTransitionType transitionType;
  final Duration duration;
  final Alignment? alignment;

  static TransitionInfo appDefault() => TransitionInfo(hasTransition: false);
}

class RootPageContext {
  const RootPageContext(this.isRootPage, [this.errorRoute]);
  final bool isRootPage;
  final String? errorRoute;

  static bool isInactiveRootPage(BuildContext context) {
    final rootPageContext = context.read<RootPageContext?>();
    final isRootPage = rootPageContext?.isRootPage ?? false;
    final location = GoRouterState.of(context).uri.toString();
    return isRootPage &&
        location != '/' &&
        location != rootPageContext?.errorRoute;
  }

  static Widget wrap(Widget child, {String? errorRoute}) => Provider.value(
        value: RootPageContext(true, errorRoute),
        child: child,
      );
}

extension GoRouterLocationExtension on GoRouter {
  String getCurrentLocation() {
    final RouteMatch lastMatch = routerDelegate.currentConfiguration.last;
    final RouteMatchList matchList = lastMatch is ImperativeRouteMatch
        ? lastMatch.matches
        : routerDelegate.currentConfiguration;
    return matchList.uri.toString();
  }
}
