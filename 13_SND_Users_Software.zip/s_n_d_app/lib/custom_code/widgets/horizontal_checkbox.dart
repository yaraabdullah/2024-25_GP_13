// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '/custom_code/actions/index.dart'; // Imports custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

class HorizontalCheckbox extends StatefulWidget {
  final String options; // Change to String
  final String initialSelections; // Change to String
  final double width;
  final double height;

  // Constructor with default values
  HorizontalCheckbox({
    this.options =
        'Option 1, Option 2, Option 3, Option 4, Option 5, Option 6, Option 7, Option 8', // Default options
    this.initialSelections =
        'false, false, false, false, false, false, false, false', // Default initialSelections
    this.width = 400.0, // Default width
    this.height = 60.0, // Default height
  });

  @override
  _HorizontalCheckboxState createState() => _HorizontalCheckboxState();
}

class _HorizontalCheckboxState extends State<HorizontalCheckbox> {
  late List<bool> selections;
  late List<String> optionsList;
  late List<bool> initialSelectionsList;

  @override
  void initState() {
    super.initState();

    // Convert the comma-separated strings into lists
    optionsList = widget.options.split(',').map((e) => e.trim()).toList();
    initialSelectionsList = widget.initialSelections
        .split(',')
        .map((e) => e.trim().toLowerCase() == 'true')
        .toList();

    // Ensure that the selections list matches the number of options
    selections = List.from(initialSelectionsList);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: widget.width,
      height: widget.height,
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: optionsList.asMap().entries.map((entry) {
            int idx = entry.key;
            String option = entry.value;
            return Row(
              children: [
                Checkbox(
                  value: selections[idx],
                  onChanged: (bool? value) {
                    setState(() {
                      selections[idx] = value!;
                    });
                  },
                ),
                Text(option),
              ],
            );
          }).toList(),
        ),
      ),
    );
  }
}

// Set your widget name, define your parameter, and then add the
// boilerplate code using the green button on the right!
