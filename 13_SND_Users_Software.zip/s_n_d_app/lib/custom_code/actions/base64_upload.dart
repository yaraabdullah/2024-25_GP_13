// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'dart:convert';
import 'package:firebase_storage/firebase_storage.dart';
import 'dart:typed_data'; // Required for Uint8List

Future<String?> base64Upload(String base64image) async {
  try {
    // Decode the base64 image
    Uint8List bytes = base64Decode(base64image);

    // Generate a unique file name
    final fileName = '${DateTime.now().millisecondsSinceEpoch}.png';

    // Upload to Firebase Storage
    final ref = FirebaseStorage.instance.ref().child('smileAlbum/$fileName');
    final uploadTask = ref.putData(bytes);
    final snapshot = await uploadTask;

    // Get download URL
    final downloadUrl = await snapshot.ref.getDownloadURL();
    return downloadUrl;
  } catch (e) {
    print('Upload failed: $e');
    return null;
  }
}

// Set your action name, define your arguments and return parameter,
// and then add the boilerplate code using the green button on the right!
