// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'index.dart'; // Imports other custom actions

import 'package:mime/mime.dart' as mime;
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:file_saver/file_saver.dart';
import 'package:collection/collection.dart';

Future report(
  String? url,
  String filename,
) async {
  var bytes = null;
  var extension = null;

  if (url == null && bytes == null) {
    throw 'No file/url to download';
  }
  if (url != null && bytes != null) {
    throw 'Only one of url or bytes can be provided';
  }

  String? mimeType;

// First, check if the extension is specified in the filename to avoid needing
// to scan the file to determine the mime type and extension
  mimeType = mime.lookupMimeType(filename);

// If a URL is provided, download the file and determine the mime type from
// the response headers.
  if (url != null && url.isNotEmpty) {
    final response = await http.get(Uri.parse(url));
    bytes = response.bodyBytes;
    mimeType ??= response.headers['content-type'];
  }

// If a file is provided and the filename does not have an extension, scan the
// file header bytes to determine the mime type and extension.
  if (bytes != null && bytes.isNotEmpty) {
// Grab the first 32 bytes of the file to determine the mime type
    if (mimeType == null) {
      final headerBytes = bytes.take(32).toList();
      mimeType ??= mime.lookupMimeType(filename, headerBytes: headerBytes);
    }
  }

  MimeType mimeTypeObj =
      MimeType.values.firstWhereOrNull((e) => e.type == mimeType) ??
          MimeType.other;

  if (kIsWeb) {
    await FileSaver.instance.saveFile(
      bytes: bytes,
      name: filename.substring(0,
          filename.contains('.') ? filename.lastIndexOf('.') : filename.length),
      ext: extension ?? mime.extensionFromMime(mimeType ?? ''),
      mimeType: mimeTypeObj,
    );
  } else {
    await FileSaver.instance.saveAs(
      bytes: bytes,
      name: filename,
      ext: extension ?? mime.extensionFromMime(mimeType ?? ''),
      mimeType: mimeTypeObj,
    );
  }
}
// Set your action name, define your arguments and return parameter,
// and then add the boilerplate code using the green button on the right!
