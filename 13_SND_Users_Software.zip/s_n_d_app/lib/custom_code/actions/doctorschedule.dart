// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'dart:developer';

/// Generates a doctor's schedule from [startDate] to [endDate] using the slots provided
/// for each weekday. The variables [sunday], [monday], [tuesday], [wednesday] and [thursday]
/// are lists of time slot strings (e.g. ["09:00", "10:00"]) for those specific days.
///
/// If a day has an empty slot list, it will be skipped and no schedule will be created for that day.
Future<void> doctorschedule(
  String doctorId,
  DateTime startDate,
  DateTime endDate,
  List<String> sunday,
  List<String> monday,
  List<String> tuesday,
  List<String> wednesday,
  List<String> thursday,
) async {
  final DateFormat formatter = DateFormat('yyyy-MM-dd');

  // Mapping weekday names (in lowercase) to their respective slot lists.
  final Map<String, List<String>> weekdaySlots = {
    'sunday': sunday,
    'monday': monday,
    'tuesday': tuesday,
    'wednesday': wednesday,
    'thursday': thursday,
  };

  // Iterate through each date from startDate to endDate (inclusive)
  for (DateTime date = startDate;
      date.isBefore(endDate) || date.isAtSameMomentAs(endDate);
      date = date.add(Duration(days: 1))) {
    // Get the weekday name in lowercase (e.g., "monday")
    String weekdayName = DateFormat('EEEE').format(date).toLowerCase();

    // Check if slots are defined for this weekday and the list is not empty
    if (weekdaySlots.containsKey(weekdayName) &&
        weekdaySlots[weekdayName]!.isNotEmpty) {
      // Create the list of slot objects with time and availability flag
      List<Map<String, dynamic>> slots = weekdaySlots[weekdayName]!
          .map((time) => {"time": time, "available": true})
          .toList();

      // Format the date as a string (YYYY-MM-DD) for the Firestore document ID
      String dateString = formatter.format(date);

      // Reference the Firestore document in the doctor's schedule subcollection
      DocumentReference scheduleDoc = FirebaseFirestore.instance
          .collection('Users')
          .doc(doctorId)
          .collection('schedule')
          .doc(dateString);

      // Schedule data to be written
      Map<String, dynamic> scheduleData = {
        "date": dateString,
        "weekday": weekdayName,
        "slots": slots,
      };

      // Write the schedule document to Firestore
      await scheduleDoc.set(scheduleData);
    }
  }
}
