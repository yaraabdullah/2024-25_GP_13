// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'dart:developer';

Future<void> scheduleforday(String userId, DateTime date) async {
  try {
    // Reference to Firestore document path
    final DateFormat formatter = DateFormat('yyyy-MM-dd');
    String dateString = formatter.format(date);
    DocumentReference scheduleRef = FirebaseFirestore.instance
        .collection('Users')
        .doc(userId)
        .collection('schedule')
        .doc(dateString);

    DocumentSnapshot scheduleSnapshot = await scheduleRef.get();
    log(scheduleSnapshot.toString());
    print(scheduleSnapshot.toString());
    if (scheduleSnapshot.exists) {
      // Extract the list of slots, assuming each slot is a map with a 'time' field
      List<String> slots = (scheduleSnapshot.get('slots') as List<dynamic>?)
              ?.map((slot) => slot['time'].toString())
              .toList() ??
          [];

      // Update the app state
      FFAppState().slotsforupdate = slots;
    } else {
      print('No slots found for the given date.');
      FFAppState().slotsforupdate = [];
    }
  } catch (e) {
    print('Error fetching slots: $e');
  }
}
