// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'dart:developer';
import 'package:http/http.dart' as http;

Future<void> updatespecific(String userId, DateTime date, List<String> newTimes,
    String doctorName) async {
  try {
    // Format date for Firestore and API separately
    final DateFormat firestoreFormatter = DateFormat('yyyy-MM-dd');
    final DateFormat weekdayFormatter = DateFormat('EEEE'); // full weekday name
    final DateFormat apiDateFormatter =
        DateFormat('dd-MM-yy'); // API date format

    String dateString = firestoreFormatter.format(date);
    String weekdayName = weekdayFormatter.format(date);
    String apiDateString = apiDateFormatter.format(date);

    // Reference to the doctor's schedule document
    DocumentReference scheduleRef = FirebaseFirestore.instance
        .collection('Users')
        .doc(userId)
        .collection('schedule')
        .doc(dateString);

    // Delete the existing schedule document
    await scheduleRef.delete();
    log('Deleted existing schedule for $dateString');

    // Convert list of times into slot maps
    List<Map<String, dynamic>> slots = newTimes
        .map((time) => {
              'time': time,
              'available': true, // Default availability
              'updateTime': Timestamp.now(), // Timestamp for tracking updates
            })
        .toList();

    // Create new schedule data
    Map<String, dynamic> scheduleData = {
      "date": dateString,
      "weekday": weekdayName,
      "slots": slots,
    };

    // Insert the new schedule document
    await scheduleRef.set(scheduleData);
    log('Inserted new schedule for $dateString');

    // Update AppState with new slots
    FFAppState().update(() {
      FFAppState().slotsforupdate = newTimes;
    });
    log('Updated AppState slotsforupdate: ${FFAppState().slotsforupdate}');
    print(userId);
    // Query bookings for the doctor on this date
    QuerySnapshot bookingsSnapshot = await FirebaseFirestore.instance
        .collection('bookings')
        .where('docid',
            isEqualTo: FirebaseFirestore.instance.collection('Users').doc(
                userId)) //.where('doctor', isEqualTo: FirebaseFirestore.instance.collection('Users').doc(userId))
        .where('date',
            isEqualTo:
                apiDateString) // assuming the booking date is stored in this format
        .get();

    // Iterate over each booking document
    for (var doc in bookingsSnapshot.docs) {
      var bookingData = doc.data() as Map<String, dynamic>;
      String bookedSlot = bookingData['slottime'];
      print(bookedSlot);
      // If the slot from the booking is not in the updated newTimes, cancel the booking
      if (!newTimes.contains(bookedSlot)) {
        print("slot in not new slot");
        // Retrieve booking parameters
        String bookedBy = bookingData['bookedby'] ?? "";
        String bookedUser = bookingData['user'] ?? "";
        DocumentReference id = bookingData['userId'] ?? "";
        print(id);
        // Combine the date and time strings.
        String dateTimeStr = "$apiDateString $bookedSlot";

        // Define the format for the combined string.
        DateFormat formatter = DateFormat("yy-MM-dd hh:mm a");
        // Parse the string into a DateTime object.
        DateTime dateTime = formatter.parse(dateTimeStr);

        // Prepare payload for the cancellation API
        Map<String, dynamic> payload = {
          'bookedby': bookedBy,
          'user': bookedUser,
          'date': apiDateString,
          'time': bookedSlot,
          'doctor_name': doctorName,
        };

        await FirebaseFirestore.instance.collection('notifications').add({
          'title': 'Appointment Cancelled',
          'description': 'Your appointment has been cancelled.',
          'time_created': Timestamp.now(),
          'appointment_time': Timestamp.fromDate(dateTime),
          'appointment_date': Timestamp.fromDate(dateTime),
          'userid': id,
        }).then((_) {
          print("Notification added.");
        }).catchError((error) {
          print("Failed to add notification: $error");
        });

        // Call the cancellation API
        var response = await http.post(
          Uri.parse('https://sndmentalhealth.com/send-email/cancelled'),
          headers: {
            'Content-Type': 'application/json',
            'x-api-token': "dummy-token-12345"
          },
          body: json.encode(payload),
        );

        if (response.statusCode == 200) {
          log('Cancellation email sent for booking ${doc.id}');
        } else {
          log('Failed to send cancellation email for booking ${doc.id}. Status code: ${response.statusCode}');
        }
      }
    }
  } catch (e) {
    log('Error updating slots and processing cancellations: $e');
  }
}
