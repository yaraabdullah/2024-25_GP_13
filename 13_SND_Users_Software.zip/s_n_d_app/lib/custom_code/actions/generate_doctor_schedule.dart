// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'dart:developer';

Future<void> generateDoctorSchedule(
  String doctorId,
  DateTime startDate,
  DateTime endDate,
  List<String> timeSlots, // List of time strings like ["09:00", "10:00"]
  String repeat, // "daily", "weekly", "monthly"
) async {
  // Formatter to convert DateTime to a string (YYYY-MM-DD)
  log("time: $timeSlots");
  final DateFormat formatter = DateFormat('yyyy-MM-dd');

  // Generate slots list from provided times
  final List<Map<String, dynamic>> slots =
      timeSlots.map((time) => {"time": time, "available": true}).toList();

  // Loop through the date range based on the repeat frequency
  for (DateTime date = startDate;
      date.isBefore(endDate) || date.isAtSameMomentAs(endDate);
      date = getNextDate(date, repeat)) {
    // Format the date as a string for Firestore
    String dateString = formatter.format(date);

    // Reference to Firestore document
    DocumentReference scheduleDoc = FirebaseFirestore.instance
        .collection('Users')
        .doc(doctorId)
        .collection('schedule')
        .doc(dateString);

    // Schedule data
    Map<String, dynamic> scheduleData = {
      "date": dateString,
      "repeat": repeat,
      "slots": slots,
    };

    // Write the schedule document to Firestore
    await scheduleDoc.set(scheduleData);
  }
}

// Function to get the next date based on repeat frequency
DateTime getNextDate(DateTime currentDate, String repeat) {
  switch (repeat) {
    case "weekly":
      return currentDate.add(Duration(days: 7));
    case "monthly":
      return DateTime(currentDate.year, currentDate.month + 1, currentDate.day);
    case "daily":
    default:
      return currentDate.add(Duration(days: 1));
  }
}

// Set your action name, define your arguments and return parameter,
// and then add the boilerplate code using the green button on the right!
