// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

/// Queries available slots for a given doctor and date,
/// and returns a JSON string containing a list of time strings for available slots.
///
/// - If the requested date is before today, it returns an empty list.
/// - If the requested date is today, only slots with a time strictly greater than the current time are returned.
/// - For future dates, all available slots are returned.
Future<String> queryAvailableSlotTimes(String doctorId, DateTime date) async {
  // Formatter to convert DateTime to "yyyy-MM-dd" format.
  final DateFormat formatter = DateFormat('yyyy-MM-dd');
  String dateString = formatter.format(date);

  // Get current date and time.
  DateTime now = DateTime.now();
  // Today's date at midnight.
  DateTime today = DateTime(now.year, now.month, now.day);
  // Requested date at midnight.
  DateTime requestedDay = DateTime(date.year, date.month, date.day);

  // If the requested date is before today, return an empty list.
  if (requestedDay.isBefore(today)) {
    print(
        'Requested date $dateString is in the past. Returning no available slots.');
    FFAppState().slots = [];
    return jsonEncode([]);
  }

  print(
      'Querying available slot times for doctorId: $doctorId on date: $dateString');

  // Reference to the schedule document in the doctor's subcollection.
  DocumentReference docRef = FirebaseFirestore.instance
      .collection('Users')
      .doc(doctorId)
      .collection('schedule')
      .doc(dateString);

  try {
    // Fetch the document snapshot from Firestore.
    DocumentSnapshot docSnapshot = await docRef.get();

    if (!docSnapshot.exists) {
      print('No schedule document found for date: $dateString');
      FFAppState().slots = [];
      return jsonEncode([]);
    }

    // Ensure the document data is valid.
    Map<String, dynamic>? data = docSnapshot.data() as Map<String, dynamic>?;
    if (data == null || !data.containsKey('slots')) {
      print('No valid data found in document for date: $dateString');
      FFAppState().slots = [];
      return jsonEncode([]);
    }

    final slots = data['slots'] as List<dynamic>;
    List<String> availableTimes = [];

    // If the requested date is today, filter slots to include only those strictly after current time.
    if (formatter.format(date) == formatter.format(now)) {
      // Current time truncated to minute precision.
      DateTime currentTime =
          DateTime(now.year, now.month, now.day, now.hour, now.minute);
      print('Current time for filtering: $currentTime');

      availableTimes = slots
          .where((slot) {
            if (slot is Map<String, dynamic>) {
              bool isAvailable = slot['available'] == true;
              bool hasTime = slot.containsKey('time');
              if (!isAvailable || !hasTime) return false;

              String timeStr = slot['time'] as String;
              DateTime slotDateTime;
              try {
                if (timeStr.contains("AM") || timeStr.contains("PM")) {
                  // Parse time with AM/PM using "h:mm a" format.
                  DateFormat timeFormatter = DateFormat("h:mm a");
                  DateTime parsedTime = timeFormatter.parse(timeStr);
                  slotDateTime = DateTime(date.year, date.month, date.day,
                      parsedTime.hour, parsedTime.minute);
                } else {
                  // Otherwise, assume it's in "HH:mm" format.
                  List<String> parts = timeStr.split(":");
                  if (parts.length < 2) return false;
                  int? hour = int.tryParse(parts[0]);
                  int? minute = int.tryParse(parts[1]);
                  if (hour == null || minute == null) {
                    print('Could not parse time: $timeStr');
                    return false;
                  }
                  slotDateTime =
                      DateTime(date.year, date.month, date.day, hour, minute);
                }
              } catch (e) {
                print('Error parsing time: $timeStr, error: $e');
                return false;
              }

              print(
                  'Slot time: $slotDateTime compared to current time: $currentTime');
              // Only include the slot if its time is strictly after the current time.
              return slotDateTime.isAfter(currentTime);
            }
            return false;
          })
          .map((slot) => slot['time'] as String)
          .toList();
    } else {
      // For future dates, include all available slots.
      availableTimes = slots
          .where((slot) {
            if (slot is Map<String, dynamic>) {
              return slot['available'] == true && slot.containsKey('time');
            }
            return false;
          })
          .map((slot) => slot['time'] as String)
          .toList();
    }
    FFAppState().slots = availableTimes;
    print('Available times for $dateString: $availableTimes');
    String jsonResponse = jsonEncode(availableTimes);
    print('JSON Response: $jsonResponse');
    return jsonResponse;
  } catch (e) {
    print('Error querying available slot times: $e');
    return jsonEncode([]);
  }
}
