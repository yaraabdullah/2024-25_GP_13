// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:cloud_firestore/cloud_firestore.dart';

Future<void> checkAndCreateNotificationForUser(String userId) async {
  final currentDate = DateTime.now();
  final oneDayBefore = currentDate.add(Duration(days: 1));

  // Fetch all bookings for the current user from Firestore
  QuerySnapshot querySnapshot = await FirebaseFirestore.instance
      .collection('bookings')
      .where('userId', isEqualTo: userId) // Filter by user ID
      .get();

  for (var doc in querySnapshot.docs) {
    String appointmentDateString =
        doc['date']; // Assuming 'date' is in String format
    DateTime appointmentDate =
        DateTime.parse(appointmentDateString); // Convert string to DateTime

    // Check if the appointment is exactly one day away
    if (appointmentDate.isAtSameMomentAs(oneDayBefore)) {
      // Create a notification document in Firestore
      await FirebaseFirestore.instance.collection('notifications').add({
        'title': 'Reminder',
        'description': 'Tomorrow is your appointment!',
        'time_created': Timestamp.now(),
        'userid': FirebaseFirestore.instance
            .collection('Users')
            .doc(userId), // Reference to user
        'appointment_time': doc[
            'time'], // Assuming 'time' is stored in a format that can be used directly
        'appointment_date': Timestamp.fromDate(
            appointmentDate), // Convert DateTime to Timestamp
      });
    }
  }
}

// Set your action name, define your arguments and return parameter,
// and then add the boilerplate code using the green button on the right!
