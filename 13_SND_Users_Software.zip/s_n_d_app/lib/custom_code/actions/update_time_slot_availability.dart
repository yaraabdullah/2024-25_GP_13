// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:cloud_firestore/cloud_firestore.dart';

/// Updates the availability of a specific time slot for a doctor on a given date.
/// The slot will be marked as booked (false).
Future<void> updateTimeSlotAvailability(
    String doctorId, DateTime dateString, String timeSlot) async {
  try {
    // Reference to Firestore collection.
    final DateFormat formatter = DateFormat('yyyy-MM-dd');
    String datestring = formatter.format(dateString);
    DocumentReference docRef = FirebaseFirestore.instance
        .collection('Users')
        .doc(doctorId)
        .collection('schedule')
        .doc(datestring);

    // Get the document snapshot.
    DocumentSnapshot docSnapshot = await docRef.get();

    if (docSnapshot.exists) {
      // Extract the current slots
      Map<String, dynamic> data = docSnapshot.data() as Map<String, dynamic>;
      List<Map<String, dynamic>> timeSlots =
          List<Map<String, dynamic>>.from(data['slots'] ?? []);

      // Find the slot and update its availability
      for (var slot in timeSlots) {
        if (slot['time'] == timeSlot) {
          slot['available'] = false; // Mark as booked
          break;
        }
      }

      // Update Firestore document.
      await docRef.update({'slots': timeSlots});
      print(
          'Time slot $timeSlot on $dateString for doctor $doctorId booked successfully.');
    } else {
      print('No schedule found for doctor $doctorId on $dateString.');
    }
  } catch (e) {
    print('Error updating time slot: $e');
  }
}

// Set your action name, define your arguments and return parameter,
// and then add the boilerplate code using the green button on the right!
