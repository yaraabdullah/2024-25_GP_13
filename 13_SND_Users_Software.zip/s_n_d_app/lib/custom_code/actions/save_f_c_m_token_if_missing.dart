// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'dart:developer';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_messaging/firebase_messaging.dart';

Future<void> saveFCMTokenIfMissing(String userId) async {
  String? fcmToken = await FirebaseMessaging.instance.getToken();
  if (fcmToken == null) {
    log("no token");
    return;
  }
  log("token $fcmToken");

  DocumentReference userRef =
      FirebaseFirestore.instance.collection('Users').doc(userId);

  DocumentSnapshot userDoc = await userRef.get();

  if (userDoc.exists) {
    var data = userDoc.data() as Map<String, dynamic>?;

    var existingToken = data != null && data.containsKey('fcm_token')
        ? data['fcm_token']
        : null;

    if (existingToken == null ||
        (existingToken is String && existingToken.isEmpty)) {
      await userRef.update({'fcm_token': fcmToken});
      log("token added");
    }
  }
}

// Set your action name, define your arguments and return parameter,
// and then add the boilerplate code using the green button on the right!
