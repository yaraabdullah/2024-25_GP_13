// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'dart:convert';
import 'dart:typed_data';
import 'package:firebase_storage/firebase_storage.dart';

Future<String> uploadBase64ToFirebase(String base64image) async {
  final Uint8List bytes = base64Decode(base64image);

  final String fileName =
      DateTime.now().millisecondsSinceEpoch.toString() + ".jpg";
  final Reference ref =
      FirebaseStorage.instance.ref().child('smileAlbum/$fileName');

  final UploadTask uploadTask = ref.putData(bytes);
  final TaskSnapshot snapshot = await uploadTask;

  final String downloadUrl = await snapshot.ref.getDownloadURL();
  return downloadUrl;
}

// Set your action name, define your arguments and return parameter,
// and then add the boilerplate code using the green button on the right!
