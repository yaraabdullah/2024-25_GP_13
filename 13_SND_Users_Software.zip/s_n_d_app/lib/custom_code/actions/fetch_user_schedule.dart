// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'dart:developer';

Future<void> fetchUserSchedule(String userId) async {
  try {
    // Reference to the schedule subcollection
    CollectionReference scheduleRef = FirebaseFirestore.instance
        .collection('Users')
        .doc(userId)
        .collection('schedule');

    // Fetch schedule data
    QuerySnapshot scheduleSnapshot = await scheduleRef.get();

    // Initialize a map to store the schedule
    Map<String, List<String>> scheduleData = {};

    // Loop through the documents in the schedule subcollection
    for (var doc in scheduleSnapshot.docs) {
      Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
      String weekday = data['weekday'] ?? ''; // Weekday name (e.g., Monday)
      List<dynamic> slots = data['time_slots'] ?? []; // List of time slots

      // Store in map
      scheduleData[weekday] = List<String>.from(slots);
    }

    // Convert to JSON string and save to app state
    FFAppState().scheduleJson = scheduleData;

    print("Schedule fetched successfully: $scheduleData");
  } catch (e) {
    print("Error fetching schedule: $e");
  }
}

// Set your action name, define your arguments and return parameter,
// and then add the boilerplate code using the green button on the right!
