// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'dart:io';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';

Future<void> savePdfToDevice(String pdfPath) async {
  try {
    // Step 1: Get the Windows Downloads directory
    final directory = await getDownloadsDirectory();

    // Debugging: Check if directory is valid
    if (directory == null) {
      print("Failed to get the Downloads directory.");
      return;
    }

    // Step 2: Construct the path to save the PDF
    final filePath = '${directory.path}/appointment_report.pdf';
    print('Directory Path: ${directory.path}'); // Debugging: Verify directory
    print('File Path to Save: $filePath'); // Debugging: Verify file path

    // Step 3: Load the PDF file (assuming it's in assets)
    final ByteData bytes = await rootBundle.load(pdfPath);
    final buffer = bytes.buffer.asUint8List();

    // Step 4: Create the File object and write the data
    final file = File(filePath);

    // Check if file already exists for debugging purposes
    if (await file.exists()) {
      print("File already exists, overwriting...");
    }

    // Write the PDF data to the file
    await file.writeAsBytes(buffer);

    // Step 5: Confirm the file was saved successfully
    print('PDF saved to: $filePath');
  } catch (e) {
    // Catch any error and print the message
    print('Error saving PDF: $e');
  }
}

// Set your action name, define your arguments and return parameter,
// and then add the boilerplate code using the green button on the right!
