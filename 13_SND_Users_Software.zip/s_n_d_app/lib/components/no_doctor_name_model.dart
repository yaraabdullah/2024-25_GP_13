import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'no_doctor_name_widget.dart' show NoDoctorNameWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class NoDoctorNameModel extends FlutterFlowModel<NoDoctorNameWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
