import 'package:flutter/material.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';
import '/backend/api_requests/api_manager.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';
import 'dart:convert';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {
    prefs = await SharedPreferences.getInstance();
    _safeInit(() {
      if (prefs.containsKey('ff_audioRef')) {
        try {
          _audioRef = jsonDecode(prefs.getString('ff_audioRef') ?? '');
        } catch (e) {
          print("Can't decode persisted json. Error: $e.");
        }
      }
    });
    _safeInit(() {
      _musicEnabled = prefs.getBool('ff_musicEnabled') ?? _musicEnabled;
    });
    _safeInit(() {
      _chart = prefs
              .getStringList('ff_chart')
              ?.map((x) {
                try {
                  return DataStruct.fromSerializableMap(jsonDecode(x));
                } catch (e) {
                  print("Can't decode persisted data type. Error: $e.");
                  return null;
                }
              })
              .withoutNulls
              .toList() ??
          _chart;
    });
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late SharedPreferences prefs;

  dynamic _audioRef = jsonDecode(
      '[\"https://firebasestorage.googleapis.com/v0/b/sand-98353.appspot.com/o/backgroundSound-nature%2Fnature-216798.mp3?alt=media&token=8e3c4fdd-f564-45ae-b5fb-598f9e670145\",\"https://firebasestorage.googleapis.com/v0/b/sand-98353.appspot.com/o/backgroundSound-chill%2F1%20Hour%20Relaxing%20Sleep%20Music.mp3?alt=media&token=0b36e11c-f2e6-4d70-834f-b2aa5d69c181\"]');
  dynamic get audioRef => _audioRef;
  set audioRef(dynamic value) {
    _audioRef = value;
    prefs.setString('ff_audioRef', jsonEncode(value));
  }

  bool _musicEnabled = true;
  bool get musicEnabled => _musicEnabled;
  set musicEnabled(bool value) {
    _musicEnabled = value;
    prefs.setBool('ff_musicEnabled', value);
  }

  String _currentURL =
      'https://firebasestorage.googleapis.com/v0/b/sand-98353.appspot.com/o/backgroundSound-nature%2Fnature-216798.mp3?alt=media&token=8e3c4fdd-f564-45ae-b5fb-598f9e670145';
  String get currentURL => _currentURL;
  set currentURL(String value) {
    _currentURL = value;
  }

  List<String> _audiRef2 = [
    '\"https://firebasestorage.googleapis.com/v0/b/sand-98353.appspot.com/o/backgroundSound-nature%2Fnature-216798.mp3?alt=media&token=8e3c4fdd-f564-45ae-b5fb-598f9e670145\"',
    '\"https://firebasestorage.googleapis.com/v0/b/sand-98353.appspot.com/o/backgroundSound-chill%2F1%20Hour%20Relaxing%20Sleep%20Music%2C%20Sleep%20Therapy%2C%20Deep%20Sleep%20Music%2C%20Insomnia%2C%20Spa%2C%20Study%2C%20Sleep%2C101.mp3?alt=media&token=0b36e11c-f2e6-4d70-834f-b2aa5d69c181\"'
  ];
  List<String> get audiRef2 => _audiRef2;
  set audiRef2(List<String> value) {
    _audiRef2 = value;
  }

  void addToAudiRef2(String value) {
    audiRef2.add(value);
  }

  void removeFromAudiRef2(String value) {
    audiRef2.remove(value);
  }

  void removeAtIndexFromAudiRef2(int index) {
    audiRef2.removeAt(index);
  }

  void updateAudiRef2AtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    audiRef2[index] = updateFn(_audiRef2[index]);
  }

  void insertAtIndexInAudiRef2(int index, String value) {
    audiRef2.insert(index, value);
  }

  String _initAddio =
      'https://firebasestorage.googleapis.com/v0/b/sand-98353.appspot.com/o/backgroundSound-nature%2Fnature-216798.mp3?alt=media&token=8e3c4fdd-f564-45ae-b5fb-598f9e670145';
  String get initAddio => _initAddio;
  set initAddio(String value) {
    _initAddio = value;
  }

  List<String> _allAdio = [
    'https://firebasestorage.googleapis.com/v0/b/sand-98353.appspot.com/o/backgroundSound-nature%2Fnature-216798.mp3?alt=media&token=8e3c4fdd-f564-45ae-b5fb-598f9e670145',
    'https://firebasestorage.googleapis.com/v0/b/sand-98353.appspot.com/o/backgroundSound-nature%2F1%20hour%20of%20Relaxing%20River%20Sounds.%20Ideal%20for%20Sleep%2C%20Healing%20or%20Studying.mp3?alt=media&token=8c0c66ec-ff8e-4164-96da-221184037084'
  ];
  List<String> get allAdio => _allAdio;
  set allAdio(List<String> value) {
    _allAdio = value;
  }

  void addToAllAdio(String value) {
    allAdio.add(value);
  }

  void removeFromAllAdio(String value) {
    allAdio.remove(value);
  }

  void removeAtIndexFromAllAdio(int index) {
    allAdio.removeAt(index);
  }

  void updateAllAdioAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    allAdio[index] = updateFn(_allAdio[index]);
  }

  void insertAtIndexInAllAdio(int index, String value) {
    allAdio.insert(index, value);
  }

  List<SoundsinfoStruct> _a = [
    SoundsinfoStruct.fromSerializableMap(jsonDecode(
        '{\"title\":\"Hello World\",\"sound\":\"https://firebasestorage.googleapis.com/v0/b/sand-98353.appspot.com/o/backgroundSound-sleep%2FWhite%20Noise%201%20Hour%20Long.mp3?alt=media&token=586f71c1-9323-41da-8ea7-4a2dc2845195\"}'))
  ];
  List<SoundsinfoStruct> get a => _a;
  set a(List<SoundsinfoStruct> value) {
    _a = value;
  }

  void addToA(SoundsinfoStruct value) {
    a.add(value);
  }

  void removeFromA(SoundsinfoStruct value) {
    a.remove(value);
  }

  void removeAtIndexFromA(int index) {
    a.removeAt(index);
  }

  void updateAAtIndex(
    int index,
    SoundsinfoStruct Function(SoundsinfoStruct) updateFn,
  ) {
    a[index] = updateFn(_a[index]);
  }

  void insertAtIndexInA(int index, SoundsinfoStruct value) {
    a.insert(index, value);
  }

  List<String> _allTitles = ['Hello World1', 'Hello World2'];
  List<String> get allTitles => _allTitles;
  set allTitles(List<String> value) {
    _allTitles = value;
  }

  void addToAllTitles(String value) {
    allTitles.add(value);
  }

  void removeFromAllTitles(String value) {
    allTitles.remove(value);
  }

  void removeAtIndexFromAllTitles(int index) {
    allTitles.removeAt(index);
  }

  void updateAllTitlesAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    allTitles[index] = updateFn(_allTitles[index]);
  }

  void insertAtIndexInAllTitles(int index, String value) {
    allTitles.insert(index, value);
  }

  bool _isTextVisible = false;
  bool get isTextVisible => _isTextVisible;
  set isTextVisible(bool value) {
    _isTextVisible = value;
  }

  bool _specialty = false;
  bool get specialty => _specialty;
  set specialty(bool value) {
    _specialty = value;
  }

  bool _languages = false;
  bool get languages => _languages;
  set languages(bool value) {
    _languages = value;
  }

  bool _subspecialty = false;
  bool get subspecialty => _subspecialty;
  set subspecialty(bool value) {
    _subspecialty = value;
  }

  bool _cv = false;
  bool get cv => _cv;
  set cv(bool value) {
    _cv = value;
  }

  bool _dateOfBirth = false;
  bool get dateOfBirth => _dateOfBirth;
  set dateOfBirth(bool value) {
    _dateOfBirth = value;
  }

  bool _showDateOfBirth = false;
  bool get showDateOfBirth => _showDateOfBirth;
  set showDateOfBirth(bool value) {
    _showDateOfBirth = value;
  }

  bool _specMore = false;
  bool get specMore => _specMore;
  set specMore(bool value) {
    _specMore = value;
  }

  bool _cvMore = false;
  bool get cvMore => _cvMore;
  set cvMore(bool value) {
    _cvMore = value;
  }

  bool _langMore = false;
  bool get langMore => _langMore;
  set langMore(bool value) {
    _langMore = value;
  }

  bool _subMore = false;
  bool get subMore => _subMore;
  set subMore(bool value) {
    _subMore = value;
  }

  bool _LanguagesEditProfile = false;
  bool get LanguagesEditProfile => _LanguagesEditProfile;
  set LanguagesEditProfile(bool value) {
    _LanguagesEditProfile = value;
  }

  bool _SubspecialtyEditProfile = false;
  bool get SubspecialtyEditProfile => _SubspecialtyEditProfile;
  set SubspecialtyEditProfile(bool value) {
    _SubspecialtyEditProfile = value;
  }

  bool _DOB = false;
  bool get DOB => _DOB;
  set DOB(bool value) {
    _DOB = value;
  }

  bool _showDateOfBirthEditProfile = false;
  bool get showDateOfBirthEditProfile => _showDateOfBirthEditProfile;
  set showDateOfBirthEditProfile(bool value) {
    _showDateOfBirthEditProfile = value;
  }

  List<AvailabilityStruct> _availability = [];
  List<AvailabilityStruct> get availability => _availability;
  set availability(List<AvailabilityStruct> value) {
    _availability = value;
  }

  void addToAvailability(AvailabilityStruct value) {
    availability.add(value);
  }

  void removeFromAvailability(AvailabilityStruct value) {
    availability.remove(value);
  }

  void removeAtIndexFromAvailability(int index) {
    availability.removeAt(index);
  }

  void updateAvailabilityAtIndex(
    int index,
    AvailabilityStruct Function(AvailabilityStruct) updateFn,
  ) {
    availability[index] = updateFn(_availability[index]);
  }

  void insertAtIndexInAvailability(int index, AvailabilityStruct value) {
    availability.insert(index, value);
  }

  bool _time = false;
  bool get time => _time;
  set time(bool value) {
    _time = value;
  }

  String _repeatOption = '';
  String get repeatOption => _repeatOption;
  set repeatOption(String value) {
    _repeatOption = value;
  }

  DocumentReference? _bookingID;
  DocumentReference? get bookingID => _bookingID;
  set bookingID(DocumentReference? value) {
    _bookingID = value;
  }

  List<String> _slots = [];
  List<String> get slots => _slots;
  set slots(List<String> value) {
    _slots = value;
  }

  void addToSlots(String value) {
    slots.add(value);
  }

  void removeFromSlots(String value) {
    slots.remove(value);
  }

  void removeAtIndexFromSlots(int index) {
    slots.removeAt(index);
  }

  void updateSlotsAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    slots[index] = updateFn(_slots[index]);
  }

  void insertAtIndexInSlots(int index, String value) {
    slots.insert(index, value);
  }

  String _sslot = '';
  String get sslot => _sslot;
  set sslot(String value) {
    _sslot = value;
  }

  String _weekday = '';
  String get weekday => _weekday;
  set weekday(String value) {
    _weekday = value;
  }

  dynamic _scheduleJson;
  dynamic get scheduleJson => _scheduleJson;
  set scheduleJson(dynamic value) {
    _scheduleJson = value;
  }

  List<String> _slotsforupdate = [];
  List<String> get slotsforupdate => _slotsforupdate;
  set slotsforupdate(List<String> value) {
    _slotsforupdate = value;
  }

  void addToSlotsforupdate(String value) {
    slotsforupdate.add(value);
  }

  void removeFromSlotsforupdate(String value) {
    slotsforupdate.remove(value);
  }

  void removeAtIndexFromSlotsforupdate(int index) {
    slotsforupdate.removeAt(index);
  }

  void updateSlotsforupdateAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    slotsforupdate[index] = updateFn(_slotsforupdate[index]);
  }

  void insertAtIndexInSlotsforupdate(int index, String value) {
    slotsforupdate.insert(index, value);
  }

  List<DataStruct> _chart = [
    DataStruct.fromSerializableMap(
        jsonDecode('{\"day\":\"1\",\"score\":\"10.0\"}')),
    DataStruct.fromSerializableMap(
        jsonDecode('{\"day\":\"2\",\"score\":\"10.0\"}')),
    DataStruct.fromSerializableMap(
        jsonDecode('{\"day\":\"3\",\"score\":\"20.0\"}')),
    DataStruct.fromSerializableMap(
        jsonDecode('{\"day\":\"1\",\"score\":\"40.0\"}'))
  ];
  List<DataStruct> get chart => _chart;
  set chart(List<DataStruct> value) {
    _chart = value;
    prefs.setStringList('ff_chart', value.map((x) => x.serialize()).toList());
  }

  void addToChart(DataStruct value) {
    chart.add(value);
    prefs.setStringList('ff_chart', _chart.map((x) => x.serialize()).toList());
  }

  void removeFromChart(DataStruct value) {
    chart.remove(value);
    prefs.setStringList('ff_chart', _chart.map((x) => x.serialize()).toList());
  }

  void removeAtIndexFromChart(int index) {
    chart.removeAt(index);
    prefs.setStringList('ff_chart', _chart.map((x) => x.serialize()).toList());
  }

  void updateChartAtIndex(
    int index,
    DataStruct Function(DataStruct) updateFn,
  ) {
    chart[index] = updateFn(_chart[index]);
    prefs.setStringList('ff_chart', _chart.map((x) => x.serialize()).toList());
  }

  void insertAtIndexInChart(int index, DataStruct value) {
    chart.insert(index, value);
    prefs.setStringList('ff_chart', _chart.map((x) => x.serialize()).toList());
  }

  bool _makePhoto = false;
  bool get makePhoto => _makePhoto;
  set makePhoto(bool value) {
    _makePhoto = value;
  }

  String _fileBase64 = '';
  String get fileBase64 => _fileBase64;
  set fileBase64(String value) {
    _fileBase64 = value;
  }

  String _imagePath = '';
  String get imagePath => _imagePath;
  set imagePath(String value) {
    _imagePath = value;
  }

  bool _isTake = false;
  bool get isTake => _isTake;
  set isTake(bool value) {
    _isTake = value;
  }

  String _correctImagePath = '';
  String get correctImagePath => _correctImagePath;
  set correctImagePath(String value) {
    _correctImagePath = value;
  }

  DateTime? _SelectedDay;
  DateTime? get SelectedDay => _SelectedDay;
  set SelectedDay(DateTime? value) {
    _SelectedDay = value;
  }

  String _isSmiling = '';
  String get isSmiling => _isSmiling;
  set isSmiling(String value) {
    _isSmiling = value;
  }

  bool _isThecallSmiling = false;
  bool get isThecallSmiling => _isThecallSmiling;
  set isThecallSmiling(bool value) {
    _isThecallSmiling = value;
  }
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}
