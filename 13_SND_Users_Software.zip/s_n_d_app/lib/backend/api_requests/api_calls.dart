import 'dart:convert';
import 'dart:typed_data';
import '../cloud_functions/cloud_functions.dart';
import '../schema/structs/index.dart';

import 'package:flutter/foundation.dart';

import '/flutter_flow/flutter_flow_util.dart';
import 'api_manager.dart';

export 'api_manager.dart' show ApiCallResponse;

const _kPrivateApiFunctionName = 'ffPrivateApiCall';

/// Start OpenAI ChatGPT Group Code

class OpenAIChatGPTGroup {
  static String getBaseUrl() =>
      'https://chatbot-snd-app-3fa5bd8f8896.herokuapp.com';
  static Map<String, String> headers = {
    'Content-Type': 'application/json',
  };
  static SendFullPromptCall sendFullPromptCall = SendFullPromptCall();
}

class SendFullPromptCall {
  Future<ApiCallResponse> call({
    String? apiKey = '',
    String? prompt = '',
  }) async {
    final baseUrl = OpenAIChatGPTGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "input": {
    "input": "${prompt}"
  },
  "config": {},
  "kwargs": {}
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Send Full Prompt',
      apiUrl: '${baseUrl}/invoke/invoke',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ${apiKey}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  int? createdTimestamp(dynamic response) => castToType<int>(getJsonField(
        response,
        r'''$.created''',
      ));
  String? role(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.choices[:].message.role''',
      ));
  String? content(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.choices[:].message.content''',
      ));
}

/// End OpenAI ChatGPT Group Code

/// Start LangChain Server Group Code

class LangChainServerGroup {
  static String getBaseUrl() =>
      'https://chatbot-snd-app-3fa5bd8f8896.herokuapp.com';
  static Map<String, String> headers = {};
  static InvokeInputSchemaInvokeInputSchemaGetCall
      invokeInputSchemaInvokeInputSchemaGetCall =
      InvokeInputSchemaInvokeInputSchemaGetCall();
  static InvokeInputSchemaWithConfigInvokeCConfigHashInputSchemaGetCall
      invokeInputSchemaWithConfigInvokeCConfigHashInputSchemaGetCall =
      InvokeInputSchemaWithConfigInvokeCConfigHashInputSchemaGetCall();
  static InvokeOutputSchemaInvokeOutputSchemaGetCall
      invokeOutputSchemaInvokeOutputSchemaGetCall =
      InvokeOutputSchemaInvokeOutputSchemaGetCall();
  static InvokeOutputSchemaWithConfigInvokeCConfigHashOutputSchemaGetCall
      invokeOutputSchemaWithConfigInvokeCConfigHashOutputSchemaGetCall =
      InvokeOutputSchemaWithConfigInvokeCConfigHashOutputSchemaGetCall();
  static InvokeConfigSchemaInvokeConfigSchemaGetCall
      invokeConfigSchemaInvokeConfigSchemaGetCall =
      InvokeConfigSchemaInvokeConfigSchemaGetCall();
  static InvokeConfigSchemaWithConfigInvokeCConfigHashConfigSchemaGetCall
      invokeConfigSchemaWithConfigInvokeCConfigHashConfigSchemaGetCall =
      InvokeConfigSchemaWithConfigInvokeCConfigHashConfigSchemaGetCall();
  static CreateFeedbackFromTokenInvokeTokenFeedbackPostCall
      createFeedbackFromTokenInvokeTokenFeedbackPostCall =
      CreateFeedbackFromTokenInvokeTokenFeedbackPostCall();
  static InvokeInvokeInvokeInvokePostCall invokeInvokeInvokeInvokePostCall =
      InvokeInvokeInvokeInvokePostCall();
  static InvokeInvokeWithConfigInvokeCConfigHashInvokePostCall
      invokeInvokeWithConfigInvokeCConfigHashInvokePostCall =
      InvokeInvokeWithConfigInvokeCConfigHashInvokePostCall();
  static InvokeBatchInvokeBatchPostCall invokeBatchInvokeBatchPostCall =
      InvokeBatchInvokeBatchPostCall();
  static InvokeBatchWithConfigInvokeCConfigHashBatchPostCall
      invokeBatchWithConfigInvokeCConfigHashBatchPostCall =
      InvokeBatchWithConfigInvokeCConfigHashBatchPostCall();
  static InvokeStreamInvokeStreamPostCall invokeStreamInvokeStreamPostCall =
      InvokeStreamInvokeStreamPostCall();
  static InvokeStreamWithConfigInvokeCConfigHashStreamPostCall
      invokeStreamWithConfigInvokeCConfigHashStreamPostCall =
      InvokeStreamWithConfigInvokeCConfigHashStreamPostCall();
  static InvokeStreamLogInvokeStreamLogPostCall
      invokeStreamLogInvokeStreamLogPostCall =
      InvokeStreamLogInvokeStreamLogPostCall();
  static InvokeStreamLogWithConfigInvokeCConfigHashStreamLogPostCall
      invokeStreamLogWithConfigInvokeCConfigHashStreamLogPostCall =
      InvokeStreamLogWithConfigInvokeCConfigHashStreamLogPostCall();
  static InvokeStreamEventsInvokeStreamEventsPostCall
      invokeStreamEventsInvokeStreamEventsPostCall =
      InvokeStreamEventsInvokeStreamEventsPostCall();
  static InvokeStreamEventsWithConfigInvokeCConfigHashStreamEventsPostCall
      invokeStreamEventsWithConfigInvokeCConfigHashStreamEventsPostCall =
      InvokeStreamEventsWithConfigInvokeCConfigHashStreamEventsPostCall();
}

class InvokeInputSchemaInvokeInputSchemaGetCall {
  Future<ApiCallResponse> call() async {
    final baseUrl = LangChainServerGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'invoke_input_schema_invoke_input_schema_get',
      apiUrl: '${baseUrl}/invoke/input_schema',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class InvokeInputSchemaWithConfigInvokeCConfigHashInputSchemaGetCall {
  Future<ApiCallResponse> call({
    String? configHash = '',
  }) async {
    final baseUrl = LangChainServerGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName:
          'invoke_input_schema_with_config_invoke_c__config_hash__input_schema_get',
      apiUrl: '${baseUrl}/invoke/c/${configHash}/input_schema',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class InvokeOutputSchemaInvokeOutputSchemaGetCall {
  Future<ApiCallResponse> call() async {
    final baseUrl = LangChainServerGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'invoke_output_schema_invoke_output_schema_get',
      apiUrl: '${baseUrl}/invoke/output_schema',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class InvokeOutputSchemaWithConfigInvokeCConfigHashOutputSchemaGetCall {
  Future<ApiCallResponse> call({
    String? configHash = '',
  }) async {
    final baseUrl = LangChainServerGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName:
          'invoke_output_schema_with_config_invoke_c__config_hash__output_schema_get',
      apiUrl: '${baseUrl}/invoke/c/${configHash}/output_schema',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class InvokeConfigSchemaInvokeConfigSchemaGetCall {
  Future<ApiCallResponse> call() async {
    final baseUrl = LangChainServerGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'invoke_config_schema_invoke_config_schema_get',
      apiUrl: '${baseUrl}/invoke/config_schema',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class InvokeConfigSchemaWithConfigInvokeCConfigHashConfigSchemaGetCall {
  Future<ApiCallResponse> call({
    String? configHash = '',
  }) async {
    final baseUrl = LangChainServerGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName:
          'invoke_config_schema_with_config_invoke_c__config_hash__config_schema_get',
      apiUrl: '${baseUrl}/invoke/c/${configHash}/config_schema',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CreateFeedbackFromTokenInvokeTokenFeedbackPostCall {
  Future<ApiCallResponse> call() async {
    final baseUrl = LangChainServerGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "token_or_url": "",
  "score": "",
  "value": "",
  "comment": "",
  "correction": "",
  "metadata": ""
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'create_feedback_from_token_invoke_token_feedback_post',
      apiUrl: '${baseUrl}/invoke/token_feedback',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class InvokeInvokeInvokeInvokePostCall {
  Future<ApiCallResponse> call({
    String? configHash = '',
    String? input = '',
  }) async {
    final baseUrl = LangChainServerGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "input": {
    "input": "${escapeStringForJson(input)}"
  },
  "config": {},
  "kwargs": {}
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'invoke_invoke_invoke_invoke_post',
      apiUrl: '${baseUrl}/invoke/invoke',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class InvokeInvokeWithConfigInvokeCConfigHashInvokePostCall {
  Future<ApiCallResponse> call({
    String? configHash = '',
  }) async {
    final baseUrl = LangChainServerGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "input": {
    "input": ""
  },
  "config": {},
  "kwargs": {}
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'invoke_invoke_with_config_invoke_c__config_hash__invoke_post',
      apiUrl: '${baseUrl}/invoke/c/${configHash}/invoke',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class InvokeBatchInvokeBatchPostCall {
  Future<ApiCallResponse> call({
    String? configHash = '',
  }) async {
    final baseUrl = LangChainServerGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "inputs": [
    {
      "input": ""
    }
  ],
  "config": "",
  "kwargs": {}
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'invoke_batch_invoke_batch_post',
      apiUrl: '${baseUrl}/invoke/batch',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class InvokeBatchWithConfigInvokeCConfigHashBatchPostCall {
  Future<ApiCallResponse> call({
    String? configHash = '',
  }) async {
    final baseUrl = LangChainServerGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "inputs": [
    {
      "input": ""
    }
  ],
  "config": "",
  "kwargs": {}
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'invoke_batch_with_config_invoke_c__config_hash__batch_post',
      apiUrl: '${baseUrl}/invoke/c/${configHash}/batch',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class InvokeStreamInvokeStreamPostCall {
  Future<ApiCallResponse> call({
    String? configHash = '',
  }) async {
    final baseUrl = LangChainServerGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "input": {
    "input": ""
  },
  "config": {},
  "kwargs": {}
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'invoke_stream_invoke_stream_post',
      apiUrl: '${baseUrl}/invoke/stream',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class InvokeStreamWithConfigInvokeCConfigHashStreamPostCall {
  Future<ApiCallResponse> call({
    String? configHash = '',
  }) async {
    final baseUrl = LangChainServerGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "input": {
    "input": ""
  },
  "config": {},
  "kwargs": {}
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'invoke_stream_with_config_invoke_c__config_hash__stream_post',
      apiUrl: '${baseUrl}/invoke/c/${configHash}/stream',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class InvokeStreamLogInvokeStreamLogPostCall {
  Future<ApiCallResponse> call({
    String? configHash = '',
  }) async {
    final baseUrl = LangChainServerGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "input": {
    "input": ""
  },
  "config": {},
  "include_names": "",
  "include_types": "",
  "include_tags": "",
  "exclude_names": "",
  "exclude_types": "",
  "exclude_tags": "",
  "kwargs": {}
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'invoke_stream_log_invoke_stream_log_post',
      apiUrl: '${baseUrl}/invoke/stream_log',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class InvokeStreamLogWithConfigInvokeCConfigHashStreamLogPostCall {
  Future<ApiCallResponse> call({
    String? configHash = '',
  }) async {
    final baseUrl = LangChainServerGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "input": {
    "input": ""
  },
  "config": {},
  "include_names": "",
  "include_types": "",
  "include_tags": "",
  "exclude_names": "",
  "exclude_types": "",
  "exclude_tags": "",
  "kwargs": {}
}''';
    return ApiManager.instance.makeApiCall(
      callName:
          'invoke_stream_log_with_config_invoke_c__config_hash__stream_log_post',
      apiUrl: '${baseUrl}/invoke/c/${configHash}/stream_log',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class InvokeStreamEventsInvokeStreamEventsPostCall {
  Future<ApiCallResponse> call({
    String? configHash = '',
  }) async {
    final baseUrl = LangChainServerGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "input": {
    "input": ""
  },
  "config": {},
  "include_names": "",
  "include_types": "",
  "include_tags": "",
  "exclude_names": "",
  "exclude_types": "",
  "exclude_tags": "",
  "kwargs": {}
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'invoke_stream_events_invoke_stream_events_post',
      apiUrl: '${baseUrl}/invoke/stream_events',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class InvokeStreamEventsWithConfigInvokeCConfigHashStreamEventsPostCall {
  Future<ApiCallResponse> call({
    String? configHash = '',
  }) async {
    final baseUrl = LangChainServerGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "input": {
    "input": ""
  },
  "config": {},
  "include_names": "",
  "include_types": "",
  "include_tags": "",
  "exclude_names": "",
  "exclude_types": "",
  "exclude_tags": "",
  "kwargs": {}
}''';
    return ApiManager.instance.makeApiCall(
      callName:
          'invoke_stream_events_with_config_invoke_c__config_hash__stream_events_post',
      apiUrl: '${baseUrl}/invoke/c/${configHash}/stream_events',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

/// End LangChain Server Group Code

/// Start BF - emailsndemail Group Code

class BFEmailsndemailGroup {
  static String getBaseUrl() => 'https://api.backendflow.io/v1';
  static Map<String, String> headers = {};
  static EmailsndemailCall emailsndemailCall = EmailsndemailCall();
}

class EmailsndemailCall {
  Future<ApiCallResponse> call({
    String? to = '',
    String? subject = '',
    String? attachmentLink = '',
    String? attachmentName = '',
  }) async {
    final baseUrl = BFEmailsndemailGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "sk-bf-0dac5084-c71b-4929-8256-8e33445c9a1b": ""
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'emailsndemail',
      apiUrl:
          '${baseUrl}/email?templateId=4kUsWGw5yd67PAXBTCPd&to=${to}&subject=${subject}&attachmentLink=${attachmentLink}&attachmentName=${attachmentName}',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

/// End BF - emailsndemail Group Code

/// Start sndmailer Group Code

class SndmailerGroup {
  static String getBaseUrl() => 'https://sndmentalhealth.com/';
  static Map<String, String> headers = {
    'x-api-token': 'dummy-token-12345',
  };
  static BookingCall bookingCall = BookingCall();
  static CancelbookingCall cancelbookingCall = CancelbookingCall();
}

class BookingCall {
  Future<ApiCallResponse> call({
    String? to = '',
    String? name = '',
    String? date = '',
    String? time = '',
    String? doctorName = '',
  }) async {
    final baseUrl = SndmailerGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "to": "${escapeStringForJson(to)}",
  "user": "${escapeStringForJson(name)}",
  "date": "${escapeStringForJson(date)}",
  "time": "${escapeStringForJson(time)}",
  "doctor_name": "${escapeStringForJson(doctorName)}"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'booking',
      apiUrl: '${baseUrl}/send-email/booking',
      callType: ApiCallType.POST,
      headers: {
        'x-api-token': 'dummy-token-12345',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CancelbookingCall {
  Future<ApiCallResponse> call() async {
    final baseUrl = SndmailerGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "to": "noonkazmi@gmail.com",
  "user": "naem",
  "date": "13-03-25",
  "time": "6:35 AM",
  "doctor_name": "Dr. Ahmed"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'cancelbooking',
      apiUrl: '${baseUrl}/send-email/cancelled',
      callType: ApiCallType.POST,
      headers: {
        'x-api-token': 'dummy-token-12345',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

/// End sndmailer Group Code

class ChatBotRequestCall {
  static Future<ApiCallResponse> call() async {
    final ffApiRequestBody = '''
{
  "message": "{user_message}"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'ChatBotRequest',
      apiUrl: 'http://localhost:8000/invoke',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class SNDchatbotCall {
  static Future<ApiCallResponse> call({
    String? input = '',
  }) async {
    final ffApiRequestBody = '''
{
  "input": {
    "input": "${escapeStringForJson(input)}"
  },
  "config": {},
  "kwargs": {}
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'SNDchatbot',
      apiUrl:
          'https://chatbot-snd-app-3fa5bd8f8896.herokuapp.com/invoke/invoke',
      callType: ApiCallType.POST,
      headers: {
        'accept': 'application/json',
        'Content-Type': 'application/json',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class SNDchatbotNoMemoryCall {
  static Future<ApiCallResponse> call({
    String? input = '',
  }) async {
    final ffApiRequestBody = '''
{
  "input": {
    "input": "${escapeStringForJson(input)}"
  },
  "config": {},
  "kwargs": {}
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'SNDchatbotNoMemory',
      apiUrl: 'https://snd-app-b5b321494c38.herokuapp.com/chatbot2/invoke',
      callType: ApiCallType.POST,
      headers: {
        'accept': 'application/json',
        'Content-Type': 'application/json',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CancelScheduledEmailCall {
  static Future<ApiCallResponse> call({
    String? scheduledId = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'Cancel Scheduled Email',
      apiUrl: 'https://api.resend.com/emails/${scheduledId}/cancel',
      callType: ApiCallType.POST,
      headers: {
        'Authorization': 'Bearer re_HcNizjix_NHSqzeya4n6c95ikdtfZAq7P',
        'Content-Type': 'application/json',
      },
      params: {},
      bodyType: BodyType.NONE,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class DetectSmileCall {
  static Future<ApiCallResponse> call({
    String? image = '',
  }) async {
    final response = await makeCloudCall(
      _kPrivateApiFunctionName,
      {
        'callName': 'DetectSmileCall',
        'variables': {
          'image': image,
        },
      },
    );
    return ApiCallResponse.fromCloudCallResponse(response);
  }

  static bool? smilimg(dynamic response) => castToType<bool>(getJsonField(
        response,
        r'''$.smiling''',
      ));
}

class ApiPagingParams {
  int nextPageNumber = 0;
  int numItems = 0;
  dynamic lastResponse;

  ApiPagingParams({
    required this.nextPageNumber,
    required this.numItems,
    required this.lastResponse,
  });

  @override
  String toString() =>
      'PagingParams(nextPageNumber: $nextPageNumber, numItems: $numItems, lastResponse: $lastResponse,)';
}

String _toEncodable(dynamic item) {
  if (item is DocumentReference) {
    return item.path;
  }
  return item;
}

String _serializeList(List? list) {
  list ??= <String>[];
  try {
    return json.encode(list, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("List serialization failed. Returning empty list.");
    }
    return '[]';
  }
}

String _serializeJson(dynamic jsonVar, [bool isList = false]) {
  jsonVar ??= (isList ? [] : {});
  try {
    return json.encode(jsonVar, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("Json serialization failed. Returning empty json.");
    }
    return isList ? '[]' : '{}';
  }
}

String? escapeStringForJson(String? input) {
  if (input == null) {
    return null;
  }
  return input
      .replaceAll('\\', '\\\\')
      .replaceAll('"', '\\"')
      .replaceAll('\n', '\\n')
      .replaceAll('\t', '\\t');
}
