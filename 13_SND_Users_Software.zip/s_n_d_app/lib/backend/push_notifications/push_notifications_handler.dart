import 'dart:async';
import 'dart:convert';

import 'serialization_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '../../flutter_flow/flutter_flow_util.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

import '../../index.dart';
import '../../main.dart';

final _handledMessageIds = <String?>{};

class PushNotificationsHandler extends StatefulWidget {
  const PushNotificationsHandler({Key? key, required this.child})
      : super(key: key);

  final Widget child;

  @override
  _PushNotificationsHandlerState createState() =>
      _PushNotificationsHandlerState();
}

class _PushNotificationsHandlerState extends State<PushNotificationsHandler> {
  bool _loading = false;

  Future handleOpenedPushNotification() async {
    if (isWeb) {
      return;
    }

    final notification = await FirebaseMessaging.instance.getInitialMessage();
    if (notification != null) {
      await _handlePushNotification(notification);
    }
    FirebaseMessaging.onMessageOpenedApp.listen(_handlePushNotification);
  }

  Future _handlePushNotification(RemoteMessage message) async {
    if (_handledMessageIds.contains(message.messageId)) {
      return;
    }
    _handledMessageIds.add(message.messageId);

    safeSetState(() => _loading = true);
    try {
      final initialPageName = message.data['initialPageName'] as String;
      final initialParameterData = getInitialParameterData(message.data);
      final parametersBuilder = parametersBuilderMap[initialPageName];
      if (parametersBuilder != null) {
        final parameterData = await parametersBuilder(initialParameterData);
        if (mounted) {
          context.pushNamed(
            initialPageName,
            pathParameters: parameterData.pathParameters,
            extra: parameterData.extra,
          );
        } else {
          appNavigatorKey.currentContext?.pushNamed(
            initialPageName,
            pathParameters: parameterData.pathParameters,
            extra: parameterData.extra,
          );
        }
      }
    } catch (e) {
      print('Error: $e');
    } finally {
      safeSetState(() => _loading = false);
    }
  }

  @override
  void initState() {
    super.initState();
    SchedulerBinding.instance.addPostFrameCallback((_) {
      handleOpenedPushNotification();
    });
  }

  @override
  Widget build(BuildContext context) => _loading
      ? Center(
          child: SizedBox(
            width: 50.0,
            height: 50.0,
            child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(
                FlutterFlowTheme.of(context).primary,
              ),
            ),
          ),
        )
      : widget.child;
}

class ParameterData {
  const ParameterData(
      {this.requiredParams = const {}, this.allParams = const {}});
  final Map<String, String?> requiredParams;
  final Map<String, dynamic> allParams;

  Map<String, String> get pathParameters => Map.fromEntries(
        requiredParams.entries
            .where((e) => e.value != null)
            .map((e) => MapEntry(e.key, e.value!)),
      );
  Map<String, dynamic> get extra => Map.fromEntries(
        allParams.entries.where((e) => e.value != null),
      );

  static Future<ParameterData> Function(Map<String, dynamic>) none() =>
      (data) async => ParameterData();
}

final parametersBuilderMap =
    <String, Future<ParameterData> Function(Map<String, dynamic>)>{
  'home': ParameterData.none(),
  'DoctorDeatils': (data) async => ParameterData(
        allParams: {
          'docID': getParameter<DocumentReference>(data, 'docID'),
        },
      ),
  'ST_2': ParameterData.none(),
  'ST_Results': ParameterData.none(),
  'Profile-Doctor': ParameterData.none(),
  'Auth_verifyEmail': (data) async => ParameterData(
        allParams: {
          'email': getParameter<String>(data, 'email'),
        },
      ),
  'Auth_ForgotPassword': (data) async => ParameterData(
        allParams: {
          'password': getParameter<String>(data, 'password'),
          'studentBool': getParameter<String>(data, 'studentBool'),
        },
      ),
  'StudentProfile': (data) async => ParameterData(
        allParams: {
          'docPic': getParameter<String>(data, 'docPic'),
        },
      ),
  'DoctorBooking': ParameterData.none(),
  'auth_3_Create_2': ParameterData.none(),
  'auth_3_Login_2': ParameterData.none(),
  'auth_3_phone_2': ParameterData.none(),
  'auth_3_verifyPhone_2': (data) async => ParameterData(
        allParams: {
          'phoneNumber': getParameter<String>(data, 'phoneNumber'),
        },
      ),
  'auth_3_ForgotPassword_2': ParameterData.none(),
  'HomePage': ParameterData.none(),
  'AssessmentCategory': ParameterData.none(),
  'AssessmentResultDepressio': (data) async => ParameterData(
        allParams: {
          'score': getParameter<double>(data, 'score'),
        },
      ),
  'Results_viewMore': ParameterData.none(),
  'Album': ParameterData.none(),
  'Smile-recognition': ParameterData.none(),
  'report_rating': (data) async => ParameterData(
        allParams: {
          'booking': getParameter<DocumentReference>(data, 'booking'),
          'userid': getParameter<DocumentReference>(data, 'userid'),
          'doctorid': getParameter<DocumentReference>(data, 'doctorid'),
        },
      ),
  'EditStudentProfile': ParameterData.none(),
  'EditNotificationSettings': ParameterData.none(),
  'success': ParameterData.none(),
  'ReservatonsPage': ParameterData.none(),
  'ST_ResultsCopy': ParameterData.none(),
  'ReservationAppointment': (data) async => ParameterData(
        allParams: {
          'docID': getParameter<DocumentReference>(data, 'docID'),
          'doctorname': getParameter<String>(data, 'doctorname'),
        },
      ),
  'Auth_CreatAcount': (data) async => ParameterData(
        allParams: {
          'studentBool': getParameter<bool>(data, 'studentBool'),
        },
      ),
  'articles': ParameterData.none(),
  'ArticleContent': ParameterData.none(),
  'ArticleContentCopy': (data) async => ParameterData(
        allParams: {
          'articleid': getParameter<DocumentReference>(data, 'articleid'),
        },
      ),
  'chat_ai_Screen': ParameterData.none(),
  'myBookingsCopy2': ParameterData.none(),
  'EditReservation': (data) async => ParameterData(
        allParams: {
          'bookingid': getParameter<DocumentReference>(data, 'bookingid'),
          'id': getParameter<DocumentReference>(data, 'id'),
          'doctorDoc': await getDocumentParameter<UsersRecord>(
              data, 'doctorDoc', UsersRecord.fromSnapshot),
        },
      ),
  'applicationStatus': ParameterData.none(),
  'EditDoctorProfile': ParameterData.none(),
  'DoctorCalender': ParameterData.none(),
  'BackgroundSoundCopy': ParameterData.none(),
  'ChillSoundCopyCopy2': (data) async => ParameterData(
        allParams: {
          'soundid': getParameter<DocumentReference>(data, 'soundid'),
        },
      ),
  'HomeCopy': ParameterData.none(),
  'ReservatonsPageCopy': ParameterData.none(),
  'contactUs': ParameterData.none(),
  'ChillSoundCopyCopy2Copy2': (data) async => ParameterData(
        allParams: {
          'soundid': getParameter<DocumentReference>(data, 'soundid'),
        },
      ),
  'NeedMoreInfo': ParameterData.none(),
  'doctortimeslots': ParameterData.none(),
  'DoctorCalenderCopy2': ParameterData.none(),
  'notifications': ParameterData.none(),
  'sendReport': (data) async => ParameterData(
        allParams: {
          'bookingId': getParameter<DocumentReference>(data, 'bookingId'),
        },
      ),
  'report_ratingCopy': (data) async => ParameterData(
        allParams: {
          'booking': getParameter<DocumentReference>(data, 'booking'),
          'userid': getParameter<DocumentReference>(data, 'userid'),
          'doctorid': getParameter<DocumentReference>(data, 'doctorid'),
        },
      ),
  'DoctorCalenderCopy': ParameterData.none(),
  'DoctorCalenderCopy3': ParameterData.none(),
  'doctorCalenderEditView': ParameterData.none(),
  'updatecalander': ParameterData.none(),
  'schedualemengment': ParameterData.none(),
  'ConfirmationScheduale': ParameterData.none(),
  'ConfirmationSchedualeCopy': ParameterData.none(),
  'doctorCalenderUpdated': ParameterData.none(),
  'DoctorBookingCopy': ParameterData.none(),
  'introsmile': ParameterData.none(),
  'camera': (data) async => ParameterData(
        allParams: {
          'smileid': getParameter<DocumentReference>(data, 'smileid'),
        },
      ),
  'ST_3': ParameterData.none(),
  'ST_4': ParameterData.none(),
  'AssessmentResultanxiety': (data) async => ParameterData(
        allParams: {
          'score': getParameter<double>(data, 'score'),
        },
      ),
  'AssessmentResultsleep': (data) async => ParameterData(
        allParams: {
          'score': getParameter<double>(data, 'score'),
        },
      ),
  'SEHAinstructions': ParameterData.none(),
  'InformationForm': ParameterData.none(),
  'Confirmation': ParameterData.none(),
  'yourPic': (data) async => ParameterData(
        allParams: {
          'smileid': getParameter<DocumentReference>(data, 'smileid'),
        },
      ),
  'ChillSoundCopyCopy2Copy': (data) async => ParameterData(
        allParams: {
          'soundid': getParameter<DocumentReference>(data, 'soundid'),
        },
      ),
  'zoomlink': ParameterData.none(),
  'zoompasscode': (data) async => ParameterData(
        allParams: {
          'bookingid': getParameter<DocumentReference>(data, 'bookingid'),
        },
      ),
  'Clinics': ParameterData.none(),
  'PsychotherapyClinic': ParameterData.none(),
  'PsychiatryClinic': ParameterData.none(),
  'SocialServicesClinic': ParameterData.none(),
  'picAlbum': ParameterData.none(),
  'gg': ParameterData.none(),
  'myBookingsCopy2Copy': ParameterData.none(),
  'successCopy': ParameterData.none(),
};

Map<String, dynamic> getInitialParameterData(Map<String, dynamic> data) {
  try {
    final parameterDataStr = data['parameterData'];
    if (parameterDataStr == null ||
        parameterDataStr is! String ||
        parameterDataStr.isEmpty) {
      return {};
    }
    return jsonDecode(parameterDataStr) as Map<String, dynamic>;
  } catch (e) {
    print('Error parsing parameter data: $e');
    return {};
  }
}
