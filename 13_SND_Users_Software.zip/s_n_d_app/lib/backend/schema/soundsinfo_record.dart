import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SoundsinfoRecord extends FirestoreRecord {
  SoundsinfoRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "sound" field.
  String? _sound;
  String get sound => _sound ?? '';
  bool hasSound() => _sound != null;

  // "title" field.
  String? _title;
  String get title => _title ?? '';
  bool hasTitle() => _title != null;

  // "cid" field.
  DocumentReference? _cid;
  DocumentReference? get cid => _cid;
  bool hasCid() => _cid != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _sound = snapshotData['sound'] as String?;
    _title = snapshotData['title'] as String?;
    _cid = snapshotData['cid'] as DocumentReference?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('Soundsinfo')
          : FirebaseFirestore.instance.collectionGroup('Soundsinfo');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('Soundsinfo').doc(id);

  static Stream<SoundsinfoRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => SoundsinfoRecord.fromSnapshot(s));

  static Future<SoundsinfoRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => SoundsinfoRecord.fromSnapshot(s));

  static SoundsinfoRecord fromSnapshot(DocumentSnapshot snapshot) =>
      SoundsinfoRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static SoundsinfoRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      SoundsinfoRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'SoundsinfoRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is SoundsinfoRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createSoundsinfoRecordData({
  String? sound,
  String? title,
  DocumentReference? cid,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'sound': sound,
      'title': title,
      'cid': cid,
    }.withoutNulls,
  );

  return firestoreData;
}

class SoundsinfoRecordDocumentEquality implements Equality<SoundsinfoRecord> {
  const SoundsinfoRecordDocumentEquality();

  @override
  bool equals(SoundsinfoRecord? e1, SoundsinfoRecord? e2) {
    return e1?.sound == e2?.sound &&
        e1?.title == e2?.title &&
        e1?.cid == e2?.cid;
  }

  @override
  int hash(SoundsinfoRecord? e) =>
      const ListEquality().hash([e?.sound, e?.title, e?.cid]);

  @override
  bool isValidKey(Object? o) => o is SoundsinfoRecord;
}
