import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class AvailableslotsRecord extends FirestoreRecord {
  AvailableslotsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "isAvailable" field.
  bool? _isAvailable;
  bool get isAvailable => _isAvailable ?? false;
  bool hasIsAvailable() => _isAvailable != null;

  // "avai" field.
  List<AvailabilityStruct>? _avai;
  List<AvailabilityStruct> get avai => _avai ?? const [];
  bool hasAvai() => _avai != null;

  // "time" field.
  List<DateTime>? _time;
  List<DateTime> get time => _time ?? const [];
  bool hasTime() => _time != null;

  // "date" field.
  DateTime? _date;
  DateTime? get date => _date;
  bool hasDate() => _date != null;

  // "timeslots" field.
  List<String>? _timeslots;
  List<String> get timeslots => _timeslots ?? const [];
  bool hasTimeslots() => _timeslots != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _isAvailable = snapshotData['isAvailable'] as bool?;
    _avai = getStructList(
      snapshotData['avai'],
      AvailabilityStruct.fromMap,
    );
    _time = getDataList(snapshotData['time']);
    _date = snapshotData['date'] as DateTime?;
    _timeslots = getDataList(snapshotData['timeslots']);
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('availableslots')
          : FirebaseFirestore.instance.collectionGroup('availableslots');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('availableslots').doc(id);

  static Stream<AvailableslotsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => AvailableslotsRecord.fromSnapshot(s));

  static Future<AvailableslotsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => AvailableslotsRecord.fromSnapshot(s));

  static AvailableslotsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      AvailableslotsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static AvailableslotsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      AvailableslotsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'AvailableslotsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is AvailableslotsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createAvailableslotsRecordData({
  bool? isAvailable,
  DateTime? date,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'isAvailable': isAvailable,
      'date': date,
    }.withoutNulls,
  );

  return firestoreData;
}

class AvailableslotsRecordDocumentEquality
    implements Equality<AvailableslotsRecord> {
  const AvailableslotsRecordDocumentEquality();

  @override
  bool equals(AvailableslotsRecord? e1, AvailableslotsRecord? e2) {
    const listEquality = ListEquality();
    return e1?.isAvailable == e2?.isAvailable &&
        listEquality.equals(e1?.avai, e2?.avai) &&
        listEquality.equals(e1?.time, e2?.time) &&
        e1?.date == e2?.date &&
        listEquality.equals(e1?.timeslots, e2?.timeslots);
  }

  @override
  int hash(AvailableslotsRecord? e) => const ListEquality()
      .hash([e?.isAvailable, e?.avai, e?.time, e?.date, e?.timeslots]);

  @override
  bool isValidKey(Object? o) => o is AvailableslotsRecord;
}
