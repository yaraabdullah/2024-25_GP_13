import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ScheduleRecord extends FirestoreRecord {
  ScheduleRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "date" field.
  DateTime? _date;
  DateTime? get date => _date;
  bool hasDate() => _date != null;

  // "slots" field.
  TimeSlotStruct? _slots;
  TimeSlotStruct get slots => _slots ?? TimeSlotStruct();
  bool hasSlots() => _slots != null;

  // "repeat" field.
  String? _repeat;
  String get repeat => _repeat ?? '';
  bool hasRepeat() => _repeat != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _date = snapshotData['date'] as DateTime?;
    _slots = snapshotData['slots'] is TimeSlotStruct
        ? snapshotData['slots']
        : TimeSlotStruct.maybeFromMap(snapshotData['slots']);
    _repeat = snapshotData['repeat'] as String?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('schedule')
          : FirebaseFirestore.instance.collectionGroup('schedule');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('schedule').doc(id);

  static Stream<ScheduleRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ScheduleRecord.fromSnapshot(s));

  static Future<ScheduleRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ScheduleRecord.fromSnapshot(s));

  static ScheduleRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ScheduleRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ScheduleRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ScheduleRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ScheduleRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ScheduleRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createScheduleRecordData({
  DateTime? date,
  TimeSlotStruct? slots,
  String? repeat,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'date': date,
      'slots': TimeSlotStruct().toMap(),
      'repeat': repeat,
    }.withoutNulls,
  );

  // Handle nested data for "slots" field.
  addTimeSlotStructData(firestoreData, slots, 'slots');

  return firestoreData;
}

class ScheduleRecordDocumentEquality implements Equality<ScheduleRecord> {
  const ScheduleRecordDocumentEquality();

  @override
  bool equals(ScheduleRecord? e1, ScheduleRecord? e2) {
    return e1?.date == e2?.date &&
        e1?.slots == e2?.slots &&
        e1?.repeat == e2?.repeat;
  }

  @override
  int hash(ScheduleRecord? e) =>
      const ListEquality().hash([e?.date, e?.slots, e?.repeat]);

  @override
  bool isValidKey(Object? o) => o is ScheduleRecord;
}
