import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class BackgroundSoundRecord extends FirestoreRecord {
  BackgroundSoundRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "Category" field.
  String? _category;
  String get category => _category ?? '';
  bool hasCategory() => _category != null;

  // "SoundPhoto" field.
  String? _soundPhoto;
  String get soundPhoto => _soundPhoto ?? '';
  bool hasSoundPhoto() => _soundPhoto != null;

  // "SoundDescription" field.
  String? _soundDescription;
  String get soundDescription => _soundDescription ?? '';
  bool hasSoundDescription() => _soundDescription != null;

  // "Soundsinfo" field.
  List<SoundsinfoStruct>? _soundsinfo;
  List<SoundsinfoStruct> get soundsinfo => _soundsinfo ?? const [];
  bool hasSoundsinfo() => _soundsinfo != null;

  void _initializeFields() {
    _category = snapshotData['Category'] as String?;
    _soundPhoto = snapshotData['SoundPhoto'] as String?;
    _soundDescription = snapshotData['SoundDescription'] as String?;
    _soundsinfo = getStructList(
      snapshotData['Soundsinfo'],
      SoundsinfoStruct.fromMap,
    );
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('backgroundSound');

  static Stream<BackgroundSoundRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => BackgroundSoundRecord.fromSnapshot(s));

  static Future<BackgroundSoundRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => BackgroundSoundRecord.fromSnapshot(s));

  static BackgroundSoundRecord fromSnapshot(DocumentSnapshot snapshot) =>
      BackgroundSoundRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static BackgroundSoundRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      BackgroundSoundRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'BackgroundSoundRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is BackgroundSoundRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createBackgroundSoundRecordData({
  String? category,
  String? soundPhoto,
  String? soundDescription,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'Category': category,
      'SoundPhoto': soundPhoto,
      'SoundDescription': soundDescription,
    }.withoutNulls,
  );

  return firestoreData;
}

class BackgroundSoundRecordDocumentEquality
    implements Equality<BackgroundSoundRecord> {
  const BackgroundSoundRecordDocumentEquality();

  @override
  bool equals(BackgroundSoundRecord? e1, BackgroundSoundRecord? e2) {
    const listEquality = ListEquality();
    return e1?.category == e2?.category &&
        e1?.soundPhoto == e2?.soundPhoto &&
        e1?.soundDescription == e2?.soundDescription &&
        listEquality.equals(e1?.soundsinfo, e2?.soundsinfo);
  }

  @override
  int hash(BackgroundSoundRecord? e) => const ListEquality()
      .hash([e?.category, e?.soundPhoto, e?.soundDescription, e?.soundsinfo]);

  @override
  bool isValidKey(Object? o) => o is BackgroundSoundRecord;
}
