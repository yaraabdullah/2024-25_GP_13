import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class BookingsRecord extends FirestoreRecord {
  BookingsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "date" field.
  String? _date;
  String get date => _date ?? '';
  bool hasDate() => _date != null;

  // "time" field.
  double? _time;
  double get time => _time ?? 0.0;
  bool hasTime() => _time != null;

  // "doctor" field.
  DocumentReference? _doctor;
  DocumentReference? get doctor => _doctor;
  bool hasDoctor() => _doctor != null;

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "age" field.
  int? _age;
  int get age => _age ?? 0;
  bool hasAge() => _age != null;

  // "about" field.
  String? _about;
  String get about => _about ?? '';
  bool hasAbout() => _about != null;

  // "bookingid" field.
  DocumentReference? _bookingid;
  DocumentReference? get bookingid => _bookingid;
  bool hasBookingid() => _bookingid != null;

  // "status" field.
  String? _status;
  String get status => _status ?? '';
  bool hasStatus() => _status != null;

  // "isAvailable" field.
  bool? _isAvailable;
  bool get isAvailable => _isAvailable ?? false;
  bool hasIsAvailable() => _isAvailable != null;

  // "bookedSlot" field.
  TimeSlotStruct? _bookedSlot;
  TimeSlotStruct get bookedSlot => _bookedSlot ?? TimeSlotStruct();
  bool hasBookedSlot() => _bookedSlot != null;

  // "bookingNum" field.
  int? _bookingNum;
  int get bookingNum => _bookingNum ?? 0;
  bool hasBookingNum() => _bookingNum != null;

  // "userId" field.
  DocumentReference? _userId;
  DocumentReference? get userId => _userId;
  bool hasUserId() => _userId != null;

  // "docid" field.
  DocumentReference? _docid;
  DocumentReference? get docid => _docid;
  bool hasDocid() => _docid != null;

  // "rating" field.
  List<int>? _rating;
  List<int> get rating => _rating ?? const [];
  bool hasRating() => _rating != null;

  // "report" field.
  String? _report;
  String get report => _report ?? '';
  bool hasReport() => _report != null;

  // "reportMessage" field.
  String? _reportMessage;
  String get reportMessage => _reportMessage ?? '';
  bool hasReportMessage() => _reportMessage != null;

  // "bookedby" field.
  String? _bookedby;
  String get bookedby => _bookedby ?? '';
  bool hasBookedby() => _bookedby != null;

  // "slottime" field.
  String? _slottime;
  String get slottime => _slottime ?? '';
  bool hasSlottime() => _slottime != null;

  // "user" field.
  String? _user;
  String get user => _user ?? '';
  bool hasUser() => _user != null;

  // "cancelled" field.
  bool? _cancelled;
  bool get cancelled => _cancelled ?? false;
  bool hasCancelled() => _cancelled != null;

  // "scheduledId" field.
  String? _scheduledId;
  String get scheduledId => _scheduledId ?? '';
  bool hasScheduledId() => _scheduledId != null;

  // "zoompass" field.
  String? _zoompass;
  String get zoompass => _zoompass ?? '';
  bool hasZoompass() => _zoompass != null;

  // "zoomlink" field.
  String? _zoomlink;
  String get zoomlink => _zoomlink ?? '';
  bool hasZoomlink() => _zoomlink != null;

  // "cancelledBy" field.
  String? _cancelledBy;
  String get cancelledBy => _cancelledBy ?? '';
  bool hasCancelledBy() => _cancelledBy != null;

  // "cancelledReason" field.
  String? _cancelledReason;
  String get cancelledReason => _cancelledReason ?? '';
  bool hasCancelledReason() => _cancelledReason != null;

  void _initializeFields() {
    _date = snapshotData['date'] as String?;
    _time = castToType<double>(snapshotData['time']);
    _doctor = snapshotData['doctor'] as DocumentReference?;
    _name = snapshotData['name'] as String?;
    _age = castToType<int>(snapshotData['age']);
    _about = snapshotData['about'] as String?;
    _bookingid = snapshotData['bookingid'] as DocumentReference?;
    _status = snapshotData['status'] as String?;
    _isAvailable = snapshotData['isAvailable'] as bool?;
    _bookedSlot = snapshotData['bookedSlot'] is TimeSlotStruct
        ? snapshotData['bookedSlot']
        : TimeSlotStruct.maybeFromMap(snapshotData['bookedSlot']);
    _bookingNum = castToType<int>(snapshotData['bookingNum']);
    _userId = snapshotData['userId'] as DocumentReference?;
    _docid = snapshotData['docid'] as DocumentReference?;
    _rating = getDataList(snapshotData['rating']);
    _report = snapshotData['report'] as String?;
    _reportMessage = snapshotData['reportMessage'] as String?;
    _bookedby = snapshotData['bookedby'] as String?;
    _slottime = snapshotData['slottime'] as String?;
    _user = snapshotData['user'] as String?;
    _cancelled = snapshotData['cancelled'] as bool?;
    _scheduledId = snapshotData['scheduledId'] as String?;
    _zoompass = snapshotData['zoompass'] as String?;
    _zoomlink = snapshotData['zoomlink'] as String?;
    _cancelledBy = snapshotData['cancelledBy'] as String?;
    _cancelledReason = snapshotData['cancelledReason'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('bookings');

  static Stream<BookingsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => BookingsRecord.fromSnapshot(s));

  static Future<BookingsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => BookingsRecord.fromSnapshot(s));

  static BookingsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      BookingsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static BookingsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      BookingsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'BookingsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is BookingsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createBookingsRecordData({
  String? date,
  double? time,
  DocumentReference? doctor,
  String? name,
  int? age,
  String? about,
  DocumentReference? bookingid,
  String? status,
  bool? isAvailable,
  TimeSlotStruct? bookedSlot,
  int? bookingNum,
  DocumentReference? userId,
  DocumentReference? docid,
  String? report,
  String? reportMessage,
  String? bookedby,
  String? slottime,
  String? user,
  bool? cancelled,
  String? scheduledId,
  String? zoompass,
  String? zoomlink,
  String? cancelledBy,
  String? cancelledReason,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'date': date,
      'time': time,
      'doctor': doctor,
      'name': name,
      'age': age,
      'about': about,
      'bookingid': bookingid,
      'status': status,
      'isAvailable': isAvailable,
      'bookedSlot': TimeSlotStruct().toMap(),
      'bookingNum': bookingNum,
      'userId': userId,
      'docid': docid,
      'report': report,
      'reportMessage': reportMessage,
      'bookedby': bookedby,
      'slottime': slottime,
      'user': user,
      'cancelled': cancelled,
      'scheduledId': scheduledId,
      'zoompass': zoompass,
      'zoomlink': zoomlink,
      'cancelledBy': cancelledBy,
      'cancelledReason': cancelledReason,
    }.withoutNulls,
  );

  // Handle nested data for "bookedSlot" field.
  addTimeSlotStructData(firestoreData, bookedSlot, 'bookedSlot');

  return firestoreData;
}

class BookingsRecordDocumentEquality implements Equality<BookingsRecord> {
  const BookingsRecordDocumentEquality();

  @override
  bool equals(BookingsRecord? e1, BookingsRecord? e2) {
    const listEquality = ListEquality();
    return e1?.date == e2?.date &&
        e1?.time == e2?.time &&
        e1?.doctor == e2?.doctor &&
        e1?.name == e2?.name &&
        e1?.age == e2?.age &&
        e1?.about == e2?.about &&
        e1?.bookingid == e2?.bookingid &&
        e1?.status == e2?.status &&
        e1?.isAvailable == e2?.isAvailable &&
        e1?.bookedSlot == e2?.bookedSlot &&
        e1?.bookingNum == e2?.bookingNum &&
        e1?.userId == e2?.userId &&
        e1?.docid == e2?.docid &&
        listEquality.equals(e1?.rating, e2?.rating) &&
        e1?.report == e2?.report &&
        e1?.reportMessage == e2?.reportMessage &&
        e1?.bookedby == e2?.bookedby &&
        e1?.slottime == e2?.slottime &&
        e1?.user == e2?.user &&
        e1?.cancelled == e2?.cancelled &&
        e1?.scheduledId == e2?.scheduledId &&
        e1?.zoompass == e2?.zoompass &&
        e1?.zoomlink == e2?.zoomlink &&
        e1?.cancelledBy == e2?.cancelledBy &&
        e1?.cancelledReason == e2?.cancelledReason;
  }

  @override
  int hash(BookingsRecord? e) => const ListEquality().hash([
        e?.date,
        e?.time,
        e?.doctor,
        e?.name,
        e?.age,
        e?.about,
        e?.bookingid,
        e?.status,
        e?.isAvailable,
        e?.bookedSlot,
        e?.bookingNum,
        e?.userId,
        e?.docid,
        e?.rating,
        e?.report,
        e?.reportMessage,
        e?.bookedby,
        e?.slottime,
        e?.user,
        e?.cancelled,
        e?.scheduledId,
        e?.zoompass,
        e?.zoomlink,
        e?.cancelledBy,
        e?.cancelledReason
      ]);

  @override
  bool isValidKey(Object? o) => o is BookingsRecord;
}
