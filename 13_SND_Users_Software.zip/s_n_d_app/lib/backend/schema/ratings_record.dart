import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class RatingsRecord extends FirestoreRecord {
  RatingsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "appointmentID" field.
  DocumentReference? _appointmentID;
  DocumentReference? get appointmentID => _appointmentID;
  bool hasAppointmentID() => _appointmentID != null;

  // "booking" field.
  DocumentReference? _booking;
  DocumentReference? get booking => _booking;
  bool hasBooking() => _booking != null;

  // "doctorname" field.
  DocumentReference? _doctorname;
  DocumentReference? get doctorname => _doctorname;
  bool hasDoctorname() => _doctorname != null;

  // "username" field.
  DocumentReference? _username;
  DocumentReference? get username => _username;
  bool hasUsername() => _username != null;

  // "rating" field.
  int? _rating;
  int get rating => _rating ?? 0;
  bool hasRating() => _rating != null;

  // "id" field.
  String? _id;
  String get id => _id ?? '';
  bool hasId() => _id != null;

  void _initializeFields() {
    _appointmentID = snapshotData['appointmentID'] as DocumentReference?;
    _booking = snapshotData['booking'] as DocumentReference?;
    _doctorname = snapshotData['doctorname'] as DocumentReference?;
    _username = snapshotData['username'] as DocumentReference?;
    _rating = castToType<int>(snapshotData['rating']);
    _id = snapshotData['id'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Ratings');

  static Stream<RatingsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => RatingsRecord.fromSnapshot(s));

  static Future<RatingsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => RatingsRecord.fromSnapshot(s));

  static RatingsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      RatingsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static RatingsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      RatingsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'RatingsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is RatingsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createRatingsRecordData({
  DocumentReference? appointmentID,
  DocumentReference? booking,
  DocumentReference? doctorname,
  DocumentReference? username,
  int? rating,
  String? id,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'appointmentID': appointmentID,
      'booking': booking,
      'doctorname': doctorname,
      'username': username,
      'rating': rating,
      'id': id,
    }.withoutNulls,
  );

  return firestoreData;
}

class RatingsRecordDocumentEquality implements Equality<RatingsRecord> {
  const RatingsRecordDocumentEquality();

  @override
  bool equals(RatingsRecord? e1, RatingsRecord? e2) {
    return e1?.appointmentID == e2?.appointmentID &&
        e1?.booking == e2?.booking &&
        e1?.doctorname == e2?.doctorname &&
        e1?.username == e2?.username &&
        e1?.rating == e2?.rating &&
        e1?.id == e2?.id;
  }

  @override
  int hash(RatingsRecord? e) => const ListEquality().hash([
        e?.appointmentID,
        e?.booking,
        e?.doctorname,
        e?.username,
        e?.rating,
        e?.id
      ]);

  @override
  bool isValidKey(Object? o) => o is RatingsRecord;
}
