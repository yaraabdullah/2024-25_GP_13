import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class UsersRecord extends FirestoreRecord {
  UsersRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "display_name" field.
  String? _displayName;
  String get displayName => _displayName ?? '';
  bool hasDisplayName() => _displayName != null;

  // "password" field.
  String? _password;
  String get password => _password ?? '';
  bool hasPassword() => _password != null;

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "DOB" field.
  DateTime? _dob;
  DateTime? get dob => _dob;
  bool hasDob() => _dob != null;

  // "about" field.
  String? _about;
  String get about => _about ?? '';
  bool hasAbout() => _about != null;

  // "speciality" field.
  String? _speciality;
  String get speciality => _speciality ?? '';
  bool hasSpeciality() => _speciality != null;

  // "cv" field.
  String? _cv;
  String get cv => _cv ?? '';
  bool hasCv() => _cv != null;

  // "photo_url" field.
  String? _photoUrl;
  String get photoUrl => _photoUrl ?? '';
  bool hasPhotoUrl() => _photoUrl != null;

  // "phone_number" field.
  String? _phoneNumber;
  String get phoneNumber => _phoneNumber ?? '';
  bool hasPhoneNumber() => _phoneNumber != null;

  // "created_time" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  // "uid" field.
  String? _uid;
  String get uid => _uid ?? '';
  bool hasUid() => _uid != null;

  // "first_name" field.
  String? _firstName;
  String get firstName => _firstName ?? '';
  bool hasFirstName() => _firstName != null;

  // "last_name" field.
  String? _lastName;
  String get lastName => _lastName ?? '';
  bool hasLastName() => _lastName != null;

  // "isStudent" field.
  bool? _isStudent;
  bool get isStudent => _isStudent ?? false;
  bool hasIsStudent() => _isStudent != null;

  // "isApproved" field.
  bool? _isApproved;
  bool get isApproved => _isApproved ?? false;
  bool hasIsApproved() => _isApproved != null;

  // "subSpecialty" field.
  List<String>? _subSpecialty;
  List<String> get subSpecialty => _subSpecialty ?? const [];
  bool hasSubSpecialty() => _subSpecialty != null;

  // "status" field.
  String? _status;
  String get status => _status ?? '';
  bool hasStatus() => _status != null;

  // "Languages" field.
  List<String>? _languages;
  List<String> get languages => _languages ?? const [];
  bool hasLanguages() => _languages != null;

  // "availableSlots" field.
  List<TimeSlotStruct>? _availableSlots;
  List<TimeSlotStruct> get availableSlots => _availableSlots ?? const [];
  bool hasAvailableSlots() => _availableSlots != null;

  // "requestedInfo" field.
  String? _requestedInfo;
  String get requestedInfo => _requestedInfo ?? '';
  bool hasRequestedInfo() => _requestedInfo != null;

  // "ava" field.
  List<AvailabilityStruct>? _ava;
  List<AvailabilityStruct> get ava => _ava ?? const [];
  bool hasAva() => _ava != null;

  // "last_notification_read_time" field.
  DateTime? _lastNotificationReadTime;
  DateTime? get lastNotificationReadTime => _lastNotificationReadTime;
  bool hasLastNotificationReadTime() => _lastNotificationReadTime != null;

  // "avai" field.
  List<AvailabilityStruct>? _avai;
  List<AvailabilityStruct> get avai => _avai ?? const [];
  bool hasAvai() => _avai != null;

  // "ratings" field.
  List<int>? _ratings;
  List<int> get ratings => _ratings ?? const [];
  bool hasRatings() => _ratings != null;

  // "ratedDoctor" field.
  List<DocumentReference>? _ratedDoctor;
  List<DocumentReference> get ratedDoctor => _ratedDoctor ?? const [];
  bool hasRatedDoctor() => _ratedDoctor != null;

  // "ratedAppointments" field.
  List<DocumentReference>? _ratedAppointments;
  List<DocumentReference> get ratedAppointments =>
      _ratedAppointments ?? const [];
  bool hasRatedAppointments() => _ratedAppointments != null;

  // "ratingId" field.
  List<String>? _ratingId;
  List<String> get ratingId => _ratingId ?? const [];
  bool hasRatingId() => _ratingId != null;

  // "userRef" field.
  DocumentReference? _userRef;
  DocumentReference? get userRef => _userRef;
  bool hasUserRef() => _userRef != null;

  // "depression_assesment" field.
  List<double>? _depressionAssesment;
  List<double> get depressionAssesment => _depressionAssesment ?? const [];
  bool hasDepressionAssesment() => _depressionAssesment != null;

  // "sleep_assesment" field.
  List<double>? _sleepAssesment;
  List<double> get sleepAssesment => _sleepAssesment ?? const [];
  bool hasSleepAssesment() => _sleepAssesment != null;

  // "anxiety_assesment" field.
  List<double>? _anxietyAssesment;
  List<double> get anxietyAssesment => _anxietyAssesment ?? const [];
  bool hasAnxietyAssesment() => _anxietyAssesment != null;

  // "tests" field.
  int? _tests;
  int get tests => _tests ?? 0;
  bool hasTests() => _tests != null;

  // "zoom" field.
  String? _zoom;
  String get zoom => _zoom ?? '';
  bool hasZoom() => _zoom != null;

  // "zoompass" field.
  String? _zoompass;
  String get zoompass => _zoompass ?? '';
  bool hasZoompass() => _zoompass != null;

  // "notificationFrequency" field.
  String? _notificationFrequency;
  String get notificationFrequency => _notificationFrequency ?? '';
  bool hasNotificationFrequency() => _notificationFrequency != null;

  // "lastNotificationSent" field.
  DateTime? _lastNotificationSent;
  DateTime? get lastNotificationSent => _lastNotificationSent;
  bool hasLastNotificationSent() => _lastNotificationSent != null;

  void _initializeFields() {
    _displayName = snapshotData['display_name'] as String?;
    _password = snapshotData['password'] as String?;
    _email = snapshotData['email'] as String?;
    _dob = snapshotData['DOB'] as DateTime?;
    _about = snapshotData['about'] as String?;
    _speciality = snapshotData['speciality'] as String?;
    _cv = snapshotData['cv'] as String?;
    _photoUrl = snapshotData['photo_url'] as String?;
    _phoneNumber = snapshotData['phone_number'] as String?;
    _createdTime = snapshotData['created_time'] as DateTime?;
    _uid = snapshotData['uid'] as String?;
    _firstName = snapshotData['first_name'] as String?;
    _lastName = snapshotData['last_name'] as String?;
    _isStudent = snapshotData['isStudent'] as bool?;
    _isApproved = snapshotData['isApproved'] as bool?;
    _subSpecialty = getDataList(snapshotData['subSpecialty']);
    _status = snapshotData['status'] as String?;
    _languages = getDataList(snapshotData['Languages']);
    _availableSlots = getStructList(
      snapshotData['availableSlots'],
      TimeSlotStruct.fromMap,
    );
    _requestedInfo = snapshotData['requestedInfo'] as String?;
    _ava = getStructList(
      snapshotData['ava'],
      AvailabilityStruct.fromMap,
    );
    _lastNotificationReadTime =
        snapshotData['last_notification_read_time'] as DateTime?;
    _avai = getStructList(
      snapshotData['avai'],
      AvailabilityStruct.fromMap,
    );
    _ratings = getDataList(snapshotData['ratings']);
    _ratedDoctor = getDataList(snapshotData['ratedDoctor']);
    _ratedAppointments = getDataList(snapshotData['ratedAppointments']);
    _ratingId = getDataList(snapshotData['ratingId']);
    _userRef = snapshotData['userRef'] as DocumentReference?;
    _depressionAssesment = getDataList(snapshotData['depression_assesment']);
    _sleepAssesment = getDataList(snapshotData['sleep_assesment']);
    _anxietyAssesment = getDataList(snapshotData['anxiety_assesment']);
    _tests = castToType<int>(snapshotData['tests']);
    _zoom = snapshotData['zoom'] as String?;
    _zoompass = snapshotData['zoompass'] as String?;
    _notificationFrequency = snapshotData['notificationFrequency'] as String?;
    _lastNotificationSent = snapshotData['lastNotificationSent'] as DateTime?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Users');

  static Stream<UsersRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => UsersRecord.fromSnapshot(s));

  static Future<UsersRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => UsersRecord.fromSnapshot(s));

  static UsersRecord fromSnapshot(DocumentSnapshot snapshot) => UsersRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static UsersRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      UsersRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'UsersRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is UsersRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createUsersRecordData({
  String? displayName,
  String? password,
  String? email,
  DateTime? dob,
  String? about,
  String? speciality,
  String? cv,
  String? photoUrl,
  String? phoneNumber,
  DateTime? createdTime,
  String? uid,
  String? firstName,
  String? lastName,
  bool? isStudent,
  bool? isApproved,
  String? status,
  String? requestedInfo,
  DateTime? lastNotificationReadTime,
  DocumentReference? userRef,
  int? tests,
  String? zoom,
  String? zoompass,
  String? notificationFrequency,
  DateTime? lastNotificationSent,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'display_name': displayName,
      'password': password,
      'email': email,
      'DOB': dob,
      'about': about,
      'speciality': speciality,
      'cv': cv,
      'photo_url': photoUrl,
      'phone_number': phoneNumber,
      'created_time': createdTime,
      'uid': uid,
      'first_name': firstName,
      'last_name': lastName,
      'isStudent': isStudent,
      'isApproved': isApproved,
      'status': status,
      'requestedInfo': requestedInfo,
      'last_notification_read_time': lastNotificationReadTime,
      'userRef': userRef,
      'tests': tests,
      'zoom': zoom,
      'zoompass': zoompass,
      'notificationFrequency': notificationFrequency,
      'lastNotificationSent': lastNotificationSent,
    }.withoutNulls,
  );

  return firestoreData;
}

class UsersRecordDocumentEquality implements Equality<UsersRecord> {
  const UsersRecordDocumentEquality();

  @override
  bool equals(UsersRecord? e1, UsersRecord? e2) {
    const listEquality = ListEquality();
    return e1?.displayName == e2?.displayName &&
        e1?.password == e2?.password &&
        e1?.email == e2?.email &&
        e1?.dob == e2?.dob &&
        e1?.about == e2?.about &&
        e1?.speciality == e2?.speciality &&
        e1?.cv == e2?.cv &&
        e1?.photoUrl == e2?.photoUrl &&
        e1?.phoneNumber == e2?.phoneNumber &&
        e1?.createdTime == e2?.createdTime &&
        e1?.uid == e2?.uid &&
        e1?.firstName == e2?.firstName &&
        e1?.lastName == e2?.lastName &&
        e1?.isStudent == e2?.isStudent &&
        e1?.isApproved == e2?.isApproved &&
        listEquality.equals(e1?.subSpecialty, e2?.subSpecialty) &&
        e1?.status == e2?.status &&
        listEquality.equals(e1?.languages, e2?.languages) &&
        listEquality.equals(e1?.availableSlots, e2?.availableSlots) &&
        e1?.requestedInfo == e2?.requestedInfo &&
        listEquality.equals(e1?.ava, e2?.ava) &&
        e1?.lastNotificationReadTime == e2?.lastNotificationReadTime &&
        listEquality.equals(e1?.avai, e2?.avai) &&
        listEquality.equals(e1?.ratings, e2?.ratings) &&
        listEquality.equals(e1?.ratedDoctor, e2?.ratedDoctor) &&
        listEquality.equals(e1?.ratedAppointments, e2?.ratedAppointments) &&
        listEquality.equals(e1?.ratingId, e2?.ratingId) &&
        e1?.userRef == e2?.userRef &&
        listEquality.equals(e1?.depressionAssesment, e2?.depressionAssesment) &&
        listEquality.equals(e1?.sleepAssesment, e2?.sleepAssesment) &&
        listEquality.equals(e1?.anxietyAssesment, e2?.anxietyAssesment) &&
        e1?.tests == e2?.tests &&
        e1?.zoom == e2?.zoom &&
        e1?.zoompass == e2?.zoompass &&
        e1?.notificationFrequency == e2?.notificationFrequency &&
        e1?.lastNotificationSent == e2?.lastNotificationSent;
  }

  @override
  int hash(UsersRecord? e) => const ListEquality().hash([
        e?.displayName,
        e?.password,
        e?.email,
        e?.dob,
        e?.about,
        e?.speciality,
        e?.cv,
        e?.photoUrl,
        e?.phoneNumber,
        e?.createdTime,
        e?.uid,
        e?.firstName,
        e?.lastName,
        e?.isStudent,
        e?.isApproved,
        e?.subSpecialty,
        e?.status,
        e?.languages,
        e?.availableSlots,
        e?.requestedInfo,
        e?.ava,
        e?.lastNotificationReadTime,
        e?.avai,
        e?.ratings,
        e?.ratedDoctor,
        e?.ratedAppointments,
        e?.ratingId,
        e?.userRef,
        e?.depressionAssesment,
        e?.sleepAssesment,
        e?.anxietyAssesment,
        e?.tests,
        e?.zoom,
        e?.zoompass,
        e?.notificationFrequency,
        e?.lastNotificationSent
      ]);

  @override
  bool isValidKey(Object? o) => o is UsersRecord;
}
