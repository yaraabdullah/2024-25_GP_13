// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class TimeStruct extends FFFirebaseStruct {
  TimeStruct({
    List<DateTime>? times,
    bool? isavailable,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _times = times,
        _isavailable = isavailable,
        super(firestoreUtilData);

  // "times" field.
  List<DateTime>? _times;
  List<DateTime> get times => _times ?? const [];
  set times(List<DateTime>? val) => _times = val;

  void updateTimes(Function(List<DateTime>) updateFn) {
    updateFn(_times ??= []);
  }

  bool hasTimes() => _times != null;

  // "isavailable" field.
  bool? _isavailable;
  bool get isavailable => _isavailable ?? false;
  set isavailable(bool? val) => _isavailable = val;

  bool hasIsavailable() => _isavailable != null;

  static TimeStruct fromMap(Map<String, dynamic> data) => TimeStruct(
        times: getDataList(data['times']),
        isavailable: data['isavailable'] as bool?,
      );

  static TimeStruct? maybeFromMap(dynamic data) =>
      data is Map ? TimeStruct.fromMap(data.cast<String, dynamic>()) : null;

  Map<String, dynamic> toMap() => {
        'times': _times,
        'isavailable': _isavailable,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'times': serializeParam(
          _times,
          ParamType.DateTime,
          isList: true,
        ),
        'isavailable': serializeParam(
          _isavailable,
          ParamType.bool,
        ),
      }.withoutNulls;

  static TimeStruct fromSerializableMap(Map<String, dynamic> data) =>
      TimeStruct(
        times: deserializeParam<DateTime>(
          data['times'],
          ParamType.DateTime,
          true,
        ),
        isavailable: deserializeParam(
          data['isavailable'],
          ParamType.bool,
          false,
        ),
      );

  @override
  String toString() => 'TimeStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is TimeStruct &&
        listEquality.equals(times, other.times) &&
        isavailable == other.isavailable;
  }

  @override
  int get hashCode => const ListEquality().hash([times, isavailable]);
}

TimeStruct createTimeStruct({
  bool? isavailable,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    TimeStruct(
      isavailable: isavailable,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

TimeStruct? updateTimeStruct(
  TimeStruct? time, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    time
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addTimeStructData(
  Map<String, dynamic> firestoreData,
  TimeStruct? time,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (time == null) {
    return;
  }
  if (time.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields = !forFieldValue && time.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final timeData = getTimeFirestoreData(time, forFieldValue);
  final nestedData = timeData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = time.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getTimeFirestoreData(
  TimeStruct? time, [
  bool forFieldValue = false,
]) {
  if (time == null) {
    return {};
  }
  final firestoreData = mapToFirestore(time.toMap());

  // Add any Firestore field values
  time.firestoreUtilData.fieldValues.forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getTimeListFirestoreData(
  List<TimeStruct>? times,
) =>
    times?.map((e) => getTimeFirestoreData(e, true)).toList() ?? [];
