// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SoundsinfoStruct extends FFFirebaseStruct {
  SoundsinfoStruct({
    String? title,
    String? sound,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _title = title,
        _sound = sound,
        super(firestoreUtilData);

  // "title" field.
  String? _title;
  String get title => _title ?? '';
  set title(String? val) => _title = val;

  bool hasTitle() => _title != null;

  // "sound" field.
  String? _sound;
  String get sound => _sound ?? '';
  set sound(String? val) => _sound = val;

  bool hasSound() => _sound != null;

  static SoundsinfoStruct fromMap(Map<String, dynamic> data) =>
      SoundsinfoStruct(
        title: data['title'] as String?,
        sound: data['sound'] as String?,
      );

  static SoundsinfoStruct? maybeFromMap(dynamic data) => data is Map
      ? SoundsinfoStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'title': _title,
        'sound': _sound,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'title': serializeParam(
          _title,
          ParamType.String,
        ),
        'sound': serializeParam(
          _sound,
          ParamType.String,
        ),
      }.withoutNulls;

  static SoundsinfoStruct fromSerializableMap(Map<String, dynamic> data) =>
      SoundsinfoStruct(
        title: deserializeParam(
          data['title'],
          ParamType.String,
          false,
        ),
        sound: deserializeParam(
          data['sound'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'SoundsinfoStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is SoundsinfoStruct &&
        title == other.title &&
        sound == other.sound;
  }

  @override
  int get hashCode => const ListEquality().hash([title, sound]);
}

SoundsinfoStruct createSoundsinfoStruct({
  String? title,
  String? sound,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    SoundsinfoStruct(
      title: title,
      sound: sound,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

SoundsinfoStruct? updateSoundsinfoStruct(
  SoundsinfoStruct? soundsinfo, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    soundsinfo
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addSoundsinfoStructData(
  Map<String, dynamic> firestoreData,
  SoundsinfoStruct? soundsinfo,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (soundsinfo == null) {
    return;
  }
  if (soundsinfo.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && soundsinfo.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final soundsinfoData = getSoundsinfoFirestoreData(soundsinfo, forFieldValue);
  final nestedData = soundsinfoData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = soundsinfo.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getSoundsinfoFirestoreData(
  SoundsinfoStruct? soundsinfo, [
  bool forFieldValue = false,
]) {
  if (soundsinfo == null) {
    return {};
  }
  final firestoreData = mapToFirestore(soundsinfo.toMap());

  // Add any Firestore field values
  soundsinfo.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getSoundsinfoListFirestoreData(
  List<SoundsinfoStruct>? soundsinfos,
) =>
    soundsinfos?.map((e) => getSoundsinfoFirestoreData(e, true)).toList() ?? [];
