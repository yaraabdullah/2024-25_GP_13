// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class RightpathStruct extends FFFirebaseStruct {
  RightpathStruct({
    bool? smilingornot,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _smilingornot = smilingornot,
        super(firestoreUtilData);

  // "smilingornot" field.
  bool? _smilingornot;
  bool get smilingornot => _smilingornot ?? false;
  set smilingornot(bool? val) => _smilingornot = val;

  bool hasSmilingornot() => _smilingornot != null;

  static RightpathStruct fromMap(Map<String, dynamic> data) => RightpathStruct(
        smilingornot: data['smilingornot'] as bool?,
      );

  static RightpathStruct? maybeFromMap(dynamic data) => data is Map
      ? RightpathStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'smilingornot': _smilingornot,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'smilingornot': serializeParam(
          _smilingornot,
          ParamType.bool,
        ),
      }.withoutNulls;

  static RightpathStruct fromSerializableMap(Map<String, dynamic> data) =>
      RightpathStruct(
        smilingornot: deserializeParam(
          data['smilingornot'],
          ParamType.bool,
          false,
        ),
      );

  @override
  String toString() => 'RightpathStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is RightpathStruct && smilingornot == other.smilingornot;
  }

  @override
  int get hashCode => const ListEquality().hash([smilingornot]);
}

RightpathStruct createRightpathStruct({
  bool? smilingornot,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    RightpathStruct(
      smilingornot: smilingornot,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

RightpathStruct? updateRightpathStruct(
  RightpathStruct? rightpath, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    rightpath
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addRightpathStructData(
  Map<String, dynamic> firestoreData,
  RightpathStruct? rightpath,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (rightpath == null) {
    return;
  }
  if (rightpath.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && rightpath.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final rightpathData = getRightpathFirestoreData(rightpath, forFieldValue);
  final nestedData = rightpathData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = rightpath.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getRightpathFirestoreData(
  RightpathStruct? rightpath, [
  bool forFieldValue = false,
]) {
  if (rightpath == null) {
    return {};
  }
  final firestoreData = mapToFirestore(rightpath.toMap());

  // Add any Firestore field values
  rightpath.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getRightpathListFirestoreData(
  List<RightpathStruct>? rightpaths,
) =>
    rightpaths?.map((e) => getRightpathFirestoreData(e, true)).toList() ?? [];
