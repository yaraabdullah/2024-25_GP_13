// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SmilealbumStruct extends FFFirebaseStruct {
  SmilealbumStruct({
    bool? smiling,
    String? picpath,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _smiling = smiling,
        _picpath = picpath,
        super(firestoreUtilData);

  // "smiling" field.
  bool? _smiling;
  bool get smiling => _smiling ?? false;
  set smiling(bool? val) => _smiling = val;

  bool hasSmiling() => _smiling != null;

  // "picpath" field.
  String? _picpath;
  String get picpath => _picpath ?? '';
  set picpath(String? val) => _picpath = val;

  bool hasPicpath() => _picpath != null;

  static SmilealbumStruct fromMap(Map<String, dynamic> data) =>
      SmilealbumStruct(
        smiling: data['smiling'] as bool?,
        picpath: data['picpath'] as String?,
      );

  static SmilealbumStruct? maybeFromMap(dynamic data) => data is Map
      ? SmilealbumStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'smiling': _smiling,
        'picpath': _picpath,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'smiling': serializeParam(
          _smiling,
          ParamType.bool,
        ),
        'picpath': serializeParam(
          _picpath,
          ParamType.String,
        ),
      }.withoutNulls;

  static SmilealbumStruct fromSerializableMap(Map<String, dynamic> data) =>
      SmilealbumStruct(
        smiling: deserializeParam(
          data['smiling'],
          ParamType.bool,
          false,
        ),
        picpath: deserializeParam(
          data['picpath'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'SmilealbumStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is SmilealbumStruct &&
        smiling == other.smiling &&
        picpath == other.picpath;
  }

  @override
  int get hashCode => const ListEquality().hash([smiling, picpath]);
}

SmilealbumStruct createSmilealbumStruct({
  bool? smiling,
  String? picpath,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    SmilealbumStruct(
      smiling: smiling,
      picpath: picpath,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

SmilealbumStruct? updateSmilealbumStruct(
  SmilealbumStruct? smilealbum, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    smilealbum
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addSmilealbumStructData(
  Map<String, dynamic> firestoreData,
  SmilealbumStruct? smilealbum,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (smilealbum == null) {
    return;
  }
  if (smilealbum.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && smilealbum.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final smilealbumData = getSmilealbumFirestoreData(smilealbum, forFieldValue);
  final nestedData = smilealbumData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = smilealbum.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getSmilealbumFirestoreData(
  SmilealbumStruct? smilealbum, [
  bool forFieldValue = false,
]) {
  if (smilealbum == null) {
    return {};
  }
  final firestoreData = mapToFirestore(smilealbum.toMap());

  // Add any Firestore field values
  smilealbum.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getSmilealbumListFirestoreData(
  List<SmilealbumStruct>? smilealbums,
) =>
    smilealbums?.map((e) => getSmilealbumFirestoreData(e, true)).toList() ?? [];
