import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ScheduledNotificationsRecord extends FirestoreRecord {
  ScheduledNotificationsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "notification_title" field.
  String? _notificationTitle;
  String get notificationTitle => _notificationTitle ?? '';
  bool hasNotificationTitle() => _notificationTitle != null;

  // "notification_body" field.
  String? _notificationBody;
  String get notificationBody => _notificationBody ?? '';
  bool hasNotificationBody() => _notificationBody != null;

  // "scheduled_time" field.
  DateTime? _scheduledTime;
  DateTime? get scheduledTime => _scheduledTime;
  bool hasScheduledTime() => _scheduledTime != null;

  // "user_id" field.
  DocumentReference? _userId;
  DocumentReference? get userId => _userId;
  bool hasUserId() => _userId != null;

  void _initializeFields() {
    _notificationTitle = snapshotData['notification_title'] as String?;
    _notificationBody = snapshotData['notification_body'] as String?;
    _scheduledTime = snapshotData['scheduled_time'] as DateTime?;
    _userId = snapshotData['user_id'] as DocumentReference?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('scheduled_notifications');

  static Stream<ScheduledNotificationsRecord> getDocument(
          DocumentReference ref) =>
      ref.snapshots().map((s) => ScheduledNotificationsRecord.fromSnapshot(s));

  static Future<ScheduledNotificationsRecord> getDocumentOnce(
          DocumentReference ref) =>
      ref.get().then((s) => ScheduledNotificationsRecord.fromSnapshot(s));

  static ScheduledNotificationsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ScheduledNotificationsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ScheduledNotificationsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ScheduledNotificationsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ScheduledNotificationsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ScheduledNotificationsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createScheduledNotificationsRecordData({
  String? notificationTitle,
  String? notificationBody,
  DateTime? scheduledTime,
  DocumentReference? userId,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'notification_title': notificationTitle,
      'notification_body': notificationBody,
      'scheduled_time': scheduledTime,
      'user_id': userId,
    }.withoutNulls,
  );

  return firestoreData;
}

class ScheduledNotificationsRecordDocumentEquality
    implements Equality<ScheduledNotificationsRecord> {
  const ScheduledNotificationsRecordDocumentEquality();

  @override
  bool equals(
      ScheduledNotificationsRecord? e1, ScheduledNotificationsRecord? e2) {
    return e1?.notificationTitle == e2?.notificationTitle &&
        e1?.notificationBody == e2?.notificationBody &&
        e1?.scheduledTime == e2?.scheduledTime &&
        e1?.userId == e2?.userId;
  }

  @override
  int hash(ScheduledNotificationsRecord? e) => const ListEquality().hash(
      [e?.notificationTitle, e?.notificationBody, e?.scheduledTime, e?.userId]);

  @override
  bool isValidKey(Object? o) => o is ScheduledNotificationsRecord;
}
