import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ArticlesRecord extends FirestoreRecord {
  ArticlesRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "ArticleName" field.
  String? _articleName;
  String get articleName => _articleName ?? '';
  bool hasArticleName() => _articleName != null;

  // "WriterName" field.
  String? _writerName;
  String get writerName => _writerName ?? '';
  bool hasWriterName() => _writerName != null;

  // "ArticleContent" field.
  String? _articleContent;
  String get articleContent => _articleContent ?? '';
  bool hasArticleContent() => _articleContent != null;

  // "ArticleImage" field.
  String? _articleImage;
  String get articleImage => _articleImage ?? '';
  bool hasArticleImage() => _articleImage != null;

  // "ArticleURL" field.
  String? _articleURL;
  String get articleURL => _articleURL ?? '';
  bool hasArticleURL() => _articleURL != null;

  // "ArticleTittle" field.
  String? _articleTittle;
  String get articleTittle => _articleTittle ?? '';
  bool hasArticleTittle() => _articleTittle != null;

  void _initializeFields() {
    _articleName = snapshotData['ArticleName'] as String?;
    _writerName = snapshotData['WriterName'] as String?;
    _articleContent = snapshotData['ArticleContent'] as String?;
    _articleImage = snapshotData['ArticleImage'] as String?;
    _articleURL = snapshotData['ArticleURL'] as String?;
    _articleTittle = snapshotData['ArticleTittle'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Articles');

  static Stream<ArticlesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ArticlesRecord.fromSnapshot(s));

  static Future<ArticlesRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ArticlesRecord.fromSnapshot(s));

  static ArticlesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ArticlesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ArticlesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ArticlesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ArticlesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ArticlesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createArticlesRecordData({
  String? articleName,
  String? writerName,
  String? articleContent,
  String? articleImage,
  String? articleURL,
  String? articleTittle,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'ArticleName': articleName,
      'WriterName': writerName,
      'ArticleContent': articleContent,
      'ArticleImage': articleImage,
      'ArticleURL': articleURL,
      'ArticleTittle': articleTittle,
    }.withoutNulls,
  );

  return firestoreData;
}

class ArticlesRecordDocumentEquality implements Equality<ArticlesRecord> {
  const ArticlesRecordDocumentEquality();

  @override
  bool equals(ArticlesRecord? e1, ArticlesRecord? e2) {
    return e1?.articleName == e2?.articleName &&
        e1?.writerName == e2?.writerName &&
        e1?.articleContent == e2?.articleContent &&
        e1?.articleImage == e2?.articleImage &&
        e1?.articleURL == e2?.articleURL &&
        e1?.articleTittle == e2?.articleTittle;
  }

  @override
  int hash(ArticlesRecord? e) => const ListEquality().hash([
        e?.articleName,
        e?.writerName,
        e?.articleContent,
        e?.articleImage,
        e?.articleURL,
        e?.articleTittle
      ]);

  @override
  bool isValidKey(Object? o) => o is ArticlesRecord;
}
