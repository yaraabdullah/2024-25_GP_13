import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SmileAlbumRecord extends FirestoreRecord {
  SmileAlbumRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "studentID" field.
  DocumentReference? _studentID;
  DocumentReference? get studentID => _studentID;
  bool hasStudentID() => _studentID != null;

  // "picture" field.
  String? _picture;
  String get picture => _picture ?? '';
  bool hasPicture() => _picture != null;

  void _initializeFields() {
    _studentID = snapshotData['studentID'] as DocumentReference?;
    _picture = snapshotData['picture'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('SmileAlbum');

  static Stream<SmileAlbumRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => SmileAlbumRecord.fromSnapshot(s));

  static Future<SmileAlbumRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => SmileAlbumRecord.fromSnapshot(s));

  static SmileAlbumRecord fromSnapshot(DocumentSnapshot snapshot) =>
      SmileAlbumRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static SmileAlbumRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      SmileAlbumRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'SmileAlbumRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is SmileAlbumRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createSmileAlbumRecordData({
  DocumentReference? studentID,
  String? picture,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'studentID': studentID,
      'picture': picture,
    }.withoutNulls,
  );

  return firestoreData;
}

class SmileAlbumRecordDocumentEquality implements Equality<SmileAlbumRecord> {
  const SmileAlbumRecordDocumentEquality();

  @override
  bool equals(SmileAlbumRecord? e1, SmileAlbumRecord? e2) {
    return e1?.studentID == e2?.studentID && e1?.picture == e2?.picture;
  }

  @override
  int hash(SmileAlbumRecord? e) =>
      const ListEquality().hash([e?.studentID, e?.picture]);

  @override
  bool isValidKey(Object? o) => o is SmileAlbumRecord;
}
