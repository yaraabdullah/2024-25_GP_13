import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class VirtualhospitalRecord extends FirestoreRecord {
  VirtualhospitalRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "doctorName" field.
  String? _doctorName;
  String get doctorName => _doctorName ?? '';
  bool hasDoctorName() => _doctorName != null;

  // "Date" field.
  DateTime? _date;
  DateTime? get date => _date;
  bool hasDate() => _date != null;

  // "studentDOB" field.
  DateTime? _studentDOB;
  DateTime? get studentDOB => _studentDOB;
  bool hasStudentDOB() => _studentDOB != null;

  // "studentFirstName" field.
  String? _studentFirstName;
  String get studentFirstName => _studentFirstName ?? '';
  bool hasStudentFirstName() => _studentFirstName != null;

  // "studentLastName" field.
  String? _studentLastName;
  String get studentLastName => _studentLastName ?? '';
  bool hasStudentLastName() => _studentLastName != null;

  // "StudentNationalID" field.
  int? _studentNationalID;
  int get studentNationalID => _studentNationalID ?? 0;
  bool hasStudentNationalID() => _studentNationalID != null;

  // "userId" field.
  DocumentReference? _userId;
  DocumentReference? get userId => _userId;
  bool hasUserId() => _userId != null;

  // "ClinicName" field.
  String? _clinicName;
  String get clinicName => _clinicName ?? '';
  bool hasClinicName() => _clinicName != null;

  // "Time" field.
  String? _time;
  String get time => _time ?? '';
  bool hasTime() => _time != null;

  // "studentPhoneNumber" field.
  String? _studentPhoneNumber;
  String get studentPhoneNumber => _studentPhoneNumber ?? '';
  bool hasStudentPhoneNumber() => _studentPhoneNumber != null;

  void _initializeFields() {
    _doctorName = snapshotData['doctorName'] as String?;
    _date = snapshotData['Date'] as DateTime?;
    _studentDOB = snapshotData['studentDOB'] as DateTime?;
    _studentFirstName = snapshotData['studentFirstName'] as String?;
    _studentLastName = snapshotData['studentLastName'] as String?;
    _studentNationalID = castToType<int>(snapshotData['StudentNationalID']);
    _userId = snapshotData['userId'] as DocumentReference?;
    _clinicName = snapshotData['ClinicName'] as String?;
    _time = snapshotData['Time'] as String?;
    _studentPhoneNumber = snapshotData['studentPhoneNumber'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('virtualhospital');

  static Stream<VirtualhospitalRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => VirtualhospitalRecord.fromSnapshot(s));

  static Future<VirtualhospitalRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => VirtualhospitalRecord.fromSnapshot(s));

  static VirtualhospitalRecord fromSnapshot(DocumentSnapshot snapshot) =>
      VirtualhospitalRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static VirtualhospitalRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      VirtualhospitalRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'VirtualhospitalRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is VirtualhospitalRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createVirtualhospitalRecordData({
  String? doctorName,
  DateTime? date,
  DateTime? studentDOB,
  String? studentFirstName,
  String? studentLastName,
  int? studentNationalID,
  DocumentReference? userId,
  String? clinicName,
  String? time,
  String? studentPhoneNumber,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'doctorName': doctorName,
      'Date': date,
      'studentDOB': studentDOB,
      'studentFirstName': studentFirstName,
      'studentLastName': studentLastName,
      'StudentNationalID': studentNationalID,
      'userId': userId,
      'ClinicName': clinicName,
      'Time': time,
      'studentPhoneNumber': studentPhoneNumber,
    }.withoutNulls,
  );

  return firestoreData;
}

class VirtualhospitalRecordDocumentEquality
    implements Equality<VirtualhospitalRecord> {
  const VirtualhospitalRecordDocumentEquality();

  @override
  bool equals(VirtualhospitalRecord? e1, VirtualhospitalRecord? e2) {
    return e1?.doctorName == e2?.doctorName &&
        e1?.date == e2?.date &&
        e1?.studentDOB == e2?.studentDOB &&
        e1?.studentFirstName == e2?.studentFirstName &&
        e1?.studentLastName == e2?.studentLastName &&
        e1?.studentNationalID == e2?.studentNationalID &&
        e1?.userId == e2?.userId &&
        e1?.clinicName == e2?.clinicName &&
        e1?.time == e2?.time &&
        e1?.studentPhoneNumber == e2?.studentPhoneNumber;
  }

  @override
  int hash(VirtualhospitalRecord? e) => const ListEquality().hash([
        e?.doctorName,
        e?.date,
        e?.studentDOB,
        e?.studentFirstName,
        e?.studentLastName,
        e?.studentNationalID,
        e?.userId,
        e?.clinicName,
        e?.time,
        e?.studentPhoneNumber
      ]);

  @override
  bool isValidKey(Object? o) => o is VirtualhospitalRecord;
}
