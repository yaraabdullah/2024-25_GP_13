import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class TestsRecord extends FirestoreRecord {
  TestsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "category_name" field.
  String? _categoryName;
  String get categoryName => _categoryName ?? '';
  bool hasCategoryName() => _categoryName != null;

  // "score" field.
  double? _score;
  double get score => _score ?? 0.0;
  bool hasScore() => _score != null;

  // "userref" field.
  DocumentReference? _userref;
  DocumentReference? get userref => _userref;
  bool hasUserref() => _userref != null;

  // "day" field.
  int? _day;
  int get day => _day ?? 0;
  bool hasDay() => _day != null;

  // "date" field.
  DateTime? _date;
  DateTime? get date => _date;
  bool hasDate() => _date != null;

  void _initializeFields() {
    _categoryName = snapshotData['category_name'] as String?;
    _score = castToType<double>(snapshotData['score']);
    _userref = snapshotData['userref'] as DocumentReference?;
    _day = castToType<int>(snapshotData['day']);
    _date = snapshotData['date'] as DateTime?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('tests');

  static Stream<TestsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => TestsRecord.fromSnapshot(s));

  static Future<TestsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => TestsRecord.fromSnapshot(s));

  static TestsRecord fromSnapshot(DocumentSnapshot snapshot) => TestsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static TestsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      TestsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'TestsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is TestsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createTestsRecordData({
  String? categoryName,
  double? score,
  DocumentReference? userref,
  int? day,
  DateTime? date,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'category_name': categoryName,
      'score': score,
      'userref': userref,
      'day': day,
      'date': date,
    }.withoutNulls,
  );

  return firestoreData;
}

class TestsRecordDocumentEquality implements Equality<TestsRecord> {
  const TestsRecordDocumentEquality();

  @override
  bool equals(TestsRecord? e1, TestsRecord? e2) {
    return e1?.categoryName == e2?.categoryName &&
        e1?.score == e2?.score &&
        e1?.userref == e2?.userref &&
        e1?.day == e2?.day &&
        e1?.date == e2?.date;
  }

  @override
  int hash(TestsRecord? e) => const ListEquality()
      .hash([e?.categoryName, e?.score, e?.userref, e?.day, e?.date]);

  @override
  bool isValidKey(Object? o) => o is TestsRecord;
}
