import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class TotaltestsRecord extends FirestoreRecord {
  TotaltestsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "total" field.
  int? _total;
  int get total => _total ?? 0;
  bool hasTotal() => _total != null;

  void _initializeFields() {
    _total = castToType<int>(snapshotData['total']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('totaltests');

  static Stream<TotaltestsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => TotaltestsRecord.fromSnapshot(s));

  static Future<TotaltestsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => TotaltestsRecord.fromSnapshot(s));

  static TotaltestsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      TotaltestsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static TotaltestsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      TotaltestsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'TotaltestsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is TotaltestsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createTotaltestsRecordData({
  int? total,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'total': total,
    }.withoutNulls,
  );

  return firestoreData;
}

class TotaltestsRecordDocumentEquality implements Equality<TotaltestsRecord> {
  const TotaltestsRecordDocumentEquality();

  @override
  bool equals(TotaltestsRecord? e1, TotaltestsRecord? e2) {
    return e1?.total == e2?.total;
  }

  @override
  int hash(TotaltestsRecord? e) => const ListEquality().hash([e?.total]);

  @override
  bool isValidKey(Object? o) => o is TotaltestsRecord;
}
