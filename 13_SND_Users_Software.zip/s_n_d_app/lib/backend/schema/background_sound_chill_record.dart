import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class BackgroundSoundChillRecord extends FirestoreRecord {
  BackgroundSoundChillRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "title" field.
  String? _title;
  String get title => _title ?? '';
  bool hasTitle() => _title != null;

  void _initializeFields() {
    _title = snapshotData['title'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('backgroundSound-Chill');

  static Stream<BackgroundSoundChillRecord> getDocument(
          DocumentReference ref) =>
      ref.snapshots().map((s) => BackgroundSoundChillRecord.fromSnapshot(s));

  static Future<BackgroundSoundChillRecord> getDocumentOnce(
          DocumentReference ref) =>
      ref.get().then((s) => BackgroundSoundChillRecord.fromSnapshot(s));

  static BackgroundSoundChillRecord fromSnapshot(DocumentSnapshot snapshot) =>
      BackgroundSoundChillRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static BackgroundSoundChillRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      BackgroundSoundChillRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'BackgroundSoundChillRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is BackgroundSoundChillRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createBackgroundSoundChillRecordData({
  String? title,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'title': title,
    }.withoutNulls,
  );

  return firestoreData;
}

class BackgroundSoundChillRecordDocumentEquality
    implements Equality<BackgroundSoundChillRecord> {
  const BackgroundSoundChillRecordDocumentEquality();

  @override
  bool equals(BackgroundSoundChillRecord? e1, BackgroundSoundChillRecord? e2) {
    return e1?.title == e2?.title;
  }

  @override
  int hash(BackgroundSoundChillRecord? e) =>
      const ListEquality().hash([e?.title]);

  @override
  bool isValidKey(Object? o) => o is BackgroundSoundChillRecord;
}
