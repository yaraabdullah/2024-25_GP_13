import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_pdf_viewer.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'report_rating_copy_widget.dart' show ReportRatingCopyWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ReportRatingCopyModel extends FlutterFlowModel<ReportRatingCopyWidget> {
  ///  Local state fields for this page.

  String? ratingId;

  List<int> existingList = [];
  void addToExistingList(int item) => existingList.add(item);
  void removeFromExistingList(int item) => existingList.remove(item);
  void removeAtIndexFromExistingList(int index) => existingList.removeAt(index);
  void insertAtIndexInExistingList(int index, int item) =>
      existingList.insert(index, item);
  void updateExistingListAtIndex(int index, Function(int) updateFn) =>
      existingList[index] = updateFn(existingList[index]);

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
