import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/flutter_flow/random_data_util.dart' as random_data;
import '/index.dart';
import 'report_rating_widget.dart' show ReportRatingWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ReportRatingModel extends FlutterFlowModel<ReportRatingWidget> {
  ///  Local state fields for this page.

  String? ratingId;

  List<int> existingList = [];
  void addToExistingList(int item) => existingList.add(item);
  void removeFromExistingList(int item) => existingList.remove(item);
  void removeAtIndexFromExistingList(int index) => existingList.removeAt(index);
  void insertAtIndexInExistingList(int index, int item) =>
      existingList.insert(index, item);
  void updateExistingListAtIndex(int index, Function(int) updateFn) =>
      existingList[index] = updateFn(existingList[index]);

  ///  State fields for stateful widgets in this page.

  // State field(s) for RatingBar widget.
  double? ratingBarValue1;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  UsersRecord? doctorQuery;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
