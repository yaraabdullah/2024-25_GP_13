import '/auth/firebase_auth/auth_util.dart';
import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/backend/custom_cloud_functions/custom_cloud_function_response_manager.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_calendar.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 'edit_reservation_widget.dart' show EditReservationWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class EditReservationModel extends FlutterFlowModel<EditReservationWidget> {
  ///  Local state fields for this page.

  TimeSlotStruct? selectedSlot;
  void updateSelectedSlotStruct(Function(TimeSlotStruct) updateFn) {
    updateFn(selectedSlot ??= TimeSlotStruct());
  }

  DateTime? selectedDay;

  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  // State field(s) for NameField widget.
  FocusNode? nameFieldFocusNode;
  TextEditingController? nameFieldTextController;
  String? Function(BuildContext, String?)? nameFieldTextControllerValidator;
  String? _nameFieldTextControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Please enter your name';
    }

    if (!RegExp('^[a-zA-Z\\s]+\$').hasMatch(val)) {
      return 'Name must contain only alphabetic characters';
    }
    return null;
  }

  // State field(s) for AgeField widget.
  FocusNode? ageFieldFocusNode;
  TextEditingController? ageFieldTextController;
  String? Function(BuildContext, String?)? ageFieldTextControllerValidator;
  String? _ageFieldTextControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Please enter your age';
    }

    if (!RegExp('^\\d+\$').hasMatch(val)) {
      return 'Age must be a number';
    }
    return null;
  }

  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController3;
  String? Function(BuildContext, String?)? textController3Validator;
  // State field(s) for Calendar widget.
  DateTimeRange? calendarSelectedDay;
  // Stores action output result for [Backend Call - Read Document] action in Button widget.
  BookingsRecord? prevBookdetails;
  // Stores action output result for [Backend Call - API (Cancel Scheduled Email)] action in Button widget.
  ApiCallResponse? canceledtheschedule;
  // Stores action output result for [Cloud Function - sendScheduledEmail] action in Button widget.
  SendScheduledEmailCloudFunctionCallResponse? cloudFunctionivr;

  @override
  void initState(BuildContext context) {
    nameFieldTextControllerValidator = _nameFieldTextControllerValidator;
    ageFieldTextControllerValidator = _ageFieldTextControllerValidator;
    calendarSelectedDay = DateTimeRange(
      start: DateTime.now().startOfDay,
      end: DateTime.now().endOfDay,
    );
  }

  @override
  void dispose() {
    nameFieldFocusNode?.dispose();
    nameFieldTextController?.dispose();

    ageFieldFocusNode?.dispose();
    ageFieldTextController?.dispose();

    textFieldFocusNode?.dispose();
    textController3?.dispose();
  }

  /// Action blocks.
  Future availableS(BuildContext context) async {}
}
