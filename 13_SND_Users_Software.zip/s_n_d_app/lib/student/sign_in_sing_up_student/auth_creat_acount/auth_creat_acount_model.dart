import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/flutter_flow/random_data_util.dart' as random_data;
import '/index.dart';
import 'auth_creat_acount_widget.dart' show AuthCreatAcountWidget;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:provider/provider.dart';

class AuthCreatAcountModel extends FlutterFlowModel<AuthCreatAcountWidget> {
  ///  Local state fields for this page.

  bool? arabic;

  bool? english;

  bool? sleep;

  bool? depression;

  bool? anxiety;

  bool? gender;

  bool? eating;

  bool? panic;

  bool? personality;

  ///  State fields for stateful widgets in this page.

  final formKey2 = GlobalKey<FormState>();
  final formKey1 = GlobalKey<FormState>();
  // State field(s) for TabBar widget.
  TabController? tabBarController;
  int get tabBarCurrentIndex =>
      tabBarController != null ? tabBarController!.index : 0;
  int get tabBarPreviousIndex =>
      tabBarController != null ? tabBarController!.previousIndex : 0;

  // State field(s) for emailAddress66 widget.
  FocusNode? emailAddress66FocusNode;
  TextEditingController? emailAddress66TextController;
  String? Function(BuildContext, String?)?
      emailAddress66TextControllerValidator;
  String? _emailAddress66TextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Please enter your KSU student email';
    }

    if (!RegExp('^\\d{9}@student\\.ksu\\.edu\\.sa\$').hasMatch(val)) {
      return 'Email must be a valid KSU student email';
    }
    return null;
  }

  // State field(s) for password widget.
  FocusNode? passwordFocusNode;
  TextEditingController? passwordTextController;
  late bool passwordVisibility;
  String? Function(BuildContext, String?)? passwordTextControllerValidator;
  String? _passwordTextControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Field is required';
    }

    if (!RegExp('^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[\\W_]).{8,}\$')
        .hasMatch(val)) {
      return 'Password too short or missing character types.';
    }
    return null;
  }

  // State field(s) for Columny widget.
  ScrollController? columny;
  // State field(s) for Name widget.
  FocusNode? nameFocusNode1;
  TextEditingController? nameTextController1;
  String? Function(BuildContext, String?)? nameTextController1Validator;
  String? _nameTextController1Validator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Please enter your First Name';
    }

    if (!RegExp('^[a-zA-Z\\s]+\$').hasMatch(val)) {
      return 'Name must contain only alphabetic characters';
    }
    return null;
  }

  // State field(s) for Name widget.
  FocusNode? nameFocusNode2;
  TextEditingController? nameTextController2;
  String? Function(BuildContext, String?)? nameTextController2Validator;
  String? _nameTextController2Validator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Please enter your Last Name ';
    }

    if (!RegExp('^[a-zA-Z\\s]+\$').hasMatch(val)) {
      return 'Name must contain only alphabetic characters';
    }
    return null;
  }

  DateTime? datePicked;
  // State field(s) for Gender widget.
  String? genderValue;
  FormFieldController<String>? genderValueController;
  // State field(s) for PhoneNumber widget.
  FocusNode? phoneNumberFocusNode;
  TextEditingController? phoneNumberTextController;
  final phoneNumberMask = MaskTextInputFormatter(mask: '##########');
  String? Function(BuildContext, String?)? phoneNumberTextControllerValidator;
  String? _phoneNumberTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Please enter your Phone Number start with 05';
    }

    if (!RegExp('^05\\d{8}\$').hasMatch(val)) {
      return 'Must be a valid Phone Number start with 05';
    }
    return null;
  }

  // State field(s) for emailAddress1111 widget.
  FocusNode? emailAddress1111FocusNode;
  TextEditingController? emailAddress1111TextController;
  String? Function(BuildContext, String?)?
      emailAddress1111TextControllerValidator;
  bool isDataUploading1 = false;
  FFUploadedFile uploadedLocalFile1 =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl1 = '';

  // State field(s) for Specialty widget.
  String? specialtyValue;
  FormFieldController<String>? specialtyValueController;
  // State field(s) for sleep widget.
  bool? sleepValue;
  // State field(s) for depression widget.
  bool? depressionValue;
  // State field(s) for anxiety widget.
  bool? anxietyValue;
  // State field(s) for Checkbox widget.
  bool? checkboxValue1;
  // State field(s) for Checkbox widget.
  bool? checkboxValue2;
  // State field(s) for Checkbox widget.
  bool? checkboxValue3;
  // State field(s) for arabic widget.
  bool? arabicValue;
  // State field(s) for english widget.
  bool? englishValue;
  // State field(s) for About widget.
  FocusNode? aboutFocusNode;
  TextEditingController? aboutTextController;
  String? Function(BuildContext, String?)? aboutTextControllerValidator;
  String? _aboutTextControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Please tell us ABOUT yourself';
    }

    return null;
  }

  bool isDataUploading2 = false;
  FFUploadedFile uploadedLocalFile2 =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl2 = '';

  // State field(s) for password1111 widget.
  FocusNode? password1111FocusNode;
  TextEditingController? password1111TextController;
  late bool password1111Visibility;
  String? Function(BuildContext, String?)? password1111TextControllerValidator;
  String? _password1111TextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Please enter your Password';
    }

    if (!RegExp('^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[\\W_]).{8,}\$')
        .hasMatch(val)) {
      return 'Password too short or missing character types';
    }
    return null;
  }

  // State field(s) for PasswordConfirm1111 widget.
  FocusNode? passwordConfirm1111FocusNode;
  TextEditingController? passwordConfirm1111TextController;
  late bool passwordConfirm1111Visibility;
  String? Function(BuildContext, String?)?
      passwordConfirm1111TextControllerValidator;
  String? _passwordConfirm1111TextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Please confirm your Password';
    }

    if (!RegExp('^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[\\W_]).{8,}\$')
        .hasMatch(val)) {
      return 'Password too short or missing character types';
    }
    return null;
  }

  @override
  void initState(BuildContext context) {
    emailAddress66TextControllerValidator =
        _emailAddress66TextControllerValidator;
    passwordVisibility = false;
    passwordTextControllerValidator = _passwordTextControllerValidator;
    columny = ScrollController();
    nameTextController1Validator = _nameTextController1Validator;
    nameTextController2Validator = _nameTextController2Validator;
    phoneNumberTextControllerValidator = _phoneNumberTextControllerValidator;
    aboutTextControllerValidator = _aboutTextControllerValidator;
    password1111Visibility = false;
    password1111TextControllerValidator = _password1111TextControllerValidator;
    passwordConfirm1111Visibility = false;
    passwordConfirm1111TextControllerValidator =
        _passwordConfirm1111TextControllerValidator;
  }

  @override
  void dispose() {
    tabBarController?.dispose();
    emailAddress66FocusNode?.dispose();
    emailAddress66TextController?.dispose();

    passwordFocusNode?.dispose();
    passwordTextController?.dispose();

    columny?.dispose();
    nameFocusNode1?.dispose();
    nameTextController1?.dispose();

    nameFocusNode2?.dispose();
    nameTextController2?.dispose();

    phoneNumberFocusNode?.dispose();
    phoneNumberTextController?.dispose();

    emailAddress1111FocusNode?.dispose();
    emailAddress1111TextController?.dispose();

    aboutFocusNode?.dispose();
    aboutTextController?.dispose();

    password1111FocusNode?.dispose();
    password1111TextController?.dispose();

    passwordConfirm1111FocusNode?.dispose();
    passwordConfirm1111TextController?.dispose();
  }
}
