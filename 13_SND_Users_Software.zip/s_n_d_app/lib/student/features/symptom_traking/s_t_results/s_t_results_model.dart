import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_button_tabbar.dart';
import '/flutter_flow/flutter_flow_charts.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:math';
import 'dart:ui';
import '/index.dart';
import 's_t_results_widget.dart' show STResultsWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class STResultsModel extends FlutterFlowModel<STResultsWidget> {
  ///  Local state fields for this page.

  List<TestsRecord> depressionpage = [];
  void addToDepressionpage(TestsRecord item) => depressionpage.add(item);
  void removeFromDepressionpage(TestsRecord item) =>
      depressionpage.remove(item);
  void removeAtIndexFromDepressionpage(int index) =>
      depressionpage.removeAt(index);
  void insertAtIndexInDepressionpage(int index, TestsRecord item) =>
      depressionpage.insert(index, item);
  void updateDepressionpageAtIndex(int index, Function(TestsRecord) updateFn) =>
      depressionpage[index] = updateFn(depressionpage[index]);

  List<TestsRecord> anxietypage = [];
  void addToAnxietypage(TestsRecord item) => anxietypage.add(item);
  void removeFromAnxietypage(TestsRecord item) => anxietypage.remove(item);
  void removeAtIndexFromAnxietypage(int index) => anxietypage.removeAt(index);
  void insertAtIndexInAnxietypage(int index, TestsRecord item) =>
      anxietypage.insert(index, item);
  void updateAnxietypageAtIndex(int index, Function(TestsRecord) updateFn) =>
      anxietypage[index] = updateFn(anxietypage[index]);

  List<TestsRecord> sleeppage = [];
  void addToSleeppage(TestsRecord item) => sleeppage.add(item);
  void removeFromSleeppage(TestsRecord item) => sleeppage.remove(item);
  void removeAtIndexFromSleeppage(int index) => sleeppage.removeAt(index);
  void insertAtIndexInSleeppage(int index, TestsRecord item) =>
      sleeppage.insert(index, item);
  void updateSleeppageAtIndex(int index, Function(TestsRecord) updateFn) =>
      sleeppage[index] = updateFn(sleeppage[index]);

  ///  State fields for stateful widgets in this page.

  // State field(s) for Checkbox widget.
  bool? checkboxValue1;
  // Stores action output result for [Firestore Query - Query a collection] action in Checkbox widget.
  List<TestsRecord>? depression;
  // State field(s) for Checkbox widget.
  bool? checkboxValue2;
  // Stores action output result for [Firestore Query - Query a collection] action in Checkbox widget.
  List<TestsRecord>? anxiety;
  // State field(s) for Checkbox widget.
  bool? checkboxValue3;
  // Stores action output result for [Firestore Query - Query a collection] action in Checkbox widget.
  List<TestsRecord>? sleep;
  // State field(s) for TabBar widget.
  TabController? tabBarController;
  int get tabBarCurrentIndex =>
      tabBarController != null ? tabBarController!.index : 0;
  int get tabBarPreviousIndex =>
      tabBarController != null ? tabBarController!.previousIndex : 0;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    tabBarController?.dispose();
  }
}
