import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:math';
import 'dart:ui';
import '/custom_code/widgets/index.dart' as custom_widgets;
import '/index.dart';
import 'chill_sound_copy_copy2_copy2_widget.dart'
    show ChillSoundCopyCopy2Copy2Widget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ChillSoundCopyCopy2Copy2Model
    extends FlutterFlowModel<ChillSoundCopyCopy2Copy2Widget> {
  ///  Local state fields for this page.

  bool isLooping = true;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
