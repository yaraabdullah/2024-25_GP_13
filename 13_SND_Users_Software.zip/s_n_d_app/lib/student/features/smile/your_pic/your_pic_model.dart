import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 'your_pic_widget.dart' show YourPicWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class YourPicModel extends FlutterFlowModel<YourPicWidget> {
  ///  Local state fields for this page.

  List<SmilealbumStruct> smileitem = [];
  void addToSmileitem(SmilealbumStruct item) => smileitem.add(item);
  void removeFromSmileitem(SmilealbumStruct item) => smileitem.remove(item);
  void removeAtIndexFromSmileitem(int index) => smileitem.removeAt(index);
  void insertAtIndexInSmileitem(int index, SmilealbumStruct item) =>
      smileitem.insert(index, item);
  void updateSmileitemAtIndex(int index, Function(SmilealbumStruct) updateFn) =>
      smileitem[index] = updateFn(smileitem[index]);

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
