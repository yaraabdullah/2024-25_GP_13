import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:ui';
import '/index.dart';
import 'need_more_info_widget.dart' show NeedMoreInfoWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class NeedMoreInfoModel extends FlutterFlowModel<NeedMoreInfoWidget> {
  ///  Local state fields for this page.

  bool? sleep;

  bool? depression;

  bool? anxiety;

  bool? eating;

  bool? panic;

  bool? personality;

  bool? arabic;

  bool? english;

  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  // State field(s) for Specialty widget.
  String? specialtyValue;
  FormFieldController<String>? specialtyValueController;
  // State field(s) for sleep widget.
  bool? sleepValue;
  // State field(s) for depression widget.
  bool? depressionValue;
  // State field(s) for anxiety widget.
  bool? anxietyValue;
  // State field(s) for Checkbox widget.
  bool? checkboxValue1;
  // State field(s) for Checkbox widget.
  bool? checkboxValue2;
  // State field(s) for Checkbox widget.
  bool? checkboxValue3;
  // State field(s) for arabic widget.
  bool? arabicValue;
  // State field(s) for english widget.
  bool? englishValue;
  // State field(s) for About widget.
  FocusNode? aboutFocusNode;
  TextEditingController? aboutTextController;
  String? Function(BuildContext, String?)? aboutTextControllerValidator;
  String? _aboutTextControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Please about ir required';
    }

    return null;
  }

  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl = '';

  @override
  void initState(BuildContext context) {
    aboutTextControllerValidator = _aboutTextControllerValidator;
  }

  @override
  void dispose() {
    aboutFocusNode?.dispose();
    aboutTextController?.dispose();
  }
}
