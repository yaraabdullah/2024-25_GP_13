import '/auth/firebase_auth/auth_util.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/index.dart';
import 'doctor_calender_updated_widget.dart' show DoctorCalenderUpdatedWidget;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DoctorCalenderUpdatedModel
    extends FlutterFlowModel<DoctorCalenderUpdatedWidget> {
  ///  Local state fields for this page.

  List<String> sunday = [];
  void addToSunday(String item) => sunday.add(item);
  void removeFromSunday(String item) => sunday.remove(item);
  void removeAtIndexFromSunday(int index) => sunday.removeAt(index);
  void insertAtIndexInSunday(int index, String item) =>
      sunday.insert(index, item);
  void updateSundayAtIndex(int index, Function(String) updateFn) =>
      sunday[index] = updateFn(sunday[index]);

  String eightam = '8:00 AM';

  String nineAm = '9:00 AM';

  String tenam = '10:00 AM';

  String elevenam = '11:00 AM';

  String tewelvepm = '12:00 PM';

  String onepm = '1:00 PM';

  String twopm = '2:00 PM';

  String threepm = '3:00 PM';

  String fourpm = '4:00 PM';

  List<String> monday = [];
  void addToMonday(String item) => monday.add(item);
  void removeFromMonday(String item) => monday.remove(item);
  void removeAtIndexFromMonday(int index) => monday.removeAt(index);
  void insertAtIndexInMonday(int index, String item) =>
      monday.insert(index, item);
  void updateMondayAtIndex(int index, Function(String) updateFn) =>
      monday[index] = updateFn(monday[index]);

  List<String> tuesday = [];
  void addToTuesday(String item) => tuesday.add(item);
  void removeFromTuesday(String item) => tuesday.remove(item);
  void removeAtIndexFromTuesday(int index) => tuesday.removeAt(index);
  void insertAtIndexInTuesday(int index, String item) =>
      tuesday.insert(index, item);
  void updateTuesdayAtIndex(int index, Function(String) updateFn) =>
      tuesday[index] = updateFn(tuesday[index]);

  List<String> wednesday = [];
  void addToWednesday(String item) => wednesday.add(item);
  void removeFromWednesday(String item) => wednesday.remove(item);
  void removeAtIndexFromWednesday(int index) => wednesday.removeAt(index);
  void insertAtIndexInWednesday(int index, String item) =>
      wednesday.insert(index, item);
  void updateWednesdayAtIndex(int index, Function(String) updateFn) =>
      wednesday[index] = updateFn(wednesday[index]);

  List<String> thursday = [];
  void addToThursday(String item) => thursday.add(item);
  void removeFromThursday(String item) => thursday.remove(item);
  void removeAtIndexFromThursday(int index) => thursday.removeAt(index);
  void insertAtIndexInThursday(int index, String item) =>
      thursday.insert(index, item);
  void updateThursdayAtIndex(int index, Function(String) updateFn) =>
      thursday[index] = updateFn(thursday[index]);

  ///  State fields for stateful widgets in this page.

  DateTime? datePicked1;
  DateTime? datePicked2;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
