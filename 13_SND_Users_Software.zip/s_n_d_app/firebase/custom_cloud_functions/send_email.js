const functions = require("firebase-functions");
const fetch = (...args) =>
  import("node-fetch").then(({ default: fetch }) => fetch(...args));

exports.sendEmail = functions.https.onCall(async (data, context) => {
  const {
    clinicName,
    date,
    studentNationalID,
    time,
    doctorName,
    studentDOB,
    studentFirstName,
    studentLastName,
    studentPhoneNumber,
  } = data;

  // Validate parameters
  if (
    !clinicName ||
    !date ||
    !studentNationalID ||
    !time ||
    !doctorName ||
    !studentDOB ||
    !studentFirstName ||
    !studentLastName ||
    !studentPhoneNumber
  ) {
    throw new functions.https.HttpsError(
      "invalid-argument",
      "Missing one or more required parameters.",
    );
  }

  const from = "SND <support@sndmentalhealth.com>"; // Verified sender
  const to = "rsalmuferaj@moh.gov.sa";
  const subject = "Clinic Submitted"; // Fixed subject

  const emailHtml = `
    <p><strong>Clinic Name:</strong> ${clinicName}</p>
    <p><strong>Date:</strong> ${date}</p>
    <p><strong>Student National ID:</strong> ${studentNationalID}</p>
    <p><strong>Time:</strong> ${time}</p>
    <p><strong>Doctor Name:</strong> ${doctorName}</p>
    <p><strong>Student DOB:</strong> ${studentDOB}</p>
    <p><strong>Student First Name:</strong> ${studentFirstName}</p>
    <p><strong>Student Last Name:</strong> ${studentLastName}</p>
    <p><strong>Student Phone Number:</strong> ${studentPhoneNumber}</p>
  `;

  try {
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: "Bearer re_HcNizjix_NHSqzeya4n6c95ikdtfZAq7P", // Your API key
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from,
        to,
        subject,
        html: emailHtml,
      }),
    });

    const responseData = await response.json();
    return responseData;
  } catch (error) {
    console.error("Error sending email:", error);
    throw new functions.https.HttpsError(
      "internal",
      "Failed to send the email.",
      error,
    );
  }
});
