// const functions = require('firebase-functions');
// const admin = require('firebase-admin');
// const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

// exports.sendScheduledEmail = functions.https.onCall(async (data, context) => {
//   const { from, to, subject, userName, doctorName, date, time, scheduledAt } = data;

//   if (!from || !to || !subject || !userName || !doctorName || !date || !time || !scheduledAt) {
//     throw new functions.https.HttpsError(
//       'invalid-argument',
//       'Missing one or more required parameters.'
//     );
//   }

//   // Templates as HTML
//   const confirmationHtml = `
//     <p>Dear ${userName},</p>
//     <p>We’re happy to let you know that your appointment has been successfully confirmed! Taking care of your well-being is important, and we’re here to support you every step of the way.</p>
//     <p><strong>Here are the details of your appointment:</strong></p>
//     <ul>
//       <li><strong>Doctor:</strong> ${doctorName}</li>
//       <li><strong>Date:</strong> ${date}</li>
//       <li><strong>Time:</strong> ${time}</li>
//     </ul>
//     <p>You can always check these details in the Appointments section of the SND app.</p>
//     <p>Take care, and we look forward to seeing you soon!</p>
//     <p>Warm regards,<br/>The SND Support Team</p>
//   `;

//   const reminderHtml = `
//     <p>Dear ${userName},</p>
//     <p>Just a gentle reminder that you have an appointment today! Prioritizing your well-being is a wonderful step, and we’re here to support you.</p>
//     <p><strong>Here are your appointment details:</strong></p>
//     <ul>
//       <li><strong>Doctor:</strong> ${doctorName}</li>
//       <li><strong>Date:</strong> ${date}</li>
//       <li><strong>Time:</strong> ${time}</li>
//     </ul>
//     <p>You can enter your appointment link from the Appointments section in the SND app.</p>
//     <p>Wishing you a peaceful and productive session!</p>
//     <p>Best wishes,<br/>The SND Support Team</p>
//   `;

//   try {
//     // --- 1. Send Confirmation Email (immediate) ---
//     await fetch('https://api.resend.com/emails', {
//       method: 'POST',
//       headers: {
//         'Authorization': 'Bearer re_HcNizjix_NHSqzeya4n6c95ikdtfZAq7P',
//         'Content-Type': 'application/json',
//       },
//       body: JSON.stringify({
//         from,
//         to,
//         subject,
//         html: confirmationHtml,
//       }),
//     });

//     // --- 2. Send Reminder Email (2 hours before) ---
//     const appointmentTime = new Date(scheduledAt * 1000);
//     const emailTime = new Date(appointmentTime.getTime() - 2 * 60 * 60 * 1000);
//     const isoTime = emailTime.toISOString();

//     await fetch('https://api.resend.com/emails', {
//       method: 'POST',
//       headers: {
//         'Authorization': 'Bearer re_HcNizjix_NHSqzeya4n6c95ikdtfZAq7P',
//         'Content-Type': 'application/json',
//       },
//       body: JSON.stringify({
//         from,
//         to,
//         subject: `${subject} (Reminder - 2 Hours Before)`,
//         html: reminderHtml,
//         scheduled_at: isoTime,
//       }),
//     });

//     return "Confirmation and reminder emails sent/scheduled successfully";
//   } catch (error) {
//     console.error('Error sending emails:', error);
//     throw new functions.https.HttpsError(
//       'internal',
//       'Failed to send or schedule email.',
//       error
//     );
//   }
// });

const functions = require("firebase-functions");
const admin = require("firebase-admin");
const fetch = (...args) =>
  import("node-fetch").then(({ default: fetch }) => fetch(...args));

exports.sendScheduledEmail = functions.https.onCall(async (data, context) => {
  const { from, to, subject, userName, doctorName, date, time, scheduledAt } =
    data;

  if (
    !from ||
    !to ||
    !subject ||
    !userName ||
    !doctorName ||
    !date ||
    !time ||
    !scheduledAt
  ) {
    throw new functions.https.HttpsError(
      "invalid-argument",
      "Missing one or more required parameters.",
    );
  }

  const confirmationHtml = `
    <p>Dear ${userName},</p>
    <p>We’re happy to let you know that your appointment has been successfully confirmed! Taking care of your well-being is important, and we’re here to support you every step of the way.</p>
    <p><strong>Here are the details of your appointment:</strong></p>
    <ul>
      <li><strong>Doctor:</strong> ${doctorName}</li>
      <li><strong>Date:</strong> ${date}</li>
      <li><strong>Time:</strong> ${time}</li>
    </ul>
    <p>You can always check these details in the Appointments section of the SND app.</p>
    <p>Take care, and we look forward to seeing you soon!</p>
    <p>Warm regards,<br/>The SND Support Team</p>
  `;

  const reminderHtml = `
    <p>Dear ${userName},</p>
    <p>Just a gentle reminder that you have an appointment today! Prioritizing your well-being is a wonderful step, and we’re here to support you.</p>
    <p><strong>Here are your appointment details:</strong></p>
    <ul>
      <li><strong>Doctor:</strong> ${doctorName}</li>
      <li><strong>Date:</strong> ${date}</li>
      <li><strong>Time:</strong> ${time}</li>
    </ul>
    <p>You can enter your appointment link from the Appointments section in the SND app.</p>
    <p>Wishing you a peaceful and productive session!</p>
    <p>Best wishes,<br/>The SND Support Team</p>
  `;

  try {
    // --- 1. Send Confirmation Email (immediate) ---
    await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: "Bearer re_HcNizjix_NHSqzeya4n6c95ikdtfZAq7P",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from,
        to,
        subject,
        html: confirmationHtml,
      }),
    });

    // --- 2. Send Reminder Email (2 hours before) ---
    const appointmentTime = new Date(scheduledAt * 1000);
    const emailTime = new Date(appointmentTime.getTime() - 2 * 60 * 60 * 1000);
    const isoTime = emailTime.toISOString();

    const reminderResponse = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: "Bearer re_HcNizjix_NHSqzeya4n6c95ikdtfZAq7P",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from,
        to,
        subject: `${subject} (Reminder - 2 Hours Before)`,
        html: reminderHtml,
        scheduled_at: isoTime,
      }),
    });

    const reminderData = await reminderResponse.json();
    const reminderEmailId = reminderData.id;

    // Return only the reminder email ID
    return reminderEmailId;
  } catch (error) {
    console.error("Error sending emails:", error);
    throw new functions.https.HttpsError(
      "internal",
      "Failed to send or schedule email.",
      error,
    );
  }
});
