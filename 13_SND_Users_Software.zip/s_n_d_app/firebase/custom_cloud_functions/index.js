const admin = require("firebase-admin/app");
admin.initializeApp();

const sendnotification = require("./sendnotification.js");
exports.sendnotification = sendnotification.sendnotification;
const sendScheduledEmail = require("./send_scheduled_email.js");
exports.sendScheduledEmail = sendScheduledEmail.sendScheduledEmail;
const scheduleSmileNotifications = require("./schedule_smile_notifications.js");
exports.scheduleSmileNotifications =
  scheduleSmileNotifications.scheduleSmileNotifications;
const sendEmail = require("./send_email.js");
exports.sendEmail = sendEmail.sendEmail;
