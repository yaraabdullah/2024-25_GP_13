const functions = require("firebase-functions");
const admin = require("firebase-admin");

// Avoid deployment errors by not calling admin.initializeApp() globally
if (!admin.apps.length) {
  admin.initializeApp(); // Initialize Firebase only if not already initialized
}

exports.sendnotification = functions.pubsub
  .schedule("0 5 * * *") // Runs daily at 09 AM UTC
  .onRun(async (context) => {
    console.log("Cloud function running");

    try {
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      tomorrow.setHours(0, 0, 0, 0);

      const dayAfterTomorrow = new Date(tomorrow);
      dayAfterTomorrow.setDate(tomorrow.getDate() + 1);

      const snapshot = await admin
        .firestore()
        .collection("bookings")
        .where(
          "appointmentDate",
          ">=",
          admin.firestore.Timestamp.fromDate(tomorrow),
        )
        .where(
          "appointmentDate",
          "<",
          admin.firestore.Timestamp.fromDate(dayAfterTomorrow),
        )
        .get();

      if (snapshot.empty) {
        console.log("No bookings for tomorrow.");
        return null;
      }

      const batch = admin.firestore().batch();

      snapshot.forEach((doc) => {
        const booking = doc.data();
        if (booking.userId) {
          const userRef = admin.firestore().doc(`users/${booking.userId}`);
          const notificationRef = admin
            .firestore()
            .collection("ff_push_notifications")
            .doc();
          batch.set(notificationRef, {
            user_refs: userRef,
            notification_title: "Appointment Reminder",
            initial_page_name: "Home",
            notification_sound: "default",
            target_audience: "All",
            notification_body: "Your appointment is scheduled for tomorrow.",
            timestamp: admin.firestore.FieldValue.serverTimestamp(),
          });
        }
      });

      await batch.commit();
      console.log("Notification documents created successfully.");
    } catch (error) {
      console.error("Error creating notification documents:", error);
    }
  });

// HTTP callable function for sending notifications manually
exports.sendNotificationCallable = functions
  .region("us-central1")
  .runWith({ memory: "128MB" })
  .https.onCall(async (data, context) => {
    try {
      if (!context.auth) {
        throw new functions.https.HttpsError(
          "unauthenticated",
          "Request is not authenticated.",
        );
      }

      const { userId, message } = data;
      if (!userId || !message) {
        throw new functions.https.HttpsError(
          "invalid-argument",
          "Missing userId or message",
        );
      }

      const userRef = admin.firestore().doc(`users/${userId}`);
      const notificationRef = admin
        .firestore()
        .collection("ff_push_notifications")
        .doc();

      await notificationRef.set({
        user_refs: userRef,
        notification_title: "Manual Notification",
        initial_page_name: "Home",
        notification_sound: "default",
        target_audience: "All",
        notification_body: message,
        timestamp: admin.firestore.FieldValue.serverTimestamp(),
      });

      return { success: true, message: "Notification sent successfully." };
    } catch (error) {
      console.error("Error sending manual notification:", error);
      throw new functions.https.HttpsError(
        "internal",
        "Failed to send notification",
      );
    }
  });

// HTTP callable function for flexible notification execution
exports.sendnotificationHttp = functions
  .region("us-central1")
  .runWith({ memory: "128MB" })
  .https.onRequest(async (req, res) => {
    console.log("HTTP function running");

    try {
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      tomorrow.setHours(0, 0, 0, 0);

      const dayAfterTomorrow = new Date(tomorrow);
      dayAfterTomorrow.setDate(tomorrow.getDate() + 1);

      const snapshot = await admin
        .firestore()
        .collection("bookings")
        .where(
          "appointmentDate",
          ">=",
          admin.firestore.Timestamp.fromDate(tomorrow),
        )
        .where(
          "appointmentDate",
          "<",
          admin.firestore.Timestamp.fromDate(dayAfterTomorrow),
        )
        .get();

      if (snapshot.empty) {
        console.log("No bookings for tomorrow.");
        return res.status(200).send("No bookings found.");
      }

      const batch = admin.firestore().batch();

      snapshot.forEach((doc) => {
        const booking = doc.data();
        if (booking.userId) {
          const userRef = admin.firestore().doc(`users/${booking.userId}`);
          const notificationRef = admin
            .firestore()
            .collection("ff_push_notifications")
            .doc();
          batch.set(notificationRef, {
            user_refs: userRef,
            notification_title: "Appointment Reminder",
            initial_page_name: "Home",
            notification_sound: "default",
            target_audience: "All",
            notification_body: "Your appointment is scheduled for tomorrow.",
            timestamp: admin.firestore.FieldValue.serverTimestamp(),
          });
        }
      });

      await batch.commit();
      console.log("Notification documents created successfully.");
      res.status(200).send("Notifications sent successfully.");
    } catch (error) {
      console.error("Error creating notification documents:", error);
      res.status(500).send("Error sending notifications.");
    }
  });
