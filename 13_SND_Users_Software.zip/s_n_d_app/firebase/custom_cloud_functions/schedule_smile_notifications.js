const functions = require("firebase-functions");
const admin = require("firebase-admin");

const firestore = admin.firestore();

exports.scheduleSmileNotifications = functions.pubsub
  .schedule("22 08 * * *")
  .timeZone("UTC")
  .onRun(async (context) => {
    console.log("Smile notification function triggered.");

    const now = new Date();
    //    const targetUserRef = firestore.doc('Users/JehqFjfJl1dzVfePQFh7uC2AvP33');

    // Fetch all users and smile notifications first
    const [usersSnapshot, smileNotificationsSnapshot] = await Promise.all([
      firestore.collection("Users").get(),
      firestore.collection("SmileNotification").get(),
    ]);

    console.log(`Fetched ${usersSnapshot.size} users.`);
    console.log(
      `Fetched ${smileNotificationsSnapshot.size} smile notifications.`,
    );

    if (smileNotificationsSnapshot.empty) {
      console.log("No SmileNotifications found.");
      return null;
    }

    const smileNotifications = smileNotificationsSnapshot.docs.map(
      (doc) => doc.data().notification,
    );

    for (const userDoc of usersSnapshot.docs) {
      const userData = userDoc.data();
      const fcmToken = userData.fcm_token;
      const frequency = userData.notificationFrequency;
      const lastNotificationSent = userData.lastNotificationSent;
      const hasReceivedFirstNotification =
        userData.hasReceivedFirstNotification;

      //     if (userDoc.ref.path === targetUserRef.path) {
      // Handle first-time notification for the target user
      if (!hasReceivedFirstNotification) {
        const randomNotification = getRandomNotification(smileNotifications);
        console.log(
          `User ${userDoc.id} will receive first notification: ${randomNotification}`,
        );

        try {
          await sendSmileNotification(
            fcmToken,
            "Smile Reminder 😊",
            randomNotification,
          );
          await userDoc.ref.update({
            lastNotificationSent: admin.firestore.Timestamp.fromDate(now),
            hasReceivedFirstNotification: true,
          });
          console.log(
            `First notification sent and updated for user ${userDoc.id}.`,
          );
        } catch (error) {
          console.error(
            `Failed to send first notification to user ${userDoc.id}:`,
            error,
          );
        }
        continue; // Skip daily/weekly check
      }
      //     }

      // Skip if missing token or frequency
      if (!fcmToken) {
        console.log(`User ${userDoc.id} skipped: missing fcm_token.`);
        continue;
      }

      if (!frequency || frequency === "Never") {
        console.log(`User ${userDoc.id} skipped: frequency is ${frequency}.`);
        continue;
      }

      if (
        !lastNotificationSent ||
        typeof lastNotificationSent.toDate !== "function"
      ) {
        console.log(
          `User ${userDoc.id} skipped: invalid lastNotificationSent.`,
        );
        continue;
      }

      const lastSentDate = lastNotificationSent.toDate();
      const diffInMs = now - lastSentDate;
      const diffInDays = diffInMs / (1000 * 60 * 60 * 24);

      let shouldSend = false;

      if (frequency === "Daily" && diffInDays >= 1) {
        shouldSend = true;
      } else if (frequency === "Every three day" && diffInDays >= 3) {
        shouldSend = true;
      } else if (frequency === "Weekly" && diffInDays >= 7) {
        shouldSend = true;
      }

      if (!shouldSend) {
        console.log(
          `User ${userDoc.id} skipped: not enough days passed (${diffInDays.toFixed(2)} days).`,
        );
        continue;
      }

      const randomNotification = getRandomNotification(smileNotifications);

      try {
        await sendSmileNotification(
          fcmToken,
          "Smile Reminder 😊",
          randomNotification,
        );
        await userDoc.ref.update({
          lastNotificationSent: admin.firestore.Timestamp.fromDate(now),
        });
        console.log(`Notification sent and updated for user ${userDoc.id}.`);
      } catch (error) {
        console.error(
          `Failed to send notification to user ${userDoc.id}:`,
          error,
        );
      }
    }

    console.log("Smile notification function finished.");
    return null;
  });

function getRandomNotification(notifications) {
  const index = Math.floor(Math.random() * notifications.length);
  return notifications[index];
}

async function sendSmileNotification(fcmToken, title, body) {
  console.log(`Sending FCM to: ${fcmToken}`);
  const message = {
    token: fcmToken,
    notification: { title, body },
    android: { priority: "high", notification: { sound: "default" } },
    apns: { payload: { aps: { sound: "default" } } },
  };

  try {
    const response = await admin.messaging().send(message);
    console.log(`FCM sent: ${response}`);
    return response;
  } catch (error) {
    console.error("FCM send error:", error);
    throw error;
  }
}
