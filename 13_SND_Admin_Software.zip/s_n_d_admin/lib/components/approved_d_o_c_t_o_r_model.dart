import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'approved_d_o_c_t_o_r_widget.dart' show ApprovedDOCTORWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ApprovedDOCTORModel extends FlutterFlowModel<ApprovedDOCTORWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
