// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'dart:html' as html;

Future<void> sendEmailToDoctor(String doctorEmail, String doctorName) async {
  final String supportEmail = "SNDHelpDesk@outlook.sa"; // admin email
  final String emailUri =
      'mailto:$doctorEmail?subject=Message from Admin&body=Dear Dr. $doctorName , this is a message from the admin.';

  html.window.open(emailUri, '_blank');
}
// Set your action name, define your arguments and return parameter,
// and then add the boilerplate code using the green button on the right!
